"""
第 2 章 · 真 embedding API —— 语义检索登场
==========================================

ch01 用词袋（BoW）做向量化，对"字面匹配"的问题能解决。但它**搞不定语义近义**：

  用户问"公司在哪儿？"     文档说"总部位于上海"     → BoW 算不出关联
  用户问"vegan 选项"        文档说"植物基"            → BoW 不知道这俩是近义
  用户问"小麦粉来自哪？"    文档说"原料采购"          → BoW 没有共同字

这一章我们换成**真 embedding API**：模型把每段文本映射到一组 1024 维数字，
让"上海"和"在哪儿"、"植物基"和"vegan"在数字空间里**距离很近**。

实现上 99% 跟 ch01 一样——唯一变化是 `vectorize()` 函数从"数词频"换成"调 embedding API"。
**这就是 RAG 工程的优雅之处**：检索算法不变，只换"向量来源"。
"""

import math
import os
import re
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

# ============================================================
# 两个 client：
#   chat_client      跟 ch00/ch01 一样，负责"对话"
#   embedding_client 新引入，负责"把文本→向量"
# 可以是同一个 provider，也可以分开（本课程默认硅基流动做 embedding）
# ============================================================
chat_client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]

embedding_client = OpenAI(
    api_key=os.environ.get("EMBEDDING_API_KEY") or os.environ["OPENAI_API_KEY"],
    base_url=os.environ.get("EMBEDDING_BASE_URL") or os.environ["OPENAI_BASE_URL"],
)
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-m3")


# ============================================================
# 切块（跟 ch01 同款）
# ============================================================
def chunk_by_heading(text: str) -> list[str]:
    parts = re.split(r"\n(?=## )", text)
    return [p.strip() for p in parts if p.strip()]


# ============================================================
# ★ 向量化：调真 embedding API（这是本章唯一的核心变化）
# ============================================================
def embed(texts: list[str]) -> list[list[float]]:
    """把一组文本批量送给 embedding 模型，返回一组向量。

    重点：**支持 batch**。一次调用可以处理几十条文本，比挨个调省钱省时间。
    """
    resp = embedding_client.embeddings.create(model=EMBEDDING_MODEL, input=texts)
    # resp.data 跟输入顺序一一对应；每个 .embedding 是 list[float]
    return [d.embedding for d in resp.data]


# ============================================================
# 余弦相似度 —— 改成支持普通 list[float]（不再是 Counter）
# ============================================================
def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# ============================================================
# 检索（跟 ch01 同构，类型变了而已）
# ============================================================
def retrieve(query_vec: list[float],
             chunk_vectors: list[list[float]],
             chunks: list[str],
             k: int = 3) -> list[tuple[int, float, str]]:
    scores = [(i, cosine_similarity(query_vec, cv), chunks[i]) for i, cv in enumerate(chunk_vectors)]
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:k]


# ============================================================
# 增强生成（跟 ch01 完全一致）
# ============================================================
def ask_with_rag(question: str, retrieved: list[tuple[int, float, str]]) -> str:
    blocks = []
    for i, (idx, score, text) in enumerate(retrieved, 1):
        blocks.append(f"--- 片段 {i} (相似度 {score:.3f}) ---\n{text}")
    context = "\n\n".join(blocks)

    messages = [
        {"role": "system", "content":
            "你是 Bread 面包工坊的客服助理。请基于下面检索到的知识库片段回答用户问题。"
            "如果片段里没有答案，必须明确说『知识库里没有相关信息』，不要瞎编。\n\n"
            f"========== 检索到的相关片段 ==========\n{context}\n========== 片段结束 =========="},
        {"role": "user", "content": question},
    ]
    resp = chat_client.chat.completions.create(model=MODEL, messages=messages)
    return resp.choices[0].message.content


# ============================================================
# 主流程
# ============================================================
def main():
    doc_text = (HERE / "sample_doc.md").read_text(encoding="utf-8")
    chunks = chunk_by_heading(doc_text)
    print(f"[索引] 文档切成 {len(chunks)} 个 chunks")

    # ★ 关键：一次 batch 调用，把所有 chunks 都向量化
    print(f"[索引] 调 embedding API，model={EMBEDDING_MODEL}...")
    chunk_vectors = embed(chunks)
    print(f"[索引] 完成，每个向量 {len(chunk_vectors[0])} 维\n")

    # ★ 故意挑了一些"语义近义"问题，与 ch01 直接对比
    questions = [
        "公司在哪儿？",                          # "在哪儿" vs "总部位于"
        "你们卖的 vegan 选项有哪些？",           # "vegan" vs "植物基"
        "小麦粉是从哪里来的？",                  # "从哪里来" vs "原料采购"
        "想退货可以吗？",                        # "退货" vs "退换"
        "你们能去新疆送货吗？",                  # 用对照 ch00/ch01
    ]

    for i, q in enumerate(questions, 1):
        print(f"=== 问题 {i}: {q} ===")
        # 用户的提问也要先 embed 成向量
        qv = embed([q])[0]
        top = retrieve(qv, chunk_vectors, chunks, k=3)
        print(f"[检索] top-3 片段:")
        for idx, score, text in top:
            head = text.split("\n", 1)[0]
            print(f"  - 第{idx}块 (cos={score:.3f}) {head[:50]}")
        answer = ask_with_rag(q, top)
        print(f"AI: {answer}\n")


if __name__ == "__main__":
    main()
