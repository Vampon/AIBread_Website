"""
第 0 章 · 无 RAG 基线 —— 暴力把全文塞 prompt
==============================================

RAG 是为了解决什么问题？最好的理解办法就是先看"不用 RAG 怎么办"。

最朴素的做法：把整篇文档塞进 system prompt，然后让 LLM 看着这堆原文回答。
我们这一章就这么干，让你体会两件事：

  1. 这种做法**确实能 work**（小文档场景下完全可用）
  2. 它的局限**也很直白**——文档一长就崩

文档变长会发生什么？
  - 上下文窗口可能装不下（很多模型只有 8K~128K 上限）
  - 每次调 API 都把整本"宪法"重发一遍，**很贵**
  - 不相关的内容也喂给模型，**回答质量下降**

后面 ch01 开始我们才引入"先检索后生成"的 RAG 思路。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")
load_dotenv(HERE.parent.parent / "bread-agent" / ".env")  # 兜底

client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


def ask(question: str, full_document: str) -> str:
    """把整篇文档塞 system prompt，让 LLM 看着它回答。"""
    messages = [
        {"role": "system", "content":
            f"你是 Bread 面包工坊的客服助理。请基于下面的内部知识库内容回答用户问题。"
            f"如果答案不在知识库里，必须明确说『知识库里没有相关信息』，不要瞎编。\n\n"
            f"========== 知识库开始 ==========\n{full_document}\n========== 知识库结束 =========="},
        {"role": "user", "content": question},
    ]
    resp = client.chat.completions.create(model=MODEL, messages=messages)
    return resp.choices[0].message.content


def main():
    # 加载示例文档（同目录的 sample_doc.md）
    doc_text = (HERE / "sample_doc.md").read_text(encoding="utf-8")

    print(f"[信息] 文档长度: {len(doc_text)} 字符 (~{len(doc_text)//2} tokens)")
    print(f"[信息] 这些字符**每次提问都会被发给模型** —— 这就是无 RAG 的代价\n")

    # 几个不同类型的问题，演示"无 RAG"的能力边界
    questions = [
        "你们公司哪一年成立的？",                   # 简单事实
        "加盟费是多少？培训要多久？",               # 跨段落
        "Bread 面包工坊 2026 年 7 月会推什么新品？", # 在文档里有
        "你们的吐司用什么面粉？黄油是哪个牌子？",   # 跨段落组合
        "你们能去新疆送货吗？",                     # 文档没说，看模型会不会编
    ]

    for i, q in enumerate(questions, 1):
        print(f"=== 问题 {i}: {q} ===")
        answer = ask(q, doc_text)
        print(f"AI: {answer}\n")


if __name__ == "__main__":
    main()
