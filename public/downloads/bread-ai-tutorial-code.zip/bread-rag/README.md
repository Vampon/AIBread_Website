# Bread RAG · 从零搭建检索增强生成系统

> 知识星球付费课程 · Bread 系列第三部
> 6 章 · 约 500 行 · 纯 Python · 完全不会编程也能跟着做 · 不依赖任何 RAG 框架

---

## 这门课在讲什么

**RAG（Retrieval-Augmented Generation，检索增强生成）** 是 2025-2026 年企业最常用的 AI 落地范式。简单说：

> 把你的文档 → 切块 → 向量化 → 存进库 → 用户提问时先从库里**检索**最相关的片段 → 拼进 prompt 给 LLM 回答。

为什么需要它？因为 LLM 本身有两个天生短板：

1. **不知道你公司的内部资料**（训练数据只到去年某月，没见过你的产品手册）
2. **塞进 prompt 的内容有限**（10 万字的文档无法整段喂给模型）

RAG 解决了这两件事——并且不需要微调模型。

读完本课程，你会用 ~500 行 Python 手写一个**功能丰富**但**构建极简**的 RAG 系统：

- 文档切块、向量化、存检索 —— RAG 的全部 3 大步
- 看穿"什么时候用 RAG、什么时候不用"
- 看穿"为什么语义检索 > 字面匹配"
- 看穿"为什么 hybrid（BM25 + 向量）> 单一检索"
- **接入 Bread Agent**，让它变成一个知识库问答 agent

不依赖 LangChain / LlamaIndex / Chroma / FAISS——**手撕底层**才是这门课的核心。

---

## 跟前两门课的关系

| | Bread Agent | Bread MCP | Bread RAG |
|---|---|---|---|
| 解决的问题 | agent 内核 | 工具协议化 | **知识库问答** |
| 推荐学习顺序 | 先学 | 第二 | 第三（ch05 接 agent） |
| 是否依赖前作 | ❌ 独立 | ⚠️ ch04 接 agent | ⚠️ ch05 接 agent |
| 行数 | ~540 | ~480 | ~500 |

如果你还没学 Bread Agent，**强烈建议先去学**——本课程的最后一章会无缝把它们串起来。

---

# 第一部分：零基础准备（5 分钟）

> 已经做过 Bread Agent / Bread MCP 的同学跳过——环境完全复用。

## 1. Python 3.10+

参见 Bread Agent README。

## 2. 进入仓库

```
cd D:\Project\bread-rag        # Windows
cd ~/Downloads/bread-rag       # macOS/Linux
```

## 3. 装依赖

```
pip install -r requirements.txt
```

只有 `openai` + `python-dotenv`。

## 4. 配置 .env

**ch00 / ch01 不需要**任何 API key（纯演示）。**ch02 起**需要：
- 一个 chat 模型（DeepSeek / 火山引擎 / OpenAI 都行）
- 一个 embedding 模型（用于把文本转向量）

参考 `.env.example`。如果你做过 Bread Agent，最简单：

```bash
# 复制 bread-agent 的 .env 过来
cp ../bread-agent/.env .env
```

然后**追加** embedding 相关三行（如果你用火山引擎）：

```
EMBEDDING_API_KEY=<同上面那个 key>
EMBEDDING_BASE_URL=https://ark.cn-beijing.volces.com/api/v3
EMBEDDING_MODEL=doubao-embedding-text-240715
```

注意：火山引擎的 coding plan 入口（`/api/coding/v3`）**没有** embedding，需要切到标准入口（`/api/v3`）。同一个 key 应该可以两边都用。

## 5. 第一次运行

```
cd ch00_baseline
python main.py
```

---

# 第二部分：课程地图

| 章 | 文件夹 | 你会学到 | 行数 |
|---|---|---|---:|
| 0 | `ch00_baseline/` | 无 RAG 的痛点：长文档塞 prompt 又贵又有限 | ~50 |
| 1 | `ch01_bow/` | 切块 + 词袋向量 + 余弦相似度（**手写检索**） | ~150 |
| 2 | `ch02_embeddings/` | 真 embedding API：**语义** vs 字面 | ~200 |
| 3 | `ch03_persist/` | 多文档、增量索引、pickle 持久化 | ~280 |
| 4 | `ch04_hybrid/` | BM25 + 向量 hybrid 检索 + rerank | ~380 |
| 5 | `ch05_with_agent/` | **接入 Bread Agent**，RAG 变成 agent 的工具 | ~480 |

每章 README 五段式（故事 → 跑起来 → 逐行精讲 → FAQ → 思考题），跟前两课同款。

---

## 怎么学每一章

**最高效的方法是看 diff**——把当前章和上一章对比看，你会很直观地看到"RAG 系统是从一个简单的字符串匹配慢慢长出来的"。

每章 30-60 分钟。读 README + 跑代码 + 做 3 道思考题。**不动手等于白学**。

---

# 附录

## 课程刻意没教的

- **专业向量数据库**（Chroma / Qdrant / Milvus）—— 学完本课你可以无缝迁移过去
- **GraphRAG / 知识图谱** —— 进阶话题
- **多模态 RAG**（图片、表格、PDF 解析）—— ch04 思考题里有方向
- **Agentic RAG**（让 agent 自己决定要不要检索）—— ch05 思考题里有方向
- **私有部署 embedding 模型** —— bge / e5 等开源模型本地跑

学完本课，这些主题你看官方文档就能上手。

## 致谢

参考实践：
- LlamaIndex / LangChain 的 RAG pipeline 设计
- 上一部 [Bread MCP](../bread-mcp/) 的工程化骨架
- 上上部 [Bread Agent](../bread-agent/) 的 agent 循环

—— Bread RAG 课程 · 知识星球
