"""
第 4 章 · Hybrid 检索 + LLM Rerank
==================================

3 路检索一起跑，对同一组问题做对比，让你**亲眼看见**：
  - 向量检索擅长什么、不擅长什么
  - BM25 擅长什么、不擅长什么
  - hybrid + rerank 怎么把两者优势合并
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

from rag import RAGIndex, llm_rerank

chat_client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
CHAT_MODEL = os.environ["MODEL"]

embedding_client = OpenAI(
    api_key=os.environ.get("EMBEDDING_API_KEY") or os.environ["OPENAI_API_KEY"],
    base_url=os.environ.get("EMBEDDING_BASE_URL") or os.environ["OPENAI_BASE_URL"],
)
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-m3")


INDEX_PATH = HERE / "index.pkl"


def build_or_load_index() -> RAGIndex:
    if INDEX_PATH.exists():
        idx = RAGIndex.load(INDEX_PATH, embedding_client=embedding_client)
        print(f"[索引] 从 {INDEX_PATH.name} 加载了 {len(idx.chunks)} 个 chunks")
        return idx
    print("[索引] 没找到 pkl，从 docs/ 新建...")
    idx = RAGIndex(embedding_client=embedding_client, embedding_model=EMBEDDING_MODEL)
    idx.add_documents(sorted((HERE / "docs").glob("*.md")))
    idx.save(INDEX_PATH)
    return idx


def show_hits(label: str, idx: RAGIndex, indices: list[int], scores: list[float] | None = None):
    print(f"  [{label}]")
    if not indices:
        print(f"    (无命中)")
        return
    for rank, i in enumerate(indices):
        c = idx.chunks[i]
        head = c.text.split("\n", 1)[0]
        score = f" score={scores[rank]:.3f}" if scores else ""
        print(f"    #{rank+1} [{c.source}] (chunk {i}){score} {head[:50]}")


def ask_with_rag(question: str, chunks_to_show: list, idx: RAGIndex) -> str:
    blocks = []
    for i, c in enumerate(chunks_to_show, 1):
        blocks.append(f"--- 片段 {i} [{c.source}] ---\n{c.text}")
    context = "\n\n".join(blocks)
    messages = [
        {"role": "system", "content":
            "你是 Bread 面包工坊的客服。基于下面检索到的片段回答用户。"
            "回答时引用来源文件名。如片段里没有答案，必须说『知识库里没有相关信息』。\n\n"
            f"========== 检索到的相关片段 ==========\n{context}\n========== 片段结束 =========="},
        {"role": "user", "content": question},
    ]
    resp = chat_client.chat.completions.create(model=CHAT_MODEL, messages=messages)
    return resp.choices[0].message.content


def main():
    idx = build_or_load_index()

    questions = [
        ("BW-20260301-0042 这个订单退款时要注意什么？", "考验编号检索：BM25 强"),
        ("你们卖的 vegan 选项有哪些？", "考验语义近义：向量强"),
        ("员工面包福利是怎样的？", "考验组合：BM25 抓'福利' + 向量抓'员工'"),
        ("我能从太原下单冷链配送吗？", "考验语义否定：向量抓'门店自提'"),
    ]

    for i, (q, hint) in enumerate(questions, 1):
        print(f"\n{'='*70}\n问题 {i}: {q}  ({hint})\n{'='*70}")

        # 3 路检索，并排展示
        vec_top = idx.search_vector(q, k=5)
        show_hits("向量检索 top-5", idx, vec_top)

        bm25_top = idx.search_bm25(q, k=5)
        show_hits("BM25 检索 top-5", idx, bm25_top)

        hybrid = idx.search_hybrid(q, k=5, fetch_k=8)
        hybrid_idxs = [x[0] for x in hybrid]
        hybrid_scores = [x[1] for x in hybrid]
        show_hits("Hybrid (RRF) top-5", idx, hybrid_idxs, hybrid_scores)

        # rerank：从 hybrid top-5 里选 final_k=3
        candidates = [idx.chunks[i] for i in hybrid_idxs]
        rerank_picks = llm_rerank(chat_client, CHAT_MODEL, q, candidates, final_k=3)
        reranked_chunks = [candidates[p] for p in rerank_picks]
        reranked_indices = [hybrid_idxs[p] for p in rerank_picks]
        show_hits("LLM 重排 final top-3", idx, reranked_indices)

        answer = ask_with_rag(q, reranked_chunks, idx)
        print(f"\nAI: {answer}")


if __name__ == "__main__":
    main()
