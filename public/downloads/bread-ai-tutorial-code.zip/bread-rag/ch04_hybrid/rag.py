"""
RAG 索引（hybrid 检索版）
=========================

ch03 只用向量检索。这一章我们引入：

  1. BM25 检索 —— 经典的"字面+词频"模型，对**专有名词、编号、英文术语**很在行
  2. 向量检索 —— 对**语义近义**在行（ch02-ch03 用的）
  3. Hybrid 融合 —— 用 RRF (Reciprocal Rank Fusion) 把两路结果合并
  4. LLM rerank —— 用 LLM 当裁判，对融合后的 top-K 复评一次

为什么需要 hybrid？
  用户问 "BW-20260301-0042 是谁的订单" → 向量检索抓不准这种编号
  用户问 "vegan 选项有什么"            → BM25 抓不到"植物基"
两个都要，才能兜底各种场景。
"""

import math
import os
import pickle
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from openai import OpenAI


@dataclass
class Chunk:
    text: str
    source: str
    vector: list[float] = field(default_factory=list)


# ============================================================
# 切块（沿用 ch03）
# ============================================================
def chunk_by_heading(text: str, source: str) -> list[Chunk]:
    parts = re.split(r"\n(?=## )", text)
    return [Chunk(text=p.strip(), source=source) for p in parts if p.strip()]


# ============================================================
# 分词（沿用 ch01）
# ============================================================
STOPWORDS = set("的了是在和与或对从把被给为有无及其之上下这那一二三四五六七八九十、，。：；？！（）《》「」 \n\r\t")


def tokenize(text: str) -> list[str]:
    tokens = []
    for w in re.findall(r"[a-zA-Z0-9\-]+", text):  # 英文/数字/带短横（编号）
        tokens.append(w.lower())
    for ch in text:
        if "一" <= ch <= "鿿":
            tokens.append(ch)
    return [t for t in tokens if t not in STOPWORDS]


# ============================================================
# 余弦
# ============================================================
def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


# ============================================================
# ★ BM25 检索
#
# BM25 公式（简化版）：
#   score(D, Q) = ∑ IDF(qi) · (tf(qi, D) · (k1+1))
#                              / (tf(qi, D) + k1 · (1 - b + b · |D|/avgDL))
#
# 直观理解：
#   - 出现越多次的词得分高（但有边际递减——k1 控制）
#   - 罕见词（IDF 大）得分高
#   - 长 chunk 会被惩罚（|D|/avgDL > 1 时分母变大）
#
# 我们的实现是教学版——没用 rank_bm25 库，全手写。
# ============================================================
class BM25:
    def __init__(self, corpus_tokens: list[list[str]], k1: float = 1.5, b: float = 0.75):
        self.corpus = corpus_tokens
        self.k1 = k1
        self.b = b
        self.N = len(corpus_tokens)
        self.avg_dl = sum(len(d) for d in corpus_tokens) / self.N if self.N else 0

        # idf 计算
        df: Counter = Counter()
        for doc in corpus_tokens:
            for term in set(doc):
                df[term] += 1
        self.idf = {term: math.log((self.N - n + 0.5) / (n + 0.5) + 1) for term, n in df.items()}

        # 预算 tf
        self.tfs = [Counter(doc) for doc in corpus_tokens]
        self.doc_lens = [len(d) for d in corpus_tokens]

    def score(self, query_tokens: list[str]) -> list[float]:
        scores = [0.0] * self.N
        for i in range(self.N):
            tf = self.tfs[i]
            dl = self.doc_lens[i]
            s = 0.0
            for q in query_tokens:
                if q not in tf:
                    continue
                idf = self.idf.get(q, 0.0)
                numer = tf[q] * (self.k1 + 1)
                denom = tf[q] + self.k1 * (1 - self.b + self.b * dl / self.avg_dl)
                s += idf * numer / denom
            scores[i] = s
        return scores


# ============================================================
# ★ RRF 融合
#
# Reciprocal Rank Fusion —— 一句话：每个排名列表里第 r 名得分 = 1/(k+r)，加起来。
# 关键好处：**完全跳过原始分数尺度问题**（BM25 vs cosine 范围天差地别）。
# 工业界（如 Elasticsearch）的 hybrid 默认就是 RRF。
# ============================================================
def rrf_fuse(rankings: list[list[int]], k: int = 60) -> list[tuple[int, float]]:
    """rankings: list of "排序好的 chunk index 列表"。返回 [(chunk_idx, score)] 排序后。"""
    scores: dict[int, float] = {}
    for ranking in rankings:
        for rank, idx in enumerate(ranking):
            scores[idx] = scores.get(idx, 0.0) + 1.0 / (k + rank + 1)  # rank 从 0 开始所以 +1
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


# ============================================================
# RAGIndex —— 在 ch03 基础上加 BM25 + hybrid
# ============================================================
class RAGIndex:
    def __init__(self, embedding_client: OpenAI, embedding_model: str):
        self.embedding_client = embedding_client
        self.embedding_model = embedding_model
        self.chunks: list[Chunk] = []
        self._bm25: BM25 | None = None
        self._tokenized: list[list[str]] = []

    def add_documents(self, paths: list[Path]):
        new_chunks: list[Chunk] = []
        for p in paths:
            text = Path(p).read_text(encoding="utf-8")
            new_chunks.extend(chunk_by_heading(text, source=p.name))

        if not new_chunks:
            return

        # vector embed
        texts = [c.text for c in new_chunks]
        vectors = self._embed_batch(texts)
        for c, v in zip(new_chunks, vectors):
            c.vector = v

        self.chunks.extend(new_chunks)
        # 重建 BM25（每次入库都重建——简单可靠）
        self._tokenized = [tokenize(c.text) for c in self.chunks]
        self._bm25 = BM25(self._tokenized)
        print(f"[索引] 新增 {len(new_chunks)} 个 chunks，索引总量 {len(self.chunks)}")

    def _embed_batch(self, texts: list[str], batch_size: int = 32) -> list[list[float]]:
        out = []
        for i in range(0, len(texts), batch_size):
            resp = self.embedding_client.embeddings.create(
                model=self.embedding_model, input=texts[i:i + batch_size],
            )
            out.extend(d.embedding for d in resp.data)
        return out

    # -------- 各种检索 --------
    def search_vector(self, query: str, k: int = 5) -> list[int]:
        if not self.chunks:
            return []
        qv = self._embed_batch([query])[0]
        scored = [(cosine(qv, c.vector), i) for i, c in enumerate(self.chunks)]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [i for _, i in scored[:k]]

    def search_bm25(self, query: str, k: int = 5) -> list[int]:
        if not self.chunks or self._bm25 is None:
            return []
        q_tokens = tokenize(query)
        scores = self._bm25.score(q_tokens)
        indexed = list(enumerate(scores))
        indexed.sort(key=lambda x: x[1], reverse=True)
        return [i for i, s in indexed[:k] if s > 0]

    def search_hybrid(self, query: str, k: int = 5, fetch_k: int = 10) -> list[tuple[int, float]]:
        """先各取 fetch_k，RRF 融合后返回 top-k。"""
        vec_top = self.search_vector(query, fetch_k)
        bm25_top = self.search_bm25(query, fetch_k)
        fused = rrf_fuse([vec_top, bm25_top])
        return fused[:k]

    # -------- 持久化 --------
    def save(self, path: Path):
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as f:
            pickle.dump({
                "embedding_model": self.embedding_model,
                "chunks": self.chunks,
            }, f)

    @classmethod
    def load(cls, path: Path, embedding_client: OpenAI) -> "RAGIndex":
        with Path(path).open("rb") as f:
            data = pickle.load(f)
        idx = cls(embedding_client=embedding_client, embedding_model=data["embedding_model"])
        idx.chunks = data["chunks"]
        idx._tokenized = [tokenize(c.text) for c in idx.chunks]
        idx._bm25 = BM25(idx._tokenized)
        return idx


# ============================================================
# ★ LLM rerank
#
# 检索的 top-K 还能再"复评"一遍——用 LLM 当裁判。
# 给它看 query 和 K 个候选，让它输出"哪几个真正相关、按相关度排"。
# 通常我们 retrieve 时多取一些（fetch_k=10），rerank 后保留 final_k=3。
# ============================================================
def llm_rerank(chat_client: OpenAI, model: str, query: str,
               candidates: list[Chunk], final_k: int = 3) -> list[int]:
    """返回 candidate 的索引列表，按相关度从高到低。失败时按原序返回。"""
    if not candidates:
        return []
    # 给候选编号，让 LLM 输出编号序列
    listing = "\n".join(f"[{i}] {c.text[:200]}" for i, c in enumerate(candidates))
    messages = [
        {"role": "system", "content":
            "你是一个搜索结果重排序专家。给定一个用户查询和若干候选片段，"
            f"你需要选出最多 {final_k} 个真正相关的候选，按相关度从高到低排列。\n"
            "输出格式：只输出选中的编号（逗号分隔），不要任何解释。例如：2,0,4"},
        {"role": "user", "content": f"查询: {query}\n\n候选片段:\n{listing}"},
    ]
    resp = chat_client.chat.completions.create(model=model, messages=messages, temperature=0)
    raw = resp.choices[0].message.content.strip()
    try:
        picks = [int(x.strip()) for x in re.findall(r"\d+", raw)]
        picks = [p for p in picks if 0 <= p < len(candidates)]
        # 去重保序
        seen = set(); out = []
        for p in picks:
            if p not in seen:
                out.append(p); seen.add(p)
            if len(out) >= final_k: break
        return out if out else list(range(min(final_k, len(candidates))))
    except Exception:
        return list(range(min(final_k, len(candidates))))
