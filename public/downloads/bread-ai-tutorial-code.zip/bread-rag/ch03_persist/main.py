"""
第 3 章 · 多文档 + 持久化索引
=============================

ch02 的索引在内存里。每次启动都要把所有 chunks 重新 embed 一遍——
慢、费钱、伸缩性差。

这一章我们做 4 件事：
  1. 多文档入库（docs/ 目录下的所有 .md 一起进库）
  2. 增量入库（同一索引可以多次 add_documents）
  3. pickle 持久化（save / load，下次启动直接读盘）
  4. 把整个流程封装成 class RAGIndex（rag.py）

跑两次 main.py：
  - 第 1 次：从零建库 → save 到 index.pkl
  - 第 2 次：load index.pkl → 直接检索（不再调 embedding API）
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

from rag import RAGIndex

# 对话用
chat_client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
CHAT_MODEL = os.environ["MODEL"]

# embedding 用
embedding_client = OpenAI(
    api_key=os.environ.get("EMBEDDING_API_KEY") or os.environ["OPENAI_API_KEY"],
    base_url=os.environ.get("EMBEDDING_BASE_URL") or os.environ["OPENAI_BASE_URL"],
)
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-m3")


INDEX_PATH = HERE / "index.pkl"


def ask_with_rag(question: str, top: list) -> str:
    """top 是 [(score, Chunk), ...]"""
    blocks = []
    for i, (score, c) in enumerate(top, 1):
        blocks.append(f"--- 片段 {i} [{c.source}] (相似度 {score:.3f}) ---\n{c.text}")
    context = "\n\n".join(blocks)

    messages = [
        {"role": "system", "content":
            "你是 Bread 面包工坊的客服助理。基于下面检索到的知识库片段回答用户问题。"
            "回答时引用来源文件名。如片段里没答案，必须说『知识库里没有相关信息』，不要瞎编。\n\n"
            f"========== 检索到的相关片段 ==========\n{context}\n========== 片段结束 =========="},
        {"role": "user", "content": question},
    ]
    resp = chat_client.chat.completions.create(model=CHAT_MODEL, messages=messages)
    return resp.choices[0].message.content


def build_or_load_index() -> RAGIndex:
    """有 index.pkl 就 load，否则从 docs/ 目录建一遍。"""
    if INDEX_PATH.exists():
        return RAGIndex.load(INDEX_PATH, embedding_client=embedding_client)

    print("[索引] 没找到 index.pkl，从 docs/ 目录新建...")
    idx = RAGIndex(embedding_client=embedding_client, embedding_model=EMBEDDING_MODEL)
    doc_paths = sorted((HERE / "docs").glob("*.md"))
    idx.add_documents(doc_paths)
    idx.save(INDEX_PATH)
    return idx


def main():
    idx = build_or_load_index()

    questions = [
        "公司在哪儿？什么时候成立的？",       # bread_workshop
        "烘焙学徒月薪是多少？",                # hr_policy
        "Q3 要研发的 vegan 产品什么特点？",   # rd_roadmap
        "你们有什么新疆相关的原料合作？",     # 跨文档：rd_roadmap 提到藜麦合作社
        "试用期工资按什么比例发？",            # hr_policy
    ]

    for i, q in enumerate(questions, 1):
        print(f"\n=== 问题 {i}: {q} ===")
        top = idx.search(q, k=3)
        print(f"[检索] top-3 命中：")
        for score, c in top:
            head = c.text.split("\n", 1)[0]
            print(f"  - [{c.source}] (cos={score:.3f}) {head[:50]}")
        print(f"AI: {ask_with_rag(q, top)}")


if __name__ == "__main__":
    main()
