"""
RAG 索引（持久化版）
====================

把 ch02 的内存索引抽象成一个 class，加上：
  - 多文档入库（list of file paths）
  - 增量入库（同一份索引可以多次 add_docs）
  - pickle 持久化（save / load）
  - top-K 检索（K 可配）

这就是把"玩具索引"做成"工程组件"——后面 ch04/ch05 都会用这个类。
"""

import math
import os
import pickle
import re
from dataclasses import dataclass, field
from pathlib import Path

from openai import OpenAI


@dataclass
class Chunk:
    """一个 chunk 的元数据 + 内容 + 向量。"""
    text: str
    source: str            # 来自哪个文件，方便回答时引用
    vector: list[float] = field(default_factory=list)


# ============================================================
# 切块（从 ch02 搬过来稍微强化）
# ============================================================

def chunk_by_heading(text: str, source: str) -> list[Chunk]:
    """按 ## 标题切块，每块保留来源信息。"""
    parts = re.split(r"\n(?=## )", text)
    return [Chunk(text=p.strip(), source=source) for p in parts if p.strip()]


# ============================================================
# 余弦相似度
# ============================================================

def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


# ============================================================
# 索引类
# ============================================================

class RAGIndex:
    """简单的内存索引 + pickle 持久化。"""

    def __init__(self, embedding_client: OpenAI, embedding_model: str):
        self.embedding_client = embedding_client
        self.embedding_model = embedding_model
        self.chunks: list[Chunk] = []

    # -------- 入库 --------
    def add_documents(self, paths: list[Path]):
        """读一组文件、切块、批量 embed、追加到索引。支持增量调用。"""
        new_chunks: list[Chunk] = []
        for p in paths:
            text = Path(p).read_text(encoding="utf-8")
            new_chunks.extend(chunk_by_heading(text, source=str(p.name)))

        if not new_chunks:
            return

        # 批量 embed —— 一次 API 调用搞定全部 chunks
        texts = [c.text for c in new_chunks]
        vectors = self._embed_batch(texts)
        for c, v in zip(new_chunks, vectors):
            c.vector = v

        self.chunks.extend(new_chunks)
        print(f"[索引] 新增 {len(new_chunks)} 个 chunks，索引总量 {len(self.chunks)}")

    def _embed_batch(self, texts: list[str], batch_size: int = 32) -> list[list[float]]:
        """分批调 API（防止单次过大）。"""
        out = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            resp = self.embedding_client.embeddings.create(
                model=self.embedding_model, input=batch,
            )
            out.extend(d.embedding for d in resp.data)
        return out

    # -------- 检索 --------
    def search(self, query: str, k: int = 3) -> list[tuple[float, Chunk]]:
        if not self.chunks:
            return []
        qv = self._embed_batch([query])[0]
        scored = [(cosine(qv, c.vector), c) for c in self.chunks]
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[:k]

    # -------- 持久化 --------
    def save(self, path: Path):
        """用 pickle 把所有 chunks（含向量）写盘。"""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # 注意：不能 pickle OpenAI client，所以只存 chunks
        with path.open("wb") as f:
            pickle.dump({
                "embedding_model": self.embedding_model,
                "chunks": self.chunks,
            }, f)
        print(f"[索引] 已保存到 {path} ({path.stat().st_size // 1024} KB)")

    @classmethod
    def load(cls, path: Path, embedding_client: OpenAI) -> "RAGIndex":
        """从 pickle 读回索引。embedding_client 单独传（不在 pickle 里）。"""
        with Path(path).open("rb") as f:
            data = pickle.load(f)
        idx = cls(embedding_client=embedding_client,
                  embedding_model=data["embedding_model"])
        idx.chunks = data["chunks"]
        print(f"[索引] 从 {path} 加载了 {len(idx.chunks)} 个 chunks")
        return idx
