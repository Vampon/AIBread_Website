"""RAG 索引（hybrid 版，从 ch04 搬过来精简）。"""

import math
import os
import pickle
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from openai import OpenAI


@dataclass
class Chunk:
    text: str
    source: str
    vector: list[float] = field(default_factory=list)


STOPWORDS = set("的了是在和与或对从把被给为有无及其之上下这那一二三四五六七八九十、，。：；？！（）《》「」 \n\r\t")


def tokenize(text: str) -> list[str]:
    tokens = []
    for w in re.findall(r"[a-zA-Z0-9\-]+", text):
        tokens.append(w.lower())
    for ch in text:
        if "一" <= ch <= "鿿":
            tokens.append(ch)
    return [t for t in tokens if t not in STOPWORDS]


def chunk_by_heading(text: str, source: str) -> list[Chunk]:
    parts = re.split(r"\n(?=## )", text)
    return [Chunk(text=p.strip(), source=source) for p in parts if p.strip()]


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


class BM25:
    def __init__(self, corpus_tokens, k1=1.5, b=0.75):
        self.corpus, self.k1, self.b = corpus_tokens, k1, b
        self.N = len(corpus_tokens)
        self.avg_dl = sum(len(d) for d in corpus_tokens) / self.N if self.N else 0
        df = Counter()
        for doc in corpus_tokens:
            for term in set(doc):
                df[term] += 1
        self.idf = {t: math.log((self.N - n + 0.5) / (n + 0.5) + 1) for t, n in df.items()}
        self.tfs = [Counter(d) for d in corpus_tokens]
        self.doc_lens = [len(d) for d in corpus_tokens]

    def score(self, query_tokens):
        scores = [0.0] * self.N
        for i in range(self.N):
            tf, dl = self.tfs[i], self.doc_lens[i]
            for q in query_tokens:
                if q not in tf: continue
                idf = self.idf.get(q, 0.0)
                numer = tf[q] * (self.k1 + 1)
                denom = tf[q] + self.k1 * (1 - self.b + self.b * dl / self.avg_dl)
                scores[i] += idf * numer / denom
        return scores


def rrf_fuse(rankings, k=60):
    scores = {}
    for ranking in rankings:
        for rank, idx in enumerate(ranking):
            scores[idx] = scores.get(idx, 0.0) + 1.0 / (k + rank + 1)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


class RAGIndex:
    def __init__(self, embedding_client: OpenAI, embedding_model: str):
        self.embedding_client = embedding_client
        self.embedding_model = embedding_model
        self.chunks: list[Chunk] = []
        self._bm25: BM25 | None = None

    def add_documents(self, paths):
        new_chunks = []
        for p in paths:
            text = Path(p).read_text(encoding="utf-8")
            new_chunks.extend(chunk_by_heading(text, source=p.name))
        if not new_chunks: return
        vectors = self._embed_batch([c.text for c in new_chunks])
        for c, v in zip(new_chunks, vectors):
            c.vector = v
        self.chunks.extend(new_chunks)
        self._bm25 = BM25([tokenize(c.text) for c in self.chunks])

    def _embed_batch(self, texts, batch_size=32):
        out = []
        for i in range(0, len(texts), batch_size):
            resp = self.embedding_client.embeddings.create(
                model=self.embedding_model, input=texts[i:i+batch_size]
            )
            out.extend(d.embedding for d in resp.data)
        return out

    def search_hybrid(self, query, k=3, fetch_k=8) -> list[tuple[float, Chunk]]:
        """高层 API：返回 [(score, Chunk), ...]——这就是给 agent 工具用的形态。"""
        if not self.chunks: return []
        # 向量
        qv = self._embed_batch([query])[0]
        vec_scored = [(cosine(qv, c.vector), i) for i, c in enumerate(self.chunks)]
        vec_scored.sort(key=lambda x: x[0], reverse=True)
        vec_top = [i for _, i in vec_scored[:fetch_k]]
        # BM25
        bm25_scores = self._bm25.score(tokenize(query)) if self._bm25 else []
        bm25_indexed = sorted(enumerate(bm25_scores), key=lambda x: x[1], reverse=True)
        bm25_top = [i for i, s in bm25_indexed[:fetch_k] if s > 0]
        # 融合
        fused = rrf_fuse([vec_top, bm25_top])
        return [(score, self.chunks[idx]) for idx, score in fused[:k]]

    def save(self, path):
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as f:
            pickle.dump({"embedding_model": self.embedding_model, "chunks": self.chunks}, f)

    @classmethod
    def load(cls, path, embedding_client):
        with Path(path).open("rb") as f:
            data = pickle.load(f)
        idx = cls(embedding_client=embedding_client, embedding_model=data["embedding_model"])
        idx.chunks = data["chunks"]
        idx._bm25 = BM25([tokenize(c.text) for c in idx.chunks])
        return idx
