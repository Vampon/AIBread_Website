"""
第 5 章 · RAG 接入 Bread Agent（终章）
======================================

agent 在多轮对话里自己决定"要不要查知识库"。

3 个对照场景：
  1. 闲聊（不该调 RAG）   → "你好"
  2. 业务问（应该调 RAG）  → "加盟费多少？"
  3. 跨段追问（应该再调）  → 上一问的延续："学徒呢？"
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")
load_dotenv(HERE.parent.parent / "bread-agent" / ".env")  # 兜底

from rag import RAGIndex
from agent import RAGAgent


def build_or_load_rag() -> RAGIndex:
    embedding_client = OpenAI(
        api_key=os.environ.get("EMBEDDING_API_KEY") or os.environ["OPENAI_API_KEY"],
        base_url=os.environ.get("EMBEDDING_BASE_URL") or os.environ["OPENAI_BASE_URL"],
    )
    embedding_model = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-m3")

    index_path = HERE / "index.pkl"
    if index_path.exists():
        idx = RAGIndex.load(index_path, embedding_client=embedding_client)
        print(f"[RAG] 从 {index_path.name} 加载了 {len(idx.chunks)} 个 chunks")
    else:
        print("[RAG] 没找到 pkl，从 docs/ 新建...")
        idx = RAGIndex(embedding_client=embedding_client, embedding_model=embedding_model)
        idx.add_documents(sorted((HERE / "docs").glob("*.md")))
        idx.save(index_path)
        print(f"[RAG] 已建库 {len(idx.chunks)} 个 chunks，存到 {index_path}")
    return idx


def main():
    rag = build_or_load_rag()

    chat_client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    agent = RAGAgent(chat_client, os.environ["MODEL"], rag)

    print("\nBread RAG-Agent · 知识库问答\n输入消息开始；Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break
        if not user_input:
            continue
        try:
            answer = agent.chat(user_input)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print(f"\nAI > {answer}\n")


if __name__ == "__main__":
    main()
