"""
RAG-Agent
=========

把 RAG 包装成 Bread Agent 的一个工具：search_knowledge_base。
LLM 在多轮对话里**自己决定**要不要查知识库。

这就是 "RAG + Agent" 的标配范式，工业界叫 **Agentic RAG**：
  - 简单问题（"你好"）→ agent 不调工具，直接回答
  - 复杂问题（"加盟费多少"）→ agent 调 search_knowledge_base，拿到结果再回答
  - 多轮追问 → agent 可以多次查、汇总
"""

import json
import os

from openai import OpenAI

from rag import RAGIndex


TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "search_knowledge_base",
            "description": (
                "在 Bread 面包工坊的内部知识库里检索相关信息。"
                "适用场景：用户问公司、产品、政策、HR、招聘等内部资料相关问题。"
                "返回 top-3 最相关的文档片段（含来源文件名和相似度分数）。"
                "**当用户问任何具体业务问题时，优先调此工具**，不要凭记忆回答。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "检索查询。把用户问题里的关键意图提炼成一句话即可。"
                    },
                },
                "required": ["query"],
            },
        },
    },
]


class RAGAgent:
    MAX_STEPS = 8

    def __init__(self, chat_client: OpenAI, chat_model: str, rag_index: RAGIndex):
        self.client = chat_client
        self.model = chat_model
        self.rag = rag_index
        self.messages = [{
            "role": "system",
            "content":
                "你是 Bread 面包工坊的客服助理。当用户问任何具体业务问题时，**必须**先用 "
                "search_knowledge_base 工具检索知识库，再基于检索结果回答；不要凭记忆/常识答业务问题。"
                "回答时引用来源（如：[bread_workshop.md]）。"
                "如果检索结果里没有答案，必须说『知识库里没有相关信息』，不要瞎编。"
        }]

    def _execute_tool(self, name: str, args: dict) -> str:
        """目前只有一个工具：search_knowledge_base。"""
        if name != "search_knowledge_base":
            return f"未知工具: {name}"
        query = args.get("query", "")
        if not query:
            return "查询为空"
        results = self.rag.search_hybrid(query, k=3)
        if not results:
            return "(无命中)"
        blocks = []
        for i, (score, c) in enumerate(results, 1):
            blocks.append(f"[{i}] 来源={c.source} 相似度={score:.3f}\n{c.text}")
        return "\n\n---\n\n".join(blocks)

    def chat(self, user_input: str) -> str:
        self.messages.append({"role": "user", "content": user_input})

        for step in range(self.MAX_STEPS):
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=TOOLS_SCHEMA,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)

            if not msg.tool_calls:
                return msg.content or ""

            for call in msg.tool_calls:
                name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    result = f"参数 JSON 解析失败: {e}"
                else:
                    print(f"  [step {step}] {name}(query={args.get('query', '')!r})")
                    result = self._execute_tool(name, args)
                    print(f"  [step {step}] -> 返回 {len(result)} chars")
                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": str(result),
                })

        return "[已达到最大步数]"
