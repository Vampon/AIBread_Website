"""
第 1 章 · 手写词袋检索 —— 切块 + BoW + 余弦相似度
=================================================

这是真正意义上的"第一个 RAG"。我们用最朴素的方法实现完整 pipeline：

  1. 切块（chunking）       —— 把长文档切成几十段
  2. 向量化（embedding）    —— 把每段变成一组数字（**这一章我们手写，不调任何 API**）
  3. 检索（retrieval）      —— 用户提问 → 找出 top-K 最相关的段
  4. 增强生成（generation） —— 把 top-K 拼进 prompt 让 LLM 看着回答

向量化我们用最朴素的"词袋（Bag of Words）"——把每段表达成"每个词出现几次"的频次向量。
相似度用余弦相似度。**全部用 Python 标准库**，零 ML 依赖。

跑完你会发现：这种"字面匹配"的 RAG 已经能解决一半问题。但它有明显短板：
  - 用户问"小麦粉来自哪？" → 文档说"原料采购" → BoW 算不出关联
  - 用户问"你们在哪儿？"  → 文档说"总部位于上海" → BoW 不知道"在哪儿"≈"位于"

ch02 引入真 embedding API 后才解决这类"语义"问题。
"""

import math
import os
import re
import sys
from collections import Counter
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")
load_dotenv(HERE.parent.parent / "bread-agent" / ".env")

client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


# ============================================================
# 1. 切块（chunking）
# ============================================================
#
# 简单策略：按 markdown 的二级标题 ## 切。每个章节就是一个 chunk。
# 真实场景里会更精细（按字数滑窗、按句子边界等），ch04 我们会做更好的。
# ============================================================

def chunk_by_heading(text: str) -> list[str]:
    """按 ## 标题切。每段保留它的标题作为上下文。"""
    parts = re.split(r"\n(?=## )", text)
    return [p.strip() for p in parts if p.strip()]


# ============================================================
# 2. 词袋向量化（Bag of Words）
# ============================================================
#
# 朴素思路：把"我爱吃面包"和"面包好吃"都变成"{'我':1,'爱':1,'吃':1,'面包':1}"
# 这种 dict 的形态。相似度用余弦：两个 dict 共同 key 的乘积 / 各自模长。
#
# 中文怎么切词？最简单：**按字切**（每个汉字一个 token）。
# 真实场景会用 jieba 或 BPE。本章用按字切，零依赖、效果其实不差。
# ============================================================

# 一些"停用词"——这些词太常见，不带信息量，去掉降噪
STOPWORDS = set("的了是在和与或与对从把被给为有无及其之上下这那一二三四五六七八九十、，。：；？！（）《》「」"
                " \n\r\t")


def tokenize(text: str) -> list[str]:
    """中文按字切 + 英文按词切。简单粗暴。"""
    tokens = []
    # 英文/数字单词
    for word in re.findall(r"[a-zA-Z0-9]+", text):
        tokens.append(word.lower())
    # 中文字
    for ch in text:
        if "一" <= ch <= "鿿":  # 是个汉字
            tokens.append(ch)
    return [t for t in tokens if t not in STOPWORDS]


def vectorize(text: str) -> Counter:
    """把文本变成 Counter（词 → 出现次数）。Counter 就是我们的"向量"。"""
    return Counter(tokenize(text))


# ============================================================
# 3. 余弦相似度
# ============================================================
#
# 公式：cos(A, B) = dot(A, B) / (|A| * |B|)
# 用 Counter 表达稀疏向量很自然——只算双方都有的词。
# ============================================================

def cosine_similarity(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    common_keys = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in common_keys)
    norm_a = math.sqrt(sum(v * v for v in a.values()))
    norm_b = math.sqrt(sum(v * v for v in b.values()))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# ============================================================
# 4. 检索：query → top-K 最相关的 chunks
# ============================================================

def retrieve(query: str, chunk_vectors: list[Counter], chunks: list[str], k: int = 3) -> list[tuple[int, float, str]]:
    """返回 [(chunk_index, score, chunk_text), ...]，按分数从高到低。"""
    qv = vectorize(query)
    scores = []
    for i, cv in enumerate(chunk_vectors):
        s = cosine_similarity(qv, cv)
        scores.append((i, s, chunks[i]))
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:k]


# ============================================================
# 5. 增强生成
# ============================================================

def ask_with_rag(question: str, retrieved: list[tuple[int, float, str]]) -> str:
    """把检索到的 top-K chunks 拼进 prompt，让 LLM 看着它们回答。"""
    context_blocks = []
    for i, (idx, score, text) in enumerate(retrieved, 1):
        context_blocks.append(f"--- 片段 {i} (相似度 {score:.3f}) ---\n{text}")
    context = "\n\n".join(context_blocks)

    messages = [
        {"role": "system", "content":
            "你是 Bread 面包工坊的客服助理。请基于下面检索到的知识库片段回答用户问题。"
            "如果片段里没有答案，必须明确说『知识库里没有相关信息』，不要瞎编。\n\n"
            f"========== 检索到的相关片段 ==========\n{context}\n========== 片段结束 =========="},
        {"role": "user", "content": question},
    ]
    resp = client.chat.completions.create(model=MODEL, messages=messages)
    return resp.choices[0].message.content


# ============================================================
# 主流程：构建索引 + 5 个问题对比
# ============================================================

def main():
    # 1) 加载文档 + 切块
    doc_text = (HERE / "sample_doc.md").read_text(encoding="utf-8")
    chunks = chunk_by_heading(doc_text)
    print(f"[索引] 文档切成 {len(chunks)} 个 chunks")

    # 2) 离线给每个 chunk 算 BoW 向量（这一步真实场景会持久化）
    chunk_vectors = [vectorize(c) for c in chunks]
    print(f"[索引] 平均每个 chunk {sum(len(v) for v in chunk_vectors)//len(chunks)} 个不同词")
    print()

    questions = [
        "你们公司哪一年成立的？",
        "加盟费是多少？培训要多久？",
        "Bread 面包工坊 2026 年 7 月会推什么新品？",
        "你们的吐司用什么面粉？黄油是哪个牌子？",
        "你们能去新疆送货吗？",
    ]

    for i, q in enumerate(questions, 1):
        print(f"=== 问题 {i}: {q} ===")
        top = retrieve(q, chunk_vectors, chunks, k=3)
        # 把"检索到了哪些片段、分数多少"显式打出来，让你看见这一步
        print(f"[检索] top-3 片段:")
        for idx, score, text in top:
            head = text.split("\n", 1)[0]  # 取首行作为片段标题
            print(f"  - 第{idx}块 (cos={score:.3f}) {head[:50]}")
        answer = ask_with_rag(q, top)
        print(f"AI: {answer}\n")


if __name__ == "__main__":
    main()
