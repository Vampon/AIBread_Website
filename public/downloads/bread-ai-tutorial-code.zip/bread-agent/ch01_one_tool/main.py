"""
第 1 章 · 第一次工具调用
========================

ch00 的 LLM 只能"说"，不能"做"。
这一章我们让它**第一次拿起工具**：当用户问"现在几点"时，模型不能瞎编一个时间，
它需要让我们的程序去查一下系统时间，然后把结果告诉它，它再用自然语言回答。

整个流程是这样的：
  第 1 步：messages 发给模型，附带"你可以用的工具清单 tools"
  第 2 步：模型如果决定用工具，会返回 tool_calls（而不是文本回答）
  第 3 步：我们的程序读 tool_calls，在本地真的执行那个函数
  第 4 步：把执行结果作为 role="tool" 的消息追加到 messages
  第 5 步：再调一次模型，这次它能基于工具结果给出最终回答

这一章故意 **不写 while 循环**。我们只做一次 round-trip，让你看清"两次请求"的形状。
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

# Windows 控制台 UTF-8（防中文/emoji 乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# 用绝对路径找仓库根目录的 .env，子目录运行也能读到
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


# ============================================================
# 1. 本地真实函数 —— 工具的"身体"
# ============================================================

def get_current_time() -> str:
    """返回当前系统时间字符串。"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================
# 2. 工具的 schema —— 工具的"说明书"
#
#    这个 dict 的格式是 OpenAI 官方规定的（DeepSeek/Qwen 等也都遵循）。
#    type/function/name/description/parameters 这些字段你**不能改名**。
#    parameters 内部是标准 JSON Schema。
# ============================================================

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "获取当前的系统时间。当用户询问现在几点、今天几号时调用。",
            "parameters": {
                "type": "object",
                "properties": {},  # 这个工具不需要任何参数
                "required": [],
            },
        },
    },
]

# 工具名 → Python 函数。模型只知道名字，我们靠这个 dict 找到真函数。
TOOLS_IMPL = {
    "get_current_time": get_current_time,
}


# ============================================================
# 3. 主流程：两次请求 + 一次工具执行
# ============================================================

def chat(user_input: str) -> str:
    messages = [
        {"role": "system", "content": "你是一个友好的中文助理，必要时使用工具。"},
        {"role": "user", "content": user_input},
    ]

    # === 第 1 次请求：让模型决定要不要用工具 ===
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        tools=TOOLS_SCHEMA,
    )
    assistant_msg = response.choices[0].message

    # 如果没有 tool_calls，说明模型直接回答了——这一章就结束了。
    if not assistant_msg.tool_calls:
        return assistant_msg.content

    # 把模型的"我想调工具"这条消息也加进 messages（这一步不能省，否则后续请求会报错）
    messages.append(assistant_msg)
    print(f"[messages] {messages}")

    # === 执行所有工具调用 ===
    # 模型可以一次发起多个 tool_calls，这里 for 循环挨个执行。
    for tool_call in assistant_msg.tool_calls:
        name = tool_call.function.name
        # 参数是 JSON 字符串，要解析。本例的 get_current_time 不需要参数，但姿势要规范。
        args = json.loads(tool_call.function.arguments or "{}")

        print(f"[工具调用] {name}({args})")
        result = TOOLS_IMPL[name](**args)
        print(f"[工具返回] {result}")

        # 把工具结果以 role="tool" 写回 messages。
        # tool_call_id 必须和上面 assistant 消息里的 id 对得上——这是配对凭据。
        messages.append({
            "role": "tool",
            "tool_call_id": tool_call.id,
            "content": str(result),
        })
    print(f"[messages] {messages}")
    # === 第 2 次请求：让模型基于工具结果生成最终自然语言回答 ===
    final = client.chat.completions.create(
        model=MODEL,
        messages=messages,
    )
    return final.choices[0].message.content


if __name__ == "__main__":
    reply = chat("现在几点了？")
    print("\n[最终回答]", reply)
