"""
会话持久化（JSONL）
====================

把 messages 一条一条写到 .jsonl 文件里，下次启动能加载回来继续聊。

为什么用 JSONL（一行一个 JSON）而不是整个 dump 成一个大 JSON？
    - 追加写不需要重新读+整段写，效率好
    - 文件被截断也能恢复大部分历史
    - 用 cat / head / tail 就能看
    - pi-main 的 session 也是这个思路

★★★ 关键工程坑（教学重点）★★★
OpenAI 协议要求：每一条 assistant 消息里的 tool_calls，
都必须有对应的 tool 消息紧跟着提供执行结果，且 tool_call_id 配对。
否则下一次发请求时会被 server 拒掉。

所以**绝不能**在"模型发起了 tool_calls，但工具还没执行完"的中间状态保存。
只能在"模型给出无 tool_calls 的 assistant 消息"这种**干净轮次边界**保存。

本模块提供两个 API：
    save_session(path, messages)  —— 整段覆写
    load_session(path)            —— 整段读回
都按 JSONL 一行一条消息。
"""

import json
from pathlib import Path

from typing import List

SESSIONS_DIR = Path("sessions")


def _session_path(name: str) -> Path:
    SESSIONS_DIR.mkdir(exist_ok=True)
    # 文件名做一点净化，避免路径穿越
    safe = "".join(c for c in name if c.isalnum() or c in ("-", "_"))
    if not safe:
        safe = "default"
    return SESSIONS_DIR / f"{safe}.jsonl"


def _message_to_dict(msg) -> dict:
    """
    OpenAI SDK 返回的 assistant 消息是个特殊对象，dict 是普通 dict。
    统一成"可 JSON 序列化的 dict"形态。
    """
    if isinstance(msg, dict):
        return msg
    # 是 SDK 的 ChatCompletionMessage —— 用 .model_dump() 转成 dict
    d = msg.model_dump(exclude_none=True)
    # model_dump 出来可能含 refusal/role 等字段；OpenAI 协议接受它们，原样保留即可
    return d


def save_session(name: str, messages: list) -> str:
    """把整个 messages 列表写到 sessions/<name>.jsonl，一条消息一行。"""
    path = _session_path(name)
    with path.open("w", encoding="utf-8") as f:
        for msg in messages:
            d = _message_to_dict(msg)
            f.write(json.dumps(d, ensure_ascii=False))
            f.write("\n")
    return str(path)


def load_session(name: str) -> list:
    """从 sessions/<name>.jsonl 读回 messages 列表。"""
    path = _session_path(name)
    if not path.exists():
        raise FileNotFoundError(f"会话不存在: {path}")
    messages = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            messages.append(json.loads(line))
    return messages


def list_sessions() -> List[str]:
    """列出 sessions/ 目录下所有可用会话名。"""
    if not SESSIONS_DIR.is_dir():
        return []
    return sorted(p.stem for p in SESSIONS_DIR.glob("*.jsonl"))


# ============================================================
# 干净轮次边界检测
# ============================================================

def is_clean_boundary(messages: list) -> bool:
    """
    判断 messages 列表当前是否处于"可以保存"的状态。

    规则：最后一条不是带 tool_calls 的 assistant。
    （如果最后一条是这种 assistant，意味着我们处在"工具还没回填"的中间状态，
     此时保存会破坏 tool_calls / tool 消息的配对。）
    """
    if not messages:
        return True
    last = _message_to_dict(messages[-1])
    if last.get("role") == "assistant" and last.get("tool_calls"):
        return False
    return True
