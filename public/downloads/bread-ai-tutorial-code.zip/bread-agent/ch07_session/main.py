"""
第 7 章 · 会话持久化（JSONL）
============================

我们的 agent 之前每次启动都是空白对话，关了就忘。
这一章加上 /save <name> 和 /load <name> 两个 slash 命令，
让对话能存到磁盘、下次启动还能继续。

底层是 JSONL：一行一条 message。代码本身简单，难点在工程坑——
**何时保存才安全**。详见 session.py 的 is_clean_boundary 说明。
"""

import sys
from pathlib import Path
from dotenv import load_dotenv

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from agent import Agent
from hooks import (
    Hooks,
    EVENT_BEFORE_TOOL,
    confirm_dangerous_tool, log_tool_calls,
)
from session import save_session, load_session, list_sessions, is_clean_boundary


def handle_slash_command(cmd: str, agent: Agent) -> bool:
    """处理 / 开头的命令。返回 True 表示已处理（不要交给 agent）。"""
    parts = cmd.strip().split(maxsplit=1)
    name = parts[0]
    arg = parts[1] if len(parts) > 1 else ""

    if name == "/save":
        if not arg:
            print("用法：/save <name>")
            return True
        msgs = agent.get_messages()
        if not is_clean_boundary(msgs):
            print("⚠ 当前处于中间状态（assistant 已发起工具调用但未回填），暂不能保存。")
            print("  请继续这一轮直到 agent 给出最终回答后再 /save。")
            return True
        path = save_session(arg, msgs)
        print(f"已保存 {len(msgs)} 条消息 → {path}")
        return True

    if name == "/load":
        if not arg:
            print("用法：/load <name>")
            print("可用会话：", ", ".join(list_sessions()) or "(无)")
            return True
        try:
            msgs = load_session(arg)
        except FileNotFoundError as e:
            print(e)
            return True
        agent.replace_messages(msgs)
        print(f"已加载 {len(msgs)} 条消息。")
        return True

    if name == "/list":
        sessions = list_sessions()
        print("可用会话：", ", ".join(sessions) if sessions else "(无)")
        return True

    if name == "/help":
        print("可用命令：")
        print("  /save <name>   保存当前会话")
        print("  /load <name>   加载已保存的会话")
        print("  /list          列出所有已保存会话")
        print("  /help          显示此帮助")
        return True

    if name.startswith("/"):
        print(f"未知命令：{name}（输入 /help 看支持的命令）")
        return True

    return False


def main():
    hooks = Hooks()
    hooks.register(EVENT_BEFORE_TOOL, confirm_dangerous_tool)
    hooks.register(EVENT_BEFORE_TOOL, log_tool_calls)

    agent = Agent(hooks=hooks)
    print("Bread Agent · v7（会话持久化）")
    print("Slash 命令：/save <name>  /load <name>  /list  /help")
    print("Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break
        if not user_input:
            continue

        # 先看是不是 slash 命令
        if user_input.startswith("/"):
            handle_slash_command(user_input, agent)
            print()
            continue

        try:
            agent.chat(user_input)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print()


if __name__ == "__main__":
    main()
