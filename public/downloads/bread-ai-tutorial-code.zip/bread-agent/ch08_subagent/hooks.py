"""Hooks 模块（跟 ch07 完全一致）。"""

from typing import Callable


EVENT_BEFORE_TOOL = "before_tool"
EVENT_AFTER_TOOL = "after_tool"
EVENT_ON_ASSISTANT = "on_assistant"


class Hooks:
    def __init__(self):
        self._handlers: dict[str, list[Callable]] = {}

    def register(self, event: str, handler: Callable):
        self._handlers.setdefault(event, []).append(handler)

    def emit(self, event: str, **payload) -> dict | None:
        for handler in self._handlers.get(event, []):
            ret = handler(**payload)
            if event == EVENT_BEFORE_TOOL and isinstance(ret, dict) and ret.get("block"):
                return ret
        return None


def confirm_dangerous_tool(tool_name: str, args: dict, **_):
    DANGEROUS = {"run_shell", "write_file"}
    if tool_name not in DANGEROUS:
        return None
    print(f"\n[!] Agent 想调用 {tool_name}({args})")
    answer = input("[!] 允许执行吗？(y/N): ").strip().lower()
    if answer != "y":
        return {"block": True, "reason": f"用户拒绝执行 {tool_name}。"}
    return None


def log_tool_calls(tool_name: str, args: dict, **_):
    print(f"  [hook:log] 即将调用 {tool_name} 参数={args}")
