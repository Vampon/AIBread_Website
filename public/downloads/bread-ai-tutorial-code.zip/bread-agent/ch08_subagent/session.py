"""会话持久化（跟 ch07 完全一致）。"""

import json
from pathlib import Path


SESSIONS_DIR = Path("sessions")


def _session_path(name: str) -> Path:
    SESSIONS_DIR.mkdir(exist_ok=True)
    safe = "".join(c for c in name if c.isalnum() or c in ("-", "_"))
    if not safe:
        safe = "default"
    return SESSIONS_DIR / f"{safe}.jsonl"


def _message_to_dict(msg) -> dict:
    if isinstance(msg, dict):
        return msg
    return msg.model_dump(exclude_none=True)


def save_session(name: str, messages: list) -> str:
    path = _session_path(name)
    with path.open("w", encoding="utf-8") as f:
        for msg in messages:
            f.write(json.dumps(_message_to_dict(msg), ensure_ascii=False))
            f.write("\n")
    return str(path)


def load_session(name: str) -> list:
    path = _session_path(name)
    if not path.exists():
        raise FileNotFoundError(f"会话不存在: {path}")
    messages = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                messages.append(json.loads(line))
    return messages


def list_sessions() -> list[str]:
    if not SESSIONS_DIR.is_dir():
        return []
    return sorted(p.stem for p in SESSIONS_DIR.glob("*.jsonl"))


def is_clean_boundary(messages: list) -> bool:
    if not messages:
        return True
    last = _message_to_dict(messages[-1])
    if last.get("role") == "assistant" and last.get("tool_calls"):
        return False
    return True
