"""
子 Agent
========

★ 本课程的最终概念：**把 agent 自己当成一个工具**。

主 agent 收到一个用户请求时，可能想把一部分脏活（例如"翻阅几十个文件找答案"）
外包给一个轻量子 agent 去做。子 agent 用同一套核心循环代码，但被赋予一个
**受限的工具集**——比如只能读、不能写、不能跑 shell。

工具集就是权限边界。** 这是本章最想灌输的思想。

实现非常直观：spawn_research_agent 内部就是再 new 一个 Agent，
传给它一个砍掉了 write_file/run_shell/spawn_research_agent 的工具集，
让它跑完一轮拿到 final answer 字符串返回。
"""

import json
import os
from datetime import date
from pathlib import Path

from openai import OpenAI

from tools import TOOLS_IMPL as _ALL_IMPL


# ============================================================
# 受限工具集：只让子 agent 用 read_file 和 list_dir
# ============================================================

SUB_TOOLS_SCHEMA = [
    {"type": "function", "function": {"name": "read_file",
        "description": "读取一个文本文件的内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "list_dir",
        "description": "列出目录下的文件和子目录。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": []}}},
]

SUB_TOOLS_IMPL = {
    "read_file": _ALL_IMPL["read_file"],
    "list_dir": _ALL_IMPL["list_dir"],
}


SUB_PERSONA = """你是一个只读调研子助手，专门帮主助手回答调研类问题。

工作风格：
- 你只能 read_file 和 list_dir，不要尝试任何其他工具
- 主动多读几个相关文件再下结论
- 用一段简短的中文报告回答主助手的问题（不超过 200 字）
- 不要询问主助手，自己拿主意
"""


# ============================================================
# 子 Agent 的工具调用循环（精简版，没有流式没有钩子）
# ============================================================

MAX_SUB_STEPS = 8


def spawn_research_agent(question: str) -> str:
    """
    主 agent 通过工具调用进来。返回子助手的调研报告字符串。
    """
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    cwd = str(Path.cwd())
    today = date.today().isoformat()

    tool_lines = [f"- {t['function']['name']}: {t['function']['description']}" for t in SUB_TOOLS_SCHEMA]
    system_prompt = f"""{SUB_PERSONA}
# 可用工具
{chr(10).join(tool_lines)}

# 上下文
当前工作目录: {cwd}
今天日期: {today}
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": question},
    ]

    print(f"\n  ┌─ [subagent] 开始调研: {question}")

    for step in range(MAX_SUB_STEPS):
        resp = client.chat.completions.create(
            model=model, messages=messages, tools=SUB_TOOLS_SCHEMA,
        )
        msg = resp.choices[0].message
        messages.append(msg)

        if not msg.tool_calls:
            answer = msg.content or "(子助手无返回)"
            print(f"  └─ [subagent] 调研完成 ({len(answer)} chars)\n")
            return answer

        for call in msg.tool_calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError as e:
                result = f"参数解析失败: {e}"
            else:
                print(f"  │ [subagent] {name}({args})")
                # ★ 这里做"工具集隔离"：即使子 agent 模型"幻觉"出 run_shell 这种工具，
                #    我们的 dict 里也没有它，会被这里挡住。
                if name not in SUB_TOOLS_IMPL:
                    result = f"子助手无权调用工具: {name}"
                else:
                    try:
                        result = str(SUB_TOOLS_IMPL[name](**args))
                    except Exception as e:
                        result = f"工具执行报错: {type(e).__name__}: {e}"
            messages.append({"role": "tool", "tool_call_id": call.id, "content": result})

    print("  └─ [subagent] 步数耗尽\n")
    return "[子助手在限定步数内未给出最终结论]"
