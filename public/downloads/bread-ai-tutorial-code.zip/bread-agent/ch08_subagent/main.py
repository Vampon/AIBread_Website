"""
第 8 章 · 子 Agent（终章）
==========================

本课程的最终概念：**把 agent 自己当成一个工具**。

主 agent 在 TOOLS_IMPL 里多了一项 spawn_research_agent。
当模型决定调它时，会启动一个**受限**子 agent（只能 read_file/list_dir），
让子 agent 跑完一轮拿到调研报告字符串，再以 tool 结果回填给主 agent。

工具集就是权限边界 —— 这是本章想灌输的核心思想。

启动顺序：
    1. 引入 subagent.spawn_research_agent
    2. 把它注入 tools.TOOLS_IMPL 字典 ★（避免循环 import 的关键）
    3. new Agent
"""

import sys
from pathlib import Path
from dotenv import load_dotenv

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# ★ 把子 agent 实现注入 TOOLS_IMPL。必须在 import Agent 之前完成。
from tools import TOOLS_IMPL
from subagent import spawn_research_agent
TOOLS_IMPL["spawn_research_agent"] = spawn_research_agent

from agent import Agent
from hooks import (
    Hooks,
    EVENT_BEFORE_TOOL,
    confirm_dangerous_tool, log_tool_calls,
)
from session import save_session, load_session, list_sessions, is_clean_boundary


def handle_slash_command(cmd: str, agent: Agent) -> bool:
    parts = cmd.strip().split(maxsplit=1)
    name = parts[0]
    arg = parts[1] if len(parts) > 1 else ""

    if name == "/save":
        if not arg:
            print("用法：/save <name>")
            return True
        msgs = agent.get_messages()
        if not is_clean_boundary(msgs):
            print("⚠ 当前处于中间状态，暂不能保存。")
            return True
        path = save_session(arg, msgs)
        print(f"已保存 {len(msgs)} 条消息 → {path}")
        return True

    if name == "/load":
        if not arg:
            print("用法：/load <name>")
            print("可用会话：", ", ".join(list_sessions()) or "(无)")
            return True
        try:
            msgs = load_session(arg)
        except FileNotFoundError as e:
            print(e)
            return True
        agent.replace_messages(msgs)
        print(f"已加载 {len(msgs)} 条消息。")
        return True

    if name == "/list":
        sessions = list_sessions()
        print("可用会话：", ", ".join(sessions) if sessions else "(无)")
        return True

    if name == "/help":
        print("可用命令：/save <name>  /load <name>  /list  /help")
        return True

    if name.startswith("/"):
        print(f"未知命令：{name}")
        return True
    return False


def main():
    hooks = Hooks()
    hooks.register(EVENT_BEFORE_TOOL, confirm_dangerous_tool)
    hooks.register(EVENT_BEFORE_TOOL, log_tool_calls)

    agent = Agent(hooks=hooks)
    print("Bread Agent · v8（终章：子 agent）")
    print("调研类问题主 agent 会派子助手处理。")
    print("Slash: /save  /load  /list  /help    Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！谢谢学完整门课程。")
            break
        if not user_input:
            continue
        if user_input.startswith("/"):
            handle_slash_command(user_input, agent)
            print()
            continue
        try:
            agent.chat(user_input)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print()


if __name__ == "__main__":
    main()
