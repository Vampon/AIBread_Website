"""
Agent 模块（主 agent，能调用子 agent）
======================================

跟 ch07 的差别：
    - 在 TOOLS_IMPL 里注入 spawn_research_agent（启动时由 main.py 完成）
    - 其余完全一致
"""

import json
import os
from datetime import date
from pathlib import Path

from openai import OpenAI

from tools import TOOLS_SCHEMA, TOOLS_IMPL
from hooks import Hooks, EVENT_BEFORE_TOOL, EVENT_AFTER_TOOL, EVENT_ON_ASSISTANT


DEFAULT_PERSONA = """你是 Bread Agent，一个能操作文件系统和 shell 的中文助理。
工作风格：
- 必要时调用工具
- 调研类问题（"分析这个项目结构"、"汇总几个文件的内容"）优先用 spawn_research_agent 派子助手去做，能省主上下文
- 执行危险命令前用户会被询问，被拒绝是正常情况，礼貌改口即可
- 简洁回答；长任务结束后用一句话总结你做了什么
"""


def build_system_prompt(tools_schema=TOOLS_SCHEMA, cwd=None, today=None, persona=DEFAULT_PERSONA):
    cwd = cwd or str(Path.cwd())
    today = today or date.today().isoformat()
    tool_lines = [f"- {t['function']['name']}: {t['function']['description']}" for t in tools_schema]
    return f"""{persona}
# 可用工具
{chr(10).join(tool_lines)}

# 上下文
当前工作目录: {cwd}
今天日期: {today}
"""


class Agent:
    MAX_STEPS = 10

    def __init__(self, hooks: Hooks | None = None):
        self.client = OpenAI(
            api_key=os.environ["OPENAI_API_KEY"],
            base_url=os.environ["OPENAI_BASE_URL"],
        )
        self.model = os.environ["MODEL"]
        self.hooks = hooks or Hooks()
        self.messages: list = [{"role": "system", "content": build_system_prompt()}]

    def get_messages(self) -> list:
        return self.messages

    def replace_messages(self, new_messages: list):
        self.messages = new_messages

    def _stream_one(self):
        stream = self.client.chat.completions.create(
            model=self.model, messages=self.messages, tools=TOOLS_SCHEMA, stream=True,
        )
        text = ""
        detected_tool = False
        for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            if delta.tool_calls:
                detected_tool = True
                for _ in stream:
                    pass
                break
            if delta.content:
                print(delta.content, end="", flush=True)
                text += delta.content
        if text:
            print()
        return text, detected_tool

    def _non_stream_one(self):
        resp = self.client.chat.completions.create(
            model=self.model, messages=self.messages, tools=TOOLS_SCHEMA,
        )
        return resp.choices[0].message

    def _execute_tool(self, call) -> str:
        name = call.function.name
        try:
            args = json.loads(call.function.arguments or "{}")
        except json.JSONDecodeError as e:
            return f"参数 JSON 解析失败: {e}"

        decision = self.hooks.emit(EVENT_BEFORE_TOOL, tool_name=name, args=args)
        if decision and decision.get("block"):
            reason = decision.get("reason", "工具调用被钩子拒绝。")
            print(f"  [blocked] {reason}")
            return reason

        if name not in TOOLS_IMPL:
            return f"未知工具: {name}"
        try:
            result = str(TOOLS_IMPL[name](**args))
        except Exception as e:
            result = f"工具执行报错: {type(e).__name__}: {e}"

        self.hooks.emit(EVENT_AFTER_TOOL, tool_name=name, args=args, result=result)
        return result

    def chat(self, user_input: str):
        self.messages.append({"role": "user", "content": user_input})

        for _ in range(self.MAX_STEPS):
            print("AI > ", end="", flush=True)
            text, has_tool = self._stream_one()

            if not has_tool:
                self.messages.append({"role": "assistant", "content": text})
                self.hooks.emit(EVENT_ON_ASSISTANT, content=text)
                return

            print("[切换到非流式模式获取工具调用...]")
            assistant_msg = self._non_stream_one()
            self.messages.append(assistant_msg)

            if not assistant_msg.tool_calls:
                print(assistant_msg.content or "")
                self.hooks.emit(EVENT_ON_ASSISTANT, content=assistant_msg.content or "")
                return

            for call in assistant_msg.tool_calls:
                result = self._execute_tool(call)
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": result,
                })

        print("[已达到最大步数，强行终止]")
