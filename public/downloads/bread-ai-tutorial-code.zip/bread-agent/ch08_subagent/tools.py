"""
工具模块（接入 subagent）
========================

主要变化：在 TOOLS_SCHEMA 和 TOOLS_IMPL 里**新增** spawn_research_agent。

spawn_research_agent 的实现放在 subagent.py 里（避免循环 import）。
这里只声明 schema 和占位，main.py 启动时会把实现注入进来。
"""

import subprocess
from pathlib import Path


# ============================================================
# 普通工具
# ============================================================

def read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {p} ({len(content)} chars)"


def list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def run_shell(command: str) -> str:
    try:
        proc = subprocess.run(command.split(), capture_output=True, text=True,
                              timeout=30, encoding="utf-8", errors="replace")
        out = (proc.stdout or "") + (proc.stderr or "")
        return out.strip() or f"(命令无输出，退出码 {proc.returncode})"
    except subprocess.TimeoutExpired:
        return "命令执行超时 (>30s)"
    except FileNotFoundError:
        return f"命令未找到: {command.split()[0]}"


# ============================================================
# 工具 schema —— 加入 spawn_research_agent
# ============================================================

TOOLS_SCHEMA = [
    {"type": "function", "function": {"name": "read_file",
        "description": "读取一个文本文件的内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "write_file",
        "description": "写入一个文本文件，会覆盖已有内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "list_dir",
        "description": "列出目录下的文件和子目录。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": []}}},
    {"type": "function", "function": {"name": "run_shell",
        "description": "执行一条 shell 命令（系统会请求用户确认）。",
        "parameters": {"type": "object",
            "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
    {"type": "function", "function": {"name": "spawn_research_agent",
        "description": (
            "派一个只读子助手去调研一个具体的问题（例如分析项目结构、汇总几个文件的内容）。"
            "子助手只能 read_file 和 list_dir，不能写盘也不能跑 shell。"
            "它会返回一段自然语言的调研报告。"
            "适合主助手需要把'脏活/费 token 的搜索'隔离出去的场合。"
        ),
        "parameters": {"type": "object",
            "properties": {
                "question": {"type": "string", "description": "要让子助手回答的具体问题"},
            },
            "required": ["question"]}}},
]

# 普通工具的实现注册。spawn_research_agent 由 main.py 启动时再注入（避免循环 import）。
TOOLS_IMPL = {
    "read_file": read_file,
    "write_file": write_file,
    "list_dir": list_dir,
    "run_shell": run_shell,
}
