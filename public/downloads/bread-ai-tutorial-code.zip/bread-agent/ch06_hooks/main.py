"""
第 6 章 · 事件钩子系统
======================

ch03 我们在 run_shell 工具内部 inline 了一段 input("y/N") 询问代码。
这一章我们把它**抽出去**——抽成一个叫 before_tool 的钩子。

抽完之后会发现一件神奇的事情：**新功能只需注册一个 hook 就能加**。
比如想给 write_file 也加上权限确认，不用动 write_file 代码——只要
把它加进 hooks.py 里 DANGEROUS 集合即可。

这就是 pi-main 的 beforeToolCall/afterToolCall hook 的思想，
只是 pi-main 用 TypeScript 强类型 + 异步 + 事件优先级，我们用极简同步实现。
"""

import sys
from pathlib import Path
from dotenv import load_dotenv

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from agent import Agent
from hooks import (
    Hooks,
    EVENT_BEFORE_TOOL, EVENT_ON_ASSISTANT,
    confirm_dangerous_tool, log_tool_calls, log_assistant_messages,
)


def main():
    # ★ 关键：在外部装配 hooks，再交给 Agent
    hooks = Hooks()
    hooks.register(EVENT_BEFORE_TOOL, log_tool_calls)  # 所有工具都日志
    hooks.register(EVENT_BEFORE_TOOL, confirm_dangerous_tool)     # 危险工具询问
    hooks.register(EVENT_ON_ASSISTANT, log_assistant_messages)     # 模型回答时日志

    agent = Agent(hooks=hooks)
    print("Bread Agent · v6（钩子化）")
    print("注：write_file 和 run_shell 是危险工具，调用前会询问。")
    print("输入消息开始对话；Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break
        if not user_input:
            continue
        try:
            agent.chat(user_input)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print()


if __name__ == "__main__":
    main()
