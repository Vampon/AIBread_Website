"""
工具模块
========

★ 跟 ch05 唯一的区别：run_shell **不再 inline 询问用户**。
权限确认在 ch06 被抽成了一个钩子，由 Agent 在工具执行前调用。
所以 run_shell 本身只负责"真的去执行"。
"""

import subprocess
from pathlib import Path


def read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {p} ({len(content)} chars)"


def list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def run_shell(command: str) -> str:
    """★ 注意：这里不再有 input() 询问。权限是 hook 的事，不是工具的事。"""
    try:
        proc = subprocess.run(command.split(), capture_output=True, text=True,
                              timeout=30, encoding="utf-8", errors="replace")
        out = (proc.stdout or "") + (proc.stderr or "")
        return out.strip() or f"(命令无输出，退出码 {proc.returncode})"
    except subprocess.TimeoutExpired:
        return "命令执行超时 (>30s)"
    except FileNotFoundError:
        return f"命令未找到: {command.split()[0]}"


TOOLS_SCHEMA = [
    {"type": "function", "function": {"name": "read_file",
        "description": "读取一个文本文件的内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "write_file",
        "description": "写入一个文本文件，会覆盖已有内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "list_dir",
        "description": "列出目录下的文件和子目录。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": []}}},
    {"type": "function", "function": {"name": "run_shell",
        "description": "执行一条 shell 命令（系统会请求用户确认）。",
        "parameters": {"type": "object",
            "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
]

TOOLS_IMPL = {
    "read_file": read_file,
    "write_file": write_file,
    "list_dir": list_dir,
    "run_shell": run_shell,
}
