"""
钩子（Hook）系统
================

什么是钩子？答：**事件 → 回调函数**的注册机制。

Agent 在它的执行过程中会经过几个关键节点：
    - on_user_message    用户刚输入完
    - before_tool        即将执行某个工具
    - after_tool         某个工具执行完
    - on_assistant       模型给出了最终自然语言回答

每一个节点都允许外部注册任意多个回调函数。Agent 在到达节点时把回调挨个调一遍。

这种设计带来两个好处：
1. **新功能不污染核心代码**——想加日志？写个 hook 注册上去就行，不用改 Agent。
2. **能"否决"工具执行**——`before_tool` 的回调可以返回 {"block": True, "reason": "..."}，
   Agent 看到就跳过工具的真实执行，把 reason 作为 tool 结果回喂模型。
   ch03 那个 inline 的"y/N 询问"在本章被重构成这种形态。

参考 pi-main agent-loop.ts:570-639 的 prepare/execute/finalize 三阶段。
我们做了大幅简化，但思想是同一个。
"""

from typing import Callable, Optional, List, Dict

# 支持的事件类型（约定俗成的字符串，便于和 pi-main 心智对齐）
EVENT_BEFORE_TOOL = "before_tool"     # 即将执行某个工具，可返回 {"block": True, "reason": "..."} 来阻止
EVENT_AFTER_TOOL = "after_tool"        # 某个工具执行完，可读取/修改结果
EVENT_ON_USER_MESSAGE = "on_user_msg"  # 用户刚输入
EVENT_ON_ASSISTANT = "on_assistant"    # 模型给出最终自然语言回答


class Hooks:
    """事件 → 回调列表的简单注册中心。"""

    def __init__(self):
        self._handlers: Dict[str, List[Callable]] = {}

    def register(self, event: str, handler: Callable):
        """注册一个回调到某个事件。同一事件可以注册多个回调，按注册顺序触发。"""
        self._handlers.setdefault(event, []).append(handler)

    def emit(self, event: str, **payload) -> Optional[dict]:
        """
        触发一个事件，把 payload 作为关键字参数传给每个回调。
        如果有任何一个 before_tool 回调返回 {"block": True, "reason": ...}，
        Agent 就能知道该工具被否决了——本函数把第一个 block 决议返回出去。

        其他事件类型不关心返回值。
        """
        for handler in self._handlers.get(event, []):
            ret = handler(**payload)
            if event == EVENT_BEFORE_TOOL and isinstance(ret, dict) and ret.get("block"):
                return ret
        return None


# ============================================================
# 几个内置 hook，main.py 会注册它们
# ============================================================

def confirm_dangerous_tool(tool_name: str, args: dict, **_):
    """before_tool hook：危险工具执行前问用户 y/N。"""
    DANGEROUS = {"run_shell", "write_file"}
    if tool_name not in DANGEROUS:
        return None  # 不是危险工具，放行
    print(f"\n[!] Agent 想调用 {tool_name}({args})")
    answer = input("[!] 允许执行吗？(y/N): ").strip().lower()
    if answer != "y":
        return {"block": True, "reason": f"用户拒绝执行 {tool_name}。"}
    return None  # 用户允许，放行


def log_tool_calls(tool_name: str, args: dict, **_):
    """before_tool hook：所有工具调用都打一行日志。"""
    print(f"  [hook:log] 即将调用 {tool_name} 参数={args}")


def log_assistant_messages(content: str, **_):
    """on_assistant hook：模型每次给出最终回答时记一笔。"""
    print(f"  [hook:log] 模型回答了 {len(content)} 个字符")
