# Bread Agent · 从零搭建你的智能体

> 知识星球付费课程配套代码仓库。
> 9 章 · 约 500 行 · 纯 Python · **完全不会编程也能跟着做** · 不依赖任何 agent 框架。

读完这门课，你会用纯 Python 手写一个**功能丰富**但**构建极简**的智能体（像 ChatGPT/Claude Code 那样的东西，但你完全理解它的每一行代码）。

## 你会学到什么

- 工具调用循环（agent loop）—— 智能体的灵魂
- 流式输出 —— 像 ChatGPT 一样打字
- 权限确认 —— 危险操作必须问过你
- 事件钩子 —— 给智能体加扩展点
- 系统提示词模板 —— prompt engineering 落到代码里
- 多轮 REPL 对话
- 会话持久化（JSONL）
- 子 agent —— 用 agent 调度 agent

参考项目是 `pi-main/`（一个用 TypeScript 写的工业级开源 agent，25+ 文件、上万行）。我把它的灵魂提炼出来，用 Python 重写到 **500 行以内**。

---

# 第一部分：零基础准备（30 分钟，做一次就好）

> 如果你已经会 Python、能用命令行、有 API Key，**跳过这部分**直接看下面"第二部分"。
> 否则一步一步跟着做，别跳。

## 0. 你需要一台什么样的电脑

- Windows / macOS / Linux 都行
- 大约 1GB 空闲硬盘
- 能上网（国外服务也能访问就更好，但本课程默认用国内 DeepSeek，普通宽带就够）

## 1. 安装 Python

Python 是一种编程语言（也是一个软件），运行我们的代码需要它。

### Windows 用户

1. 打开浏览器，访问 https://www.python.org/downloads/
2. 点首页那个大大的黄色按钮 "Download Python 3.12.x"（数字可能是 3.11/3.12/3.13，都行）
3. 下载完双击安装包打开
4. **★ 关键：勾选最下面的 "Add Python to PATH" 复选框**（很多人因为没勾这个走弯路）
5. 然后点 "Install Now"，等装完

如果你已经装过 Anaconda / Miniconda，也可以——课程兼容。

### macOS 用户

```bash
# 终端里执行（终端是 应用程序 → 实用工具 → 终端.app）
brew install python@3.12
```

如果没有 brew，先去 https://brew.sh 装一下。

### 验证安装成功

打开**终端**（Windows 上叫 "命令提示符" 或 "PowerShell"，macOS 上叫 "终端.app"，Linux 上叫 Terminal），输入：

```
python --version
```

回车，看到一行 `Python 3.x.x`（数字是 3.10 或更高）就说明装好了。

如果提示 "python 不是内部或外部命令"，就是 Windows 上没勾"Add to PATH"。回去重装一遍 Python，注意勾上那个复选框。

## 2. 下载本课程代码

如果你看到这个 README，说明你已经在 `bread-agent/` 文件夹里了。如果不是，去知识星球下载课程压缩包，解压到任意位置（路径里不要有中文最好），然后用终端 `cd` 进去：

```
# Windows 例子（在 PowerShell）
cd D:\Project\bread-agent

# macOS / Linux 例子
cd ~/Downloads/bread-agent
```

## 3. 安装课程依赖

本课程只用两个 Python 库：`openai`（调大模型）和 `python-dotenv`（读 .env 配置）。一句命令装完：

```
pip install -r requirements.txt
```

如果看到一大堆 `Successfully installed ...`，就是装好了。

如果提示 `pip 不是内部或外部命令`，试试 `python -m pip install -r requirements.txt`。

国内学员如果下载特别慢，加一个清华镜像：

```
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 4. 拿一个 LLM 的 API Key

**API Key 就是你调大模型的"密码 + 账号"**。

本课程**强烈推荐两个国内 provider**（任选其一）：

### 选项 A：DeepSeek

- 国内可直连，不需要 VPN
- 注册送 10 块钱额度，跑完整门课花不到 1 块钱
- 接口跟 OpenAI 完全兼容

注册：
1. 浏览器打开 https://platform.deepseek.com
2. 用手机号或邮箱注册并登录
3. 左侧菜单点 "API Keys" → "创建 API key"
4. **复制以 `sk-` 开头的那串字符**（只显示一次）

`.env` 配置：
```
OPENAI_API_KEY=sk-你的key
OPENAI_BASE_URL=https://api.deepseek.com
MODEL=deepseek-chat
```

### 选项 B：火山引擎 ark（GLM-5.1 等代码增强模型）

- 国内顶级速度
- 注册送较多额度
- coding plan 入口对工具调用很友好

注册：
1. 浏览器打开 https://console.volcengine.com/ark
2. 注册并登录
3. 控制台开通 "coding plan"，拿到 API Key
4. 复制 key（一长串带横杠的字符）

`.env` 配置：
```
OPENAI_API_KEY=你的key
OPENAI_BASE_URL=https://ark.cn-beijing.volces.com/api/coding/v3
MODEL=glm-5.1
```

## 5. 配置 .env 文件

`.env` 是一个文本文件，里面放"密码"之类的敏感信息。我们不想把 API Key 写在代码里（不安全），所以单独放这里。

在 `bread-agent/` 目录里：

1. 找到那个叫 `.env.example` 的文件
2. **复制一份，重命名成 `.env`**（前面那个点 `.` 是文件名的一部分，不要漏）
3. 用任意文本编辑器（记事本、VS Code、Notepad++ 都行）打开 `.env`
4. 找到 `OPENAI_API_KEY=sk-xxxxxxxxxxxxx` 这一行，把 `sk-xxxxxxxxxxxxx` 换成你刚才复制的真实 key
5. 保存

> Windows 资源管理器复制粘贴文件后改名时，如果发现"找不到 .env.example"，可能是它隐藏了 `.example` 后缀。点资源管理器顶部"查看 → 显示 → 文件扩展名"勾上，就能看到完整文件名。

打开后 `.env` 看起来应该是这样的（关键的两行）：

```
OPENAI_API_KEY=sk-你刚才复制的那串很长的key
OPENAI_BASE_URL=https://api.deepseek.com
MODEL=deepseek-chat
```

后两行如果你用 DeepSeek 就保持不变。如果用别的厂商，看 `.env.example` 里的注释。

## 6. 第一次运行：让 ch00 跑出来

终端里输入：

```
cd ch00_hello
python main.py
```

正常应该看到一行 AI 的回复，例如：

```
你好！我是一个友好的中文助理，随时准备帮你解答问题或聊天，有什么需要我做的吗？
```

**如果你看到这一行，恭喜，准备工作全部完成。** 关掉终端、休息一下，第二部分开始正式学习。

如果遇到报错，看下面这个 FAQ。

---

## 卡住了怎么办（FAQ）

### ❌ `python 不是内部或外部命令` / `command not found: python`
- Windows：重装 Python，勾选 "Add to PATH"
- macOS/Linux：试试 `python3 main.py` 而不是 `python main.py`

### ❌ `ModuleNotFoundError: No module named 'openai'`
依赖没装。在仓库根目录跑：
```
pip install -r requirements.txt
```

### ❌ `KeyError: 'OPENAI_API_KEY'`
`.env` 文件没建，或者位置不对，或者改名错了。
- 必须叫 `.env`（带前面那个点，没有 .txt 后缀）
- 必须放在 `bread-agent/` 根目录（**不是放在 ch00_hello 里**）
- 里面 `OPENAI_API_KEY=sk-真实key` 这一行必须有

### ❌ `openai.AuthenticationError: Incorrect API key`
key 复制错了，或者前后多了空格。打开 .env 检查 `OPENAI_API_KEY=` 后面那串是不是完整的 `sk-...`。

### ❌ `Connection error` / `Connection timeout`
- 如果你用的是 DeepSeek，国内直连就行
- 如果用的是 OpenAI 官方，需要稳定的代理网络
- 如果用本地 Ollama，确认 `ollama serve` 在跑

### ❌ 提示余额不足
去 https://platform.deepseek.com 充值，或换一个有额度的 provider（改 `.env` 里的 base_url 即可）。

---

# 第二部分：开始学习

## 课程地图

每一章是一个独立的、可单独运行的 Python 项目。**按顺序学**，不要跳。

| 章 | 文件夹 | 你会学到什么 | 大约行数 |
|---|---|---|---:|
| 0 | `ch00_hello/` | messages 列表是什么、role 是什么 | 30 |
| 1 | `ch01_one_tool/` | 第一次让 AI 调用一个函数 | 80 |
| 2 | `ch02_loop/` | **真正的 agent 循环（最重要）** | 140 |
| 3 | `ch03_repl/` | 多轮对话、权限确认 | 180 |
| 4 | `ch04_stream/` | 像 ChatGPT 一样逐字打印 | 270 |
| 5 | `ch05_promptpl/` | 第一次"重构"，模块化 + 系统提示词 | 340 |
| 6 | `ch06_hooks/` | 钩子机制，给 agent 加扩展点 | 410 |
| 7 | `ch07_session/` | 把对话存到硬盘，下次还能继续 | 470 |
| 8 | `ch08_subagent/` | 终章：让 agent 调度 agent | 540 |

## 怎么学每一章（重要）

每章 `README.md` 都按**五段式**结构：

1. **故事**：这一章想解决什么实际问题（先讲清楚 why）
2. **跑起来**：跟着命令把 demo 跑出来，看到效果（先看到 what 再讲 how）
3. **逐行精讲**：把代码里关键的几行掰开揉碎讲清楚
4. **卡住了怎么办**：这一章学员常踩的坑
5. **思考题**：动手改三个变体，不动手等于白学

**学习节奏建议：每章 30-45 分钟**。读 README + 跑代码 + 做思考题。

**最高效的方法**是看 diff（diff 就是"看哪些代码新增/修改/删除"）。把当前章和上一章并排打开对比看，你会很直观地理解"agent 是从一个简单脚本慢慢长出来的"。VS Code 里多选两个文件夹 → 右键 → "Compare Folders" 即可。

## 开始！

```
cd ch00_hello
```

然后打开里面的 `README.md`。

---

# 附录

## 我刻意没教的（避免劝退新手）

下面这些有用但复杂的东西被我从教学版剥掉了。等你学完整门课，再去 `pi-main/` 看工业级实现：

- 完整的 tool-call delta 流式合并（ch04 用了简化版，附录 `APPENDIX_full_streaming.py` 有完整版）
- 上下文压缩（messages 太长时让 LLM 自己总结）
- MCP 协议（统一外部工具的标准）
- 多 provider 抽象层（我们用 OpenAI 兼容接口绕过了）
- TUI 美化、Markdown 渲染

## 不要纠结的事情

- 代码不够"工程化"是故意的——`class Agent` 直到 ch05 才出现，前 5 章都是平铺直叙的脚本，让你看见"框架是从重复中长出来的"
- 没有单元测试——教学项目，每章靠端到端验收用例验证
- 同步而不是 async——新手期 async 是负担

## 致谢

灵感与架构骨架来自 [pi-main / pi-agent](https://github.com/earendil-works/pi)（@earendil-works）。我从它的 `agent-loop.ts` 里学到了 agent 循环的工程化形态，并把它简化、翻译成 Python 教学材料。

—— Bread Agent 课程 · 知识星球
