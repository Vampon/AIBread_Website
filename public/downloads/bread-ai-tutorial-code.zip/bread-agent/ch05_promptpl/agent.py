"""
Agent 模块
==========

把 ch04 的 run_turn / stream_one_turn / non_stream_one_turn 收进一个 Agent 类。
顺便提供 build_system_prompt：根据"当前可用工具 / cwd / 当前日期"动态拼出 system prompt。
"""

import json
import os
from datetime import date
from pathlib import Path
from typing import Optional, Tuple, List
from openai import OpenAI

from tools import TOOLS_SCHEMA, TOOLS_IMPL


# ============================================================
# 系统提示词构建器
#
# 参考 pi-main/packages/coding-agent/src/core/system-prompt.ts:28-77。
# 思想：persona + 工具清单 + cwd + 今天日期 拼成一个 system 消息。
# ============================================================

DEFAULT_PERSONA = """你是 Bread Agent，一个能操作文件系统和 shell 的中文助理。
工作风格：
- 必要时调用工具；不要凭空捏造文件内容
- 执行危险命令前用户会被询问，被拒绝是正常情况，礼貌改口即可
- 简洁回答；长任务结束后用一句话总结你做了什么
"""

def build_system_prompt(tools_schema: list = TOOLS_SCHEMA,
                        cwd: Optional[str] = None,
                        today: Optional[str] = None,
                        persona: str = DEFAULT_PERSONA) -> str:
    """把 persona + 可用工具简介 + cwd + 今天日期拼成 system 消息文本。"""
    cwd = cwd or str(Path.cwd())
    today = today or date.today().isoformat()

    tool_lines = []
    for t in tools_schema:
        fn = t["function"]
        tool_lines.append(f"- {fn['name']}: {fn['description']}")
    tools_block = "\n".join(tool_lines) if tool_lines else "(无可用工具)"

    return f"""{persona}
# 可用工具
{tools_block}

# 上下文
当前工作目录: {cwd}
今天日期: {today}
"""


# ============================================================
# Agent 类
# ============================================================

class Agent:
    """封装 OpenAI 客户端 + messages 状态 + agent 循环。"""

    MAX_STEPS = 10

    def __init__(self):
        self.client = OpenAI(
            api_key=os.environ["OPENAI_API_KEY"],
            base_url=os.environ["OPENAI_BASE_URL"],
        )
        self.model = os.environ["MODEL"]
        self.messages: list = [
            {"role": "system", "content": build_system_prompt()},
        ]

    # -------- 流式：处理一次模型调用 --------
    def _stream_one(self) -> Tuple[str, bool]:
        stream = self.client.chat.completions.create(
            model=self.model, messages=self.messages, tools=TOOLS_SCHEMA, stream=True,
        )
        text = ""
        detected_tool = False
        for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            if delta.tool_calls:
                detected_tool = True
                for _ in stream:
                    pass
                break
            if delta.content:
                print(delta.content, end="", flush=True)
                text += delta.content
        if text:
            print()
        return text, detected_tool

    # -------- 非流式：拿完整 assistant 消息（含 tool_calls）--------
    def _non_stream_one(self):
        resp = self.client.chat.completions.create(
            model=self.model, messages=self.messages, tools=TOOLS_SCHEMA,
        )
        return resp.choices[0].message

    # -------- 执行单个 tool_call --------
    def _execute_tool(self, call) -> str:
        name = call.function.name
        try:
            args = json.loads(call.function.arguments or "{}")
        except json.JSONDecodeError as e:
            return f"参数 JSON 解析失败: {e}"
        print(f"  [tool] {name}({args})")
        try:
            return str(TOOLS_IMPL[name](**args))
        except Exception as e:
            return f"工具执行报错: {type(e).__name__}: {e}"

    # -------- 处理一轮用户输入 --------
    def chat(self, user_input: str):
        self.messages.append({"role": "user", "content": user_input})

        for _ in range(self.MAX_STEPS):
            print("AI > ", end="", flush=True)
            text, has_tool = self._stream_one()

            if not has_tool:
                self.messages.append({"role": "assistant", "content": text})
                return

            print("[切换到非流式模式获取工具调用...]")
            assistant_msg = self._non_stream_one()
            self.messages.append(assistant_msg)

            if not assistant_msg.tool_calls:
                print(assistant_msg.content or "")
                return

            for call in assistant_msg.tool_calls:
                result = self._execute_tool(call)
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": result,
                })

        print("[已达到最大步数，强行终止]")
