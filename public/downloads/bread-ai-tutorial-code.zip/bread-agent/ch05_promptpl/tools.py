"""
工具模块
========

把所有工具的实现和 schema 集中到这里，main.py 和 agent.py 就不用堆这些细节。
"""

import subprocess
from pathlib import Path


# ============================================================
# 工具实现
# ============================================================

def read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {p} ({len(content)} chars)"


def list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def run_shell(command: str) -> str:
    print(f"\n[!] Agent 想执行命令: {command}")
    if input("[!] 允许执行吗？(y/N): ").strip().lower() != "y":
        return "用户拒绝执行此命令。"
    try:
        proc = subprocess.run(command.split(), capture_output=True, text=True,
                              timeout=30, encoding="utf-8", errors="replace")
        out = (proc.stdout or "") + (proc.stderr or "")
        return out.strip() or f"(命令无输出，退出码 {proc.returncode})"
    except subprocess.TimeoutExpired:
        return "命令执行超时 (>30s)"
    except FileNotFoundError:
        return f"命令未找到: {command.split()[0]}"


# ============================================================
# 工具 schema —— 列表顺序就是 system prompt 里展示给模型的顺序
# ============================================================

TOOLS_SCHEMA = [
    {"type": "function", "function": {"name": "read_file",
        "description": "读取一个文本文件的内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "write_file",
        "description": "写入一个文本文件，会覆盖已有内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "list_dir",
        "description": "列出目录下的文件和子目录。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": []}}},
    {"type": "function", "function": {"name": "run_shell",
        "description": "执行一条 shell 命令（用户会被提示确认）。",
        "parameters": {"type": "object",
            "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
]

TOOLS_IMPL = {
    "read_file": read_file,
    "write_file": write_file,
    "list_dir": list_dir,
    "run_shell": run_shell,
}
