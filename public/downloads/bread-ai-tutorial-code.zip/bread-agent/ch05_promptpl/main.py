"""
第 5 章 · 多文件重构 + 系统提示词模板
====================================

到目前为止我们的代码全堆在 main.py 一个文件里。
这一章不引入任何新功能，只做**重构**：
    tools.py   —— 工具实现 + schema
    agent.py   —— Agent 类（封装客户端、messages、循环）+ build_system_prompt
    main.py    —— 只剩 REPL 外壳（你正在读的这个文件）

同时引入一个非常重要的概念：**系统提示词模板化**。
system 消息不再是写死的字符串，而是根据"当前可用工具 / cwd / 今天日期"动态拼起来。

为什么这个值得单独一章？
    - "新建一个 class Agent" 是后面 3 章共用的骨架
    - "system prompt 是动态拼装的" 这件事，是工业级 agent（包括 pi-main）的标配
"""

import sys
from pathlib import Path
from dotenv import load_dotenv

# Windows 控制台 UTF-8（防中文/emoji 乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# ★ 必须在 import agent 之前——agent.py 里读 os.environ
# 用绝对路径找仓库根目录的 .env，子目录运行也能读到
load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from agent import Agent


def main():
    agent = Agent()
    print("Bread Agent · v5（已重构）")
    print("输入消息开始对话；Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break
        if not user_input:
            continue
        try:
            agent.chat(user_input)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print()


if __name__ == "__main__":
    main()
