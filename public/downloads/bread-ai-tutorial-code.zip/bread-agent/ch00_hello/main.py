"""
第 0 章 · 最简的 LLM 调用
========================

这是整门课程的起点。我们什么 agent 都不做，只是单纯地：
  1. 准备一份对话历史 messages
  2. 把它发给大模型
  3. 打印大模型的回复

请把这段代码当作"agent 的胚胎"——后面 8 章都是在它身上一点点长出器官。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

# Windows 控制台默认是 GBK 编码，遇到 emoji 或部分中文字符会乱码。
# 这一行强制 stdout 用 UTF-8，让学员不论什么终端都看得清。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# 从 .env 文件加载 OPENAI_API_KEY / OPENAI_BASE_URL / MODEL
# 用绝对路径找仓库根目录的 .env，这样从任何目录跑 main.py 都能正确读到
load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# OpenAI 的 Python SDK 是一个事实标准。
# 只要把 base_url 换掉，就能切到 DeepSeek / Qwen / Moonshot / Ollama 等任何兼容 provider。
client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


def chat(user_input: str) -> str:
    """把一句用户输入发给 LLM，拿回它的字符串回复。"""

    # messages 是一个 list，每一项都是一个 dict，必须有 "role" 和 "content"。
    # role 的三大基本值：system（系统人设）/ user（用户）/ assistant（模型）
    messages = [
        {"role": "system", "content": "你是一个友好的中文助理。"},
        {"role": "user", "content": user_input},
    ]

    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
    )

    # 一次响应里可能有多个候选（n 参数控制），我们只取第 0 个。
    return response.choices[0].message.content


if __name__ == "__main__":
    reply = chat("用一句话介绍一下你自己。")
    print(reply)
