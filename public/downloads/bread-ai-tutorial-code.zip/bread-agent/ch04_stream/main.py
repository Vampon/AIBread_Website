"""
第 4 章 · 流式输出
==================

ch03 的 agent 每次说话都是"憋很久 → 一次性吐出一大段"。体验差。
真实的 ChatGPT/Claude 是边生成边打字——这就是 stream（流式）。

技术上 stream=True 让 OpenAI SDK 返回一个**生成器**，逐 chunk 给你内容片段。
你拿到一个 chunk 就 print 一个，用户就看到打字效果。

但是！流式有一个**地狱级**的复杂点：**当模型要调工具时，tool_calls 字段也是分块传过来的**——
你必须自己拼装 id / name / arguments 这些字段。生产级实现要 60+ 行 dict 合并。

为了让本章在 ~270 行内可读，我们做了一个**明确的简化**：
    - 用 stream=True 调一次，**只显示文本 delta**
    - 如果发现这一轮模型要调工具（chunk 里出现 tool_calls），
      就丢弃这次 streaming 响应，重新用 stream=False 拿一次完整结果
    - 这样我们永远不需要做 tool_calls 的 delta 合并

代价：触发工具调用的轮次会"卡一下"——但学员看见的代码非常清楚。
完整版的实现在本目录的 APPENDIX_full_streaming.py，供学有余力的同学研究。
"""

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Tuple, List
from dotenv import load_dotenv
from openai import OpenAI

# Windows 控制台 UTF-8（防中文/emoji 乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# 用绝对路径找仓库根目录的 .env，子目录运行也能读到
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


# ============================================================
# 工具（跟 ch03 一样，直接搬过来）
# ============================================================

def read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {p} ({len(content)} chars)"


def list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def run_shell(command: str) -> str:
    print(f"\n[!] Agent 想执行命令: {command}")
    if input("[!] 允许执行吗？(y/N): ").strip().lower() != "y":
        return "用户拒绝执行此命令。"
    try:
        proc = subprocess.run(command.split(), capture_output=True, text=True,
                              timeout=30, encoding="utf-8", errors="replace")
        out = (proc.stdout or "") + (proc.stderr or "")
        return out.strip() or f"(命令无输出，退出码 {proc.returncode})"
    except subprocess.TimeoutExpired:
        return "命令执行超时 (>30s)"
    except FileNotFoundError:
        return f"命令未找到: {command.split()[0]}"


TOOLS_SCHEMA = [
    {"type": "function", "function": {"name": "read_file",
        "description": "读取一个文本文件的内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "write_file",
        "description": "写入一个文本文件，会覆盖已有内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "list_dir",
        "description": "列出目录下的文件和子目录。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}}, "required": []}}},
    {"type": "function", "function": {"name": "run_shell",
        "description": "执行一条 shell 命令（用户会被提示确认）。",
        "parameters": {"type": "object",
            "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
]

TOOLS_IMPL = {
    "read_file": read_file, "write_file": write_file,
    "list_dir": list_dir, "run_shell": run_shell,
}


# ============================================================
# ★ 本章核心：流式响应处理
# ============================================================

def stream_one_turn(messages: list) -> Tuple[str, bool]:
    """
    用 stream=True 调一次模型，边收边打。

    返回 (accumulated_text, has_tool_calls)：
      - 如果模型给的是纯文本回答，就一边流式打印一边拼接，最终把整段文本返回；
        调用方再把它 append 到 messages。
      - 如果检测到模型想调工具（chunk 里出现 tool_calls），立即返回 (空串, True)，
        让调用方用非流式方式重新拿完整 tool_calls。

    本章的关键简化：我们不在这里拼装 tool_calls 的 delta。
    """
    stream = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        tools=TOOLS_SCHEMA,
        stream=True,
    )

    accumulated_text = ""
    detected_tool_call = False

    for chunk in stream:
        if not chunk.choices:
            continue
        delta = chunk.choices[0].delta

        # ----- 工具调用检测 -----
        # 只要 chunk 里出现了 tool_calls（哪怕只是个 id），就说明这一轮要调工具。
        # 我们立即停止流式处理，告诉外层"换非流式模式重新来"。
        if delta.tool_calls:
            detected_tool_call = True
            # 把 streaming 迭代器消费掉（不消费的话连接会一直挂着）
            for _ in stream:
                pass
            break

        # ----- 文本 delta -----
        if delta.content:
            print(delta.content, end="", flush=True)
            accumulated_text += delta.content

    if accumulated_text:
        print()  # 收尾换行

    return accumulated_text, detected_tool_call


def non_stream_one_turn(messages: list):
    """非流式调一次，拿到完整 assistant 消息（含 tool_calls）。仅在已知有工具调用时用。"""
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        tools=TOOLS_SCHEMA,
    )
    return response.choices[0].message


# ============================================================
# Agent 主循环
# ============================================================

MAX_STEPS = 10

def run_turn(messages: list):
    """处理一轮用户输入。Agent 内部可能多次调模型 / 调工具。"""
    for step in range(MAX_STEPS):
        print("AI > ", end="", flush=True)

        # === 先尝试流式 ===
        text, has_tool = stream_one_turn(messages)

        if not has_tool:
            # 纯文本回答，流式已经把内容打印过了。把它写进 messages 就行。
            messages.append({"role": "assistant", "content": text})
            return

        # === 检测到要调工具：回退到非流式拿完整 tool_calls ===
        # （注：这会让"工具触发的回合"看上去卡一下；这是本章主动牺牲的体验。）
        print("[切换到非流式模式获取工具调用...]")
        assistant_msg = non_stream_one_turn(messages)
        messages.append(assistant_msg)

        if not assistant_msg.tool_calls:
            # 罕见情况：非流式那一次模型又改主意不调工具了
            print(assistant_msg.content or "")
            return

        for call in assistant_msg.tool_calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError as e:
                result = f"参数 JSON 解析失败: {e}"
            else:
                print(f"  [tool] {name}({args})")
                try:
                    result = TOOLS_IMPL[name](**args)
                except Exception as e:
                    result = f"工具执行报错: {type(e).__name__}: {e}"
            messages.append({"role": "tool", "tool_call_id": call.id, "content": str(result)})

    print("[已达到最大步数，强行终止]")


def main():
    messages = [
        {"role": "system", "content": "你是一个能操作文件系统和 shell 的中文助理。"},
    ]
    print("Bread Agent · 流式 REPL\n输入消息开始对话；Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break
        if not user_input:
            continue
        messages.append({"role": "user", "content": user_input})
        try:
            run_turn(messages)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print()


if __name__ == "__main__":
    main()
