"""
附录 A · 完整流式实现（拼装 tool_calls 的 delta）
=================================================

本课主线（main.py）做了一个简化：检测到 tool_calls 就回退到非流式。
真实的生产级 agent（包括 pi-main）会把 tool_calls 的所有片段也拼装起来。

这个附录给你一份完整版的"流式 + tool_calls 拼装"实现，**仅供阅读参考**，
不在课程主线里讲解。

tool_calls delta 的形态（OpenAI 协议定义）：
    chunk 1 的 delta.tool_calls = [
        {"index": 0, "id": "call_abc", "function": {"name": "read_f", "arguments": ""}}
    ]
    chunk 2 的 delta.tool_calls = [
        {"index": 0, "function": {"arguments": "{\""}}
    ]
    chunk 3 的 delta.tool_calls = [
        {"index": 0, "function": {"arguments": "path"}}
    ]
    ... 直到结束。

我们需要按 index 把 id / name / arguments 一片片拼起来。

注意：实际跑这份附录代码需要把 main.py 的 stream_one_turn 替换掉，并修改 run_turn
以处理拼装出来的 tool_calls。这里只给关键函数，完整接入需要你自己改 main.py。
"""

import json
from openai import OpenAI


def stream_with_tool_call_assembly(client: OpenAI, model: str, messages: list, tools: list):
    """
    完整版流式：边流式打印文本 delta，边拼装 tool_calls 的 delta。

    返回 (text, tool_calls)：
      - text: 模型生成的最终文本（可能为空）
      - tool_calls: 拼装好的 list，每个元素形如：
          {"id": "call_xxx", "type": "function",
           "function": {"name": "read_file", "arguments": "{...}"}}
        如果模型没调工具就是空 list。
    """
    stream = client.chat.completions.create(
        model=model, messages=messages, tools=tools, stream=True,
    )

    text_parts = []
    # 用一个 dict 按 index 缓存 tool_calls 的拼装结果
    # 注意：OpenAI 协议保证同一个 tool_call 的所有 chunk 用相同 index
    tool_calls_by_index: dict[int, dict] = {}

    for chunk in stream:
        if not chunk.choices:
            continue
        delta = chunk.choices[0].delta

        # ----- 文本片段：原地累积 -----
        if delta.content:
            print(delta.content, end="", flush=True)
            text_parts.append(delta.content)

        # ----- 工具调用片段：按 index 合并 -----
        if delta.tool_calls:
            for tc_delta in delta.tool_calls:
                idx = tc_delta.index
                if idx not in tool_calls_by_index:
                    # 这是该 index 的第一个 chunk，初始化外壳
                    tool_calls_by_index[idx] = {
                        "id": "",
                        "type": "function",
                        "function": {"name": "", "arguments": ""},
                    }
                slot = tool_calls_by_index[idx]

                if tc_delta.id:
                    slot["id"] += tc_delta.id
                if tc_delta.function:
                    if tc_delta.function.name:
                        slot["function"]["name"] += tc_delta.function.name
                    if tc_delta.function.arguments:
                        slot["function"]["arguments"] += tc_delta.function.arguments

    if text_parts:
        print()  # 收尾换行

    # 按 index 升序排列，转成 list 返回
    tool_calls = [tool_calls_by_index[i] for i in sorted(tool_calls_by_index)]
    return "".join(text_parts), tool_calls


# ============================================================
# 用法示意（伪代码，不要直接跑）
# ============================================================
"""
text, tool_calls = stream_with_tool_call_assembly(client, MODEL, messages, TOOLS_SCHEMA)

if not tool_calls:
    messages.append({"role": "assistant", "content": text})
    return text

# 把 assistant 消息写回 messages（注意 content 可以为 None）
messages.append({
    "role": "assistant",
    "content": text or None,
    "tool_calls": tool_calls,
})

# 执行每个工具
for tc in tool_calls:
    args = json.loads(tc["function"]["arguments"] or "{}")
    result = TOOLS_IMPL[tc["function"]["name"]](**args)
    messages.append({
        "role": "tool",
        "tool_call_id": tc["id"],
        "content": str(result),
    })
"""
