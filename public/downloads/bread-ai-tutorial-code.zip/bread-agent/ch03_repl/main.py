"""
第 3 章 · 多轮对话 + 权限确认
=============================

ch02 的 agent 一次只能处理一个任务，然后就退出了。
这一章我们把它包成 REPL（Read-Eval-Print Loop），让你可以和它**持续聊**——
你说一句，它回一句，记得上下文；你说"刚才那个文件再加一行"，它知道"那个文件"是谁。

同时我们新增一个非常**危险**的工具 `run_shell`，能执行任意 shell 命令。
危险工具不能让 agent 想跑就跑——我们在它执行之前 inline 一个 y/N 确认。
（下一章 ch06 会把这个 inline 的 if 重构成"钩子"——但现在先用最朴素的方式。）

多轮对话的本质：**messages 列表跨用户输入持续累积**，仅此而已。
"""

import json
import os
import subprocess
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

# Windows 控制台 UTF-8（防中文/emoji 乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# 用绝对路径找仓库根目录的 .env，子目录运行也能读到
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


# ============================================================
# 工具
# ============================================================

def read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {p} ({len(content)} chars)"


def list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def run_shell(command: str) -> str:
    """执行 shell 命令并返回 stdout+stderr。"""
    # ★ 这里就是 ch03 的高光：危险工具执行前先问用户
    print(f"\n[!] Agent 想执行命令: {command}")
    answer = input("[!] 允许执行吗？(y/N): ").strip().lower()
    if answer != "y":
        # 拒绝信息以工具结果的形式回喂给模型，它会用中文告诉用户"被拒绝了"
        return "用户拒绝执行此命令。"

    try:
        # shell=False + 把命令字符串按空白切——简单但能用。
        # 课程不教 shlex/shell=True 的正确组合，避免新手踩注入坑。
        proc = subprocess.run(
            command.split(),
            capture_output=True,
            text=True,
            timeout=30,
            encoding="utf-8",
            errors="replace",
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        return out.strip() or f"(命令无输出，退出码 {proc.returncode})"
    except subprocess.TimeoutExpired:
        return "命令执行超时 (>30s)"
    except FileNotFoundError:
        return f"命令未找到: {command.split()[0]}"


# ============================================================
# 工具注册
# ============================================================

TOOLS_SCHEMA = [
    {"type": "function", "function": {"name": "read_file",
        "description": "读取一个文本文件的内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"]}}},
    {"type": "function", "function": {"name": "write_file",
        "description": "写入一个文本文件，会覆盖已有内容。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"]}}},
    {"type": "function", "function": {"name": "list_dir",
        "description": "列出目录下的文件和子目录。",
        "parameters": {"type": "object",
            "properties": {"path": {"type": "string"}},
            "required": []}}},
    {"type": "function", "function": {"name": "run_shell",
        "description": "执行一条 shell 命令（用户会被提示确认）。适合运行 git/ls/cat/python 等。",
        "parameters": {"type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"]}}},
]

TOOLS_IMPL = {
    "read_file": read_file,
    "write_file": write_file,
    "list_dir": list_dir,
    "run_shell": run_shell,
}


# ============================================================
# Agent 单轮处理 —— 跟 ch02 几乎一样，区别是 messages 从外面传进来
# ============================================================

MAX_STEPS = 10

def run_turn(messages: list) -> str:
    """处理一轮用户输入。messages 会被原地修改（持续累积）。"""
    for step in range(MAX_STEPS):
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=TOOLS_SCHEMA,
        )
        msg = response.choices[0].message
        messages.append(msg)

        if not msg.tool_calls:
            return msg.content or ""

        for call in msg.tool_calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError as e:
                result = f"参数 JSON 解析失败: {e}"
            else:
                print(f"  [tool] {name}({args})")
                try:
                    result = TOOLS_IMPL[name](**args)
                except Exception as e:
                    result = f"工具执行报错: {type(e).__name__}: {e}"
            messages.append({"role": "tool", "tool_call_id": call.id, "content": str(result)})

    return "[已达到最大步数，强行终止]"


# ============================================================
# REPL —— 多轮对话的外壳
# ============================================================

def main():
    # ★ messages 在 REPL 循环外定义，整个对话期间持续累积。
    #    多轮对话的全部秘密就这一行——其他都是装饰。
    messages = [
        {"role": "system", "content": "你是一个能操作文件系统和 shell 的中文助理。"
                                       "执行危险命令前会被用户拦截。"},
    ]

    print("Bread Agent · REPL 模式")
    print("输入消息开始对话；Ctrl+C 退出。\n")

    while True:
        try:
            user_input = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break

        if not user_input:
            continue

        messages.append({"role": "user", "content": user_input})
        try:
            answer = run_turn(messages)
        except KeyboardInterrupt:
            print("\n[中断本轮，回到提示符]")
            continue
        print(f"\nAI > {answer}\n")


if __name__ == "__main__":
    main()
