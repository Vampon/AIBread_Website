"""
第 2 章 · 真正的 Agent 循环
==========================

ch01 我们演示了"两次请求+一次工具执行"。
但真实场景里，一个任务往往要**多个工具配合**才能完成。比如：
    用户："把 README.md 第一行复制到 hello.txt"
    模型 1：调 read_file("README.md")
    模型 2：基于读到的内容，调 write_file("hello.txt", first_line)
    模型 3：用自然语言告诉用户"已完成"
这就要求我们：**不断把工具结果回喂给模型，直到它不再要求调工具为止**。

这就是 agent loop —— 智能体的灵魂。本章 ~140 行代码搞定。

另外这一章还教一个**关键技巧**：工具执行用 try/except 包起来，
异常时把错误字符串作为 tool 结果回喂给模型，让 agent 能从错误中恢复。
"""

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

# Windows 控制台 UTF-8（防中文/emoji 乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# 用绝对路径找仓库根目录的 .env，子目录运行也能读到
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ["OPENAI_BASE_URL"],
)
MODEL = os.environ["MODEL"]


# ============================================================
# 工具实现
# ============================================================

def read_file(path: str) -> str:
    """读取文本文件全部内容。"""
    text = Path(path).read_text(encoding="utf-8")
    # 防止极长文件把上下文窗口撑爆，做个简单截断
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def write_file(path: str, content: str) -> str:
    """写入文本文件，会覆盖原内容。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {p} ({len(content)} chars)"


def list_dir(path: str = ".") -> str:
    """列出目录下的文件和子目录。"""
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = []
    for child in sorted(p.iterdir()):
        kind = "DIR " if child.is_dir() else "FILE"
        items.append(f"{kind} {child.name}")
    return "\n".join(items) if items else "(空目录)"


# ============================================================
# 工具注册：schema 给模型看，impl 给我们自己用
# ============================================================

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "读取一个文本文件的内容。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "文件路径，可以是相对路径或绝对路径"},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "写入一个文本文件，会覆盖已有内容。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "列出目录下的文件和子目录。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "目录路径，默认为当前目录"},
                },
                "required": [],
            },
        },
    },
]

TOOLS_IMPL = {
    "read_file": read_file,
    "write_file": write_file,
    "list_dir": list_dir,
}


# ============================================================
# 核心：Agent 循环
# ============================================================

MAX_STEPS = 10  # 安全阀：避免模型无限调工具把 token 烧光

def run_agent(user_input: str) -> str:
    messages = [
        {"role": "system", "content": "你是一个能操作文件系统的中文助理，根据需要调用工具。完成任务后用一句话总结。"},
        {"role": "user", "content": user_input},
    ]

    for step in range(MAX_STEPS):
        # ----- 调一次模型 -----
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=TOOLS_SCHEMA,
        )
        assistant_msg = response.choices[0].message
        messages.append(assistant_msg)

        # ----- 没有 tool_calls 就说明任务完成了，break -----
        if not assistant_msg.tool_calls:
            return assistant_msg.content or ""

        # ----- 有 tool_calls，逐个执行并把结果写回 -----
        for tool_call in assistant_msg.tool_calls:
            name = tool_call.function.name
            try:
                args = json.loads(tool_call.function.arguments or "{}")
            except json.JSONDecodeError as e:
                # 模型偶尔会返回坏 JSON，错误也回喂给它，它会自己改正
                result = f"参数 JSON 解析失败: {e}"
            else:
                print(f"[step {step}] 调用 {name}({args})")
                try:
                    # ★ 关键技巧：工具执行出异常时，把异常作为 tool 结果回喂，
                    #    模型会看到错误信息并自己调整——agent 因此具备"从错误中恢复"的能力。
                    result = TOOLS_IMPL[name](**args)
                except Exception as e:
                    result = f"工具执行报错: {type(e).__name__}: {e}"
                print(f"[step {step}] 结果: {str(result)[:120]}")

            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": str(result),
            })

    return "[已达到最大步数，强行终止]"


if __name__ == "__main__":
    # 端到端示例：让 agent 读一个文件的内容，并写入到另一个文件
    answer = run_agent("读取origin.txt文件的前3行，并把第1行内容写入到一个到文件new.txt中。")
    print("\n[最终回答]", answer)
