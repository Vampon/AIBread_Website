"""
第 3 章 · Router
================

Router agent 当"前台分诊员"：

  用户问 ──→ Router 分类 ──→ 转给对应专家 ──→ 专家答 ──→ 返给用户

3 个专家：
  - MathAgent：会调 calc 工具，专攻算术
  - CodeAgent：专攻 Python 代码问题，纯文本回答
  - GeneralAgent：兜底闲聊

这是**真实客服系统**的标准架构。
"""

import json
import os
import re
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")


# =========================================================
# 共享的算术工具（仅 MathAgent 用）
# =========================================================
def calc(expression: str) -> str:
    if not re.fullmatch(r"[0-9+\-*/().\s]+", expression):
        return f"非法表达式: {expression!r}"
    try:
        return str(eval(expression, {"__builtins__": {}}, {}))
    except Exception as e:
        return f"计算失败: {e}"


CALC_TOOL = {
    "type": "function",
    "function": {
        "name": "calc",
        "description": "Compute an arithmetic expression. Only digits and + - * / ( ) allowed.",
        "parameters": {
            "type": "object",
            "properties": {"expression": {"type": "string"}},
            "required": ["expression"],
        },
    },
}


# =========================================================
# 专家 agent 基类
# =========================================================
class SpecialistAgent:
    """每个专家有自己的 persona、自己的 messages、可选的工具集。"""

    SYSTEM = "你是一个通用助手。"
    TOOLS: list[dict] = []

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model
        self.messages = [{"role": "system", "content": self.SYSTEM}]

    def answer(self, user_query: str) -> str:
        self.messages.append({"role": "user", "content": user_query})

        for _ in range(5):
            kwargs = {"model": self.model, "messages": self.messages, "temperature": 0.2}
            if self.TOOLS:
                kwargs["tools"] = self.TOOLS
            resp = self.client.chat.completions.create(**kwargs)
            msg = resp.choices[0].message
            self.messages.append(msg)

            if not msg.tool_calls:
                return msg.content or ""

            for call in msg.tool_calls:
                args = json.loads(call.function.arguments or "{}")
                if call.function.name == "calc":
                    result = calc(args.get("expression", ""))
                else:
                    result = f"unknown tool: {call.function.name}"
                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": result,
                })

        return "[已达最大工具调用次数]"


class MathAgent(SpecialistAgent):
    SYSTEM = (
        "你是数学专家。用户的所有问题都跟数字、算术、几何、代数有关。\n"
        "**所有算术必须调 calc 工具**——即使是 2+2 也不允许心算。\n"
        "回答风格：先讲思路，再调工具算，最后用一句话总结答案。"
    )
    TOOLS = [CALC_TOOL]


class CodeAgent(SpecialistAgent):
    SYSTEM = (
        "你是 Python 代码专家。\n"
        "用户问什么你只用 Python 视角回答。代码块用 ```python ... ``` 包起来。\n"
        "提供能跑的最小代码，附 1-2 句解释。不啰嗦、不写不必要的边界处理。\n"
        "如果问题与 Python 无关，礼貌说明你只懂 Python。"
    )


class GeneralAgent(SpecialistAgent):
    SYSTEM = (
        "你是友好的通用助手。负责接闲聊、生活问题、和那些没法分类的问题。\n"
        "回答简短、温暖、自然。"
    )


# =========================================================
# Router —— 分诊员
# =========================================================
class Router:
    SYSTEM = (
        "你是分诊员。用户会发一句话，你判断应该交给以下哪个专家：\n"
        "  - 'math'    数学 / 算术 / 几何 / 数字相关\n"
        "  - 'code'    Python / 编程 / 代码相关\n"
        "  - 'general' 其他一切（闲聊、问候、生活问题）\n"
        "\n"
        "输出**严格 JSON**：{\"specialist\": \"math|code|general\", \"reason\": \"一句话原因\"}\n"
        "不要 markdown 代码块、不要额外文字。"
    )

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

    def route(self, query: str) -> tuple[str, str]:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content": query},
            ],
            temperature=0.0,
        )
        text = (resp.choices[0].message.content or "").strip()
        if text.startswith("```"):
            text = text.strip("`").lstrip("json").strip()
        # 截到最后 }
        last_brace = text.rfind("}")
        if last_brace != -1:
            text = text[: last_brace + 1]
        try:
            data = json.loads(text)
            spec = data.get("specialist", "general")
            reason = data.get("reason", "")
        except json.JSONDecodeError:
            # 兜底正则
            m = re.search(r'(math|code|general)', text)
            spec = m.group(1) if m else "general"
            reason = "(JSON 解析失败，正则兜底)"
        if spec not in ("math", "code", "general"):
            spec = "general"
        return spec, reason


# =========================================================
# 主流程：REPL
# =========================================================
def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    router = Router(client, model)
    specialists = {
        "math": MathAgent(client, model),
        "code": CodeAgent(client, model),
        "general": GeneralAgent(client, model),
    }
    emoji = {"math": "🧮", "code": "🐍", "general": "💬"}

    print("Bread Router · 一站式智能助手（REPL）")
    print("Ctrl+C 退出。试试：")
    print("  1+2+3 等于几？")
    print("  写一个 Python 函数反转字符串")
    print("  今天天气真不错")
    print()

    while True:
        try:
            query = input("你 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break
        if not query:
            continue

        spec, reason = router.route(query)
        print(f"  [Router → {spec}]  原因：{reason}")
        try:
            answer = specialists[spec].answer(query)
        except KeyboardInterrupt:
            print("\n[中断本轮]")
            continue
        print(f"\n{emoji[spec]} {spec}: {answer}\n")


if __name__ == "__main__":
    main()
