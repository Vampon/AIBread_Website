"""
第 4 章 · Pipeline
==================

多阶段流水线：博客生成系统。

  topic ──→ Researcher ──→ key_points
                              │
                              ▼
                          Outliner ──→ outline
                              │
                              ▼
                          Writer ──→ draft
                              │
                              ▼
                          Editor ──→ final article

每阶段是一个独立 agent。**output 是下一阶段的 input**。

这就是 LangChain / LlamaIndex 等框架里 "Chain" 的本质——
而我们没有依赖任何框架。
"""

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")


# =========================================================
# Stage 基类
# =========================================================
class Stage:
    """每个 stage 是个无状态函数：input → output。

    无状态 = messages 每次新建。这样 stages 可以独立单元测试、独立缓存、独立重跑。
    """

    NAME = "stage"
    SYSTEM = ""

    def __init__(self, client: OpenAI, model: str, temperature: float = 0.5):
        self.client = client
        self.model = model
        self.temperature = temperature

    def run(self, prev_output: str, topic: str) -> str:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content": self._build_user_msg(prev_output, topic)},
            ],
            temperature=self.temperature,
        )
        return (resp.choices[0].message.content or "").strip()

    def _build_user_msg(self, prev_output: str, topic: str) -> str:
        return f"主题：{topic}\n\n上一阶段输出：\n{prev_output}"


# =========================================================
# 4 个 stage 实例
# =========================================================
class ResearcherStage(Stage):
    NAME = "researcher"
    SYSTEM = (
        "你是技术研究员。给你一个主题，你的工作是列出**6-10 条关键事实/观点**作为后续写作素材。\n"
        "\n"
        "规则：\n"
        "1. 每条用 '- ' 开头，单行简洁（不超过 40 字）。\n"
        "2. 优先：定义、历史、为什么有、争议点、近期变化、和其他方案对比。\n"
        "3. 客观、可验证。\n"
        "4. 只输出 bullet list，不要标题、不要总结。"
    )

    def _build_user_msg(self, prev_output: str, topic: str) -> str:
        return f"主题：{topic}"  # researcher 是首位，没有 prev_output


class OutlinerStage(Stage):
    NAME = "outliner"
    SYSTEM = (
        "你是博客大纲规划师。给你一份事实清单，你要输出**博客大纲**。\n"
        "\n"
        "格式（严格遵守）：\n"
        "# 标题（吸引人但不浮夸）\n"
        "\n"
        "## 1. 一级标题\n"
        "- 段落要点 a\n"
        "- 段落要点 b\n"
        "\n"
        "## 2. 一级标题\n"
        "- ...\n"
        "\n"
        "规则：3-5 个一级标题，每个 2-4 个要点。"
    )


class WriterStage(Stage):
    NAME = "writer"
    SYSTEM = (
        "你是技术博客作者。给你一份大纲，把它扩写成**完整的博客文章**。\n"
        "\n"
        "规则：\n"
        "- 保留大纲的标题结构。\n"
        "- 每个要点扩成 2-4 句话。\n"
        "- 风格：通俗但不失专业，可适度幽默。\n"
        "- 全文约 600-900 字。\n"
        "- 用 markdown 输出（# 标题 / ## 二级 / 普通段落）。"
    )


class EditorStage(Stage):
    NAME = "editor"
    SYSTEM = (
        "你是资深编辑。给你一份博客初稿，你的工作是**润色**——不大改结构。\n"
        "\n"
        "重点改：\n"
        "- 过渡词、衔接句、行文节奏。\n"
        "- 啰嗦的句子精简。\n"
        "- 技术不准确的地方修正。\n"
        "- 标题如果太平淡，换一个更吸引的。\n"
        "\n"
        "输出**修改后的完整 markdown 文章**，不要任何编辑批注。"
    )


# =========================================================
# Pipeline 驱动器
# =========================================================
class BlogPipeline:
    def __init__(self, client: OpenAI, model: str, output_dir: Path):
        self.stages: list[Stage] = [
            ResearcherStage(client, model, temperature=0.4),
            OutlinerStage(client, model, temperature=0.4),
            WriterStage(client, model, temperature=0.6),  # 创作高一点
            EditorStage(client, model, temperature=0.3),  # 编辑稳定一点
        ]
        self.output_dir = output_dir
        self.output_dir.mkdir(exist_ok=True)

    def run(self, topic: str) -> str:
        current = ""
        for stage in self.stages:
            print(f"\n=== Stage: {stage.NAME} ===")
            current = stage.run(current, topic)
            print(f"[{stage.NAME} 输出 {len(current)} 字]")
            print(current[:400] + ("..." if len(current) > 400 else ""))
            # 存中间产物，方便 debug
            (self.output_dir / f"{stage.NAME}.md").write_text(current, encoding="utf-8")
        return current


# =========================================================
# 主流程
# =========================================================
def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    topic = "Python 的 GIL：它是什么，为什么有人想去掉，2026 年的进展"

    pipeline = BlogPipeline(client, model, output_dir=HERE / "output")
    print(f"=== 博客主题 ===\n{topic}\n")

    final_article = pipeline.run(topic)

    final_path = HERE / "output" / "final.md"
    print(f"\n\n=== 全部完成 ===")
    print(f"完整文章存到 {final_path}（{len(final_article)} 字）")
    print(f"中间产物（researcher.md / outliner.md / writer.md / editor.md）也在 output/ 里。")


if __name__ == "__main__":
    main()
