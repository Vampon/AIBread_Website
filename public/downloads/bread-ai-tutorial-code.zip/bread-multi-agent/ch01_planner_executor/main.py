"""
第 1 章 · Planner + Executor
=============================

两个 agent **角色不同**：

  Planner —— 接到任务，输出 JSON 步骤列表（不执行）
  Executor —— 接到步骤列表，逐条执行（带工具）

这是真实业务里最常用的多 agent 拓扑——
**"思考"和"动手"分离**。

demo 任务：
  "计算前 10 个素数的平均值，给出完整的中文句子作为答案。"
"""

import json
import os
import re
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")


# =========================================================
# Executor 的工具集
# =========================================================
def calc(expression: str) -> str:
    """安全的算术计算器。仅允许数字、运算符、括号、空格。"""
    if not re.fullmatch(r"[0-9+\-*/().\s]+", expression):
        return f"非法表达式（仅允许数字与运算符）: {expression!r}"
    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return f"{expression} = {result}"
    except Exception as e:
        return f"计算失败: {e}"


TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "calc",
            "description": "Compute an arithmetic expression. Only digits, + - * / ( ) allowed.",
            "parameters": {
                "type": "object",
                "properties": {"expression": {"type": "string"}},
                "required": ["expression"],
            },
        },
    },
]


# =========================================================
# Planner —— 接任务，输出 JSON 步骤列表
# =========================================================
class Planner:
    SYSTEM = (
        "你是 Planner。接到一个任务，你的工作是把它**拆成 3-6 条具体可执行的步骤**。\n"
        "\n"
        "约束：\n"
        "1. 每条步骤是一句简短的中文动作（不到 30 字），动词开头。\n"
        "2. 最后一步必须是 '汇报最终答案'。\n"
        "3. 输出**严格的 JSON 数组**，不要任何额外文字、不要 markdown 代码块。\n"
        "\n"
        "示例输入：'计算 1+2+3 的结果，输出英文单词形式'\n"
        "示例输出：[\"计算 1+2+3 的数值\", \"将结果翻译为英文单词\", \"汇报最终答案\"]"
    )

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

    def plan(self, task: str) -> list[str]:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content": f"任务：{task}"},
            ],
            temperature=0.2,
        )
        text = (resp.choices[0].message.content or "").strip()
        # 容错：剥掉 markdown 代码块
        if text.startswith("```"):
            text = text.strip("`")
            if text.startswith("json"):
                text = text[4:]
        text = text.strip()
        return json.loads(text)


# =========================================================
# Executor —— 接步骤列表，逐条执行
# =========================================================
class Executor:
    SYSTEM = (
        "你是 Executor。Planner 给了你一份步骤计划。你要**按顺序逐条完成**。\n"
        "每次只关注当前那一步；其它步骤会在后续轮次问你。\n"
        "需要算术时调用 calc 工具，不要心算。\n"
        "最后一步'汇报最终答案'时，整合前面所有结果，直接给出最终答案（不用调工具）。"
    )

    MAX_STEPS_PER_TASK = 3  # 每个 step 最多调 3 次工具防死循环

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model
        self.messages = [{"role": "system", "content": self.SYSTEM}]

    def execute_plan(self, task: str, steps: list[str]) -> str:
        self.messages.append({
            "role": "user",
            "content": f"原任务：{task}\n\n计划：\n" + "\n".join(f"  {i+1}. {s}" for i, s in enumerate(steps)),
        })

        for i, step in enumerate(steps):
            print(f"\n▶ Executor 步骤 {i+1}/{len(steps)}: {step}")
            self.messages.append({"role": "user", "content": f"现在执行第 {i+1} 步：{step}"})
            self._run_one_step()
        # 最后一条 assistant 消息就是最终答案
        for m in reversed(self.messages):
            content = m.get("content") if isinstance(m, dict) else getattr(m, "content", None)
            role = m.get("role") if isinstance(m, dict) else getattr(m, "role", None)
            if role == "assistant" and content:
                return content
        return "(no final answer)"

    def _run_one_step(self):
        for _ in range(self.MAX_STEPS_PER_TASK):
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=TOOLS_SCHEMA, temperature=0.2,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)
            if not msg.tool_calls:
                print(f"  Executor: {msg.content}")
                return
            for call in msg.tool_calls:
                args = json.loads(call.function.arguments or "{}")
                if call.function.name == "calc":
                    result = calc(args.get("expression", ""))
                else:
                    result = f"unknown tool: {call.function.name}"
                print(f"  ↳ calc({args.get('expression')!r}) = {result.split('=')[-1].strip()}")
                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": result,
                })


# =========================================================
# 主流程
# =========================================================
def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    task = "计算前 10 个素数的算术平均值，给出一句完整的中文答案。"
    print(f"=== 原任务 ===\n{task}\n")

    planner = Planner(client, model)
    print("=== Planner 在思考 ===")
    steps = planner.plan(task)
    for i, s in enumerate(steps):
        print(f"  {i+1}. {s}")

    executor = Executor(client, model)
    answer = executor.execute_plan(task, steps)

    print(f"\n=== 最终答案 ===\n{answer}\n")


if __name__ == "__main__":
    main()
