"""
多 agent 协作 · Planner + BrowserWorker + Summarizer
=====================================================

这是 Bread 系列 4+1 课的合流点：

  Planner    —— 拆"研究 X"成多个子研究任务（输出 JSON）
  BrowserWorker —— 每个子任务派一个，调浏览器工具去抓数据
  Summarizer —— 汇总所有子任务结果，写终稿

每个 BrowserWorker 都是一个**完整的小 agent**（带工具循环），但作用域受限——
只在一个 url + 一个目标的小任务上工作。完成后销毁。

这是 OpenAI Deep Research / Perplexity Pro 等"研究型 agent"产品的核心架构。
"""

import json
import re
from typing import Any

from openai import OpenAI


# =========================================================
# 浏览器工具（沿用 Bread Browser ch05 的简化版）
# =========================================================
EXTRACT_JS = r"""
() => {
  document.querySelectorAll('[data-bread-id]').forEach(el => el.removeAttribute('data-bread-id'));
  const SELECTOR = ['button', 'input', 'a', 'select', '[role="button"]', '[role="link"]'].join(',');
  const candidates = Array.from(document.querySelectorAll(SELECTOR));
  const result = [];
  let idx = 0;
  for (const el of candidates) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    el.setAttribute('data-bread-id', String(idx));
    result.push({
      idx: idx, tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || el.placeholder || '').trim().slice(0, 80),
      href: el.href || '',
    });
    idx += 1;
  }
  return result;
}
"""


def format_elements(elements):
    lines = []
    for el in elements:
        line = f"[{el['idx']}] <{el['tag']}> {el['text']}"
        if el["href"] and el["tag"] == "a":
            h = el["href"]
            if len(h) > 60:
                h = h[:57] + "..."
            line += f"  → {h}"
        lines.append(line)
    return "\n".join(lines)


WORKER_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "open_url",
            "description": "Navigate to a URL.",
            "parameters": {
                "type": "object",
                "properties": {"url": {"type": "string"}},
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "click",
            "description": "Click element by [index] from latest page snapshot.",
            "parameters": {
                "type": "object",
                "properties": {"index": {"type": "integer"}},
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "extract_text",
            "description": "Read text by CSS selector. Returns matched texts joined by ---.",
            "parameters": {
                "type": "object",
                "properties": {"selector": {"type": "string"}},
                "required": ["selector"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "report",
            "description": "Submit findings for this sub-task and exit.",
            "parameters": {
                "type": "object",
                "properties": {"findings": {"type": "string", "description": "Detailed findings, multiple paragraphs ok."}},
                "required": ["findings"],
            },
        },
    },
]


# =========================================================
# BrowserWorker —— 单子任务 agent，跑完即销毁
# =========================================================
class BrowserWorker:
    SYSTEM = (
        "You are a focused web research worker. You have ONE sub-task. "
        "Tools: open_url / click(index) / extract_text(css) / report(findings).\n"
        "\n"
        "Workflow:\n"
        "1. open_url to your starting URL\n"
        "2. Use extract_text with sensible CSS selectors to read content\n"
        "3. Click links if needed to navigate deeper (use the [index] from the latest snapshot)\n"
        "4. When you have what was asked, call `report` and stop.\n"
        "\n"
        "Rules:\n"
        "- Stay focused on YOUR sub-task only; ignore unrelated content.\n"
        "- Don't open the same URL twice.\n"
        "- Maximum 8 actions total — be efficient."
    )
    MAX_STEPS = 8

    def __init__(self, client: OpenAI, model: str, page):
        self.client = client
        self.model = model
        self.page = page
        self.messages = [{"role": "system", "content": self.SYSTEM}]

    def _snapshot(self) -> str:
        elements = self.page.evaluate(EXTRACT_JS)
        return format_elements(elements)

    def _with_snapshot(self, action_result):
        try:
            self.page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        self.page.wait_for_timeout(300)
        return f"{action_result}\n\nCurrent page (URL: {self.page.url}):\n{self._snapshot()}"

    def _execute(self, name, args) -> str:
        if name == "open_url":
            self.page.goto(args["url"])
            return self._with_snapshot(f"opened {args['url']}")
        if name == "click":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').click()
            return self._with_snapshot(f"clicked [{args['index']}]")
        if name == "extract_text":
            try:
                texts = self.page.locator(args["selector"]).all_inner_texts()
            except Exception as e:
                return f"extract_text failed: {e}"
            if not texts:
                return f"(selector {args['selector']!r} matched nothing)"
            joined = "\n---\n".join(t.strip() for t in texts if t.strip())
            if len(joined) > 3000:
                joined = joined[:3000] + "\n...[truncated]"
            return f"Extracted from {args['selector']!r}:\n{joined}"
        return f"unknown tool: {name}"

    def run(self, subtask_description: str, starting_url: str) -> str:
        self.messages.append({
            "role": "user",
            "content": (
                f"Sub-task: {subtask_description}\n"
                f"Suggested starting URL: {starting_url}\n"
                f"Open it and gather what's asked."
            ),
        })
        for step in range(self.MAX_STEPS):
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=WORKER_TOOLS, temperature=0.2,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)
            if not msg.tool_calls:
                # Worker should always end via report; if it didn't, return its text content
                return msg.content or "(no findings)"
            for call in msg.tool_calls:
                args = json.loads(call.function.arguments or "{}")
                name = call.function.name
                if name == "report":
                    return args.get("findings", "")
                arg_repr = list(args.values())[0] if args else ""
                if isinstance(arg_repr, str) and len(arg_repr) > 60:
                    arg_repr = arg_repr[:57] + "..."
                print(f"      [worker step {step}] {name}({arg_repr})")
                try:
                    result = self._execute(name, args)
                except Exception as e:
                    result = f"action failed: {type(e).__name__}: {e}"
                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": str(result),
                })
        return "[worker reached MAX_STEPS without report]"


# =========================================================
# Planner —— 把研究主题拆成 2-3 个子任务
# =========================================================
class Planner:
    SYSTEM = (
        "你是研究规划师。给你一个研究主题和一个目标网站，"
        "你要拆出 **2-3 个具体的子研究任务**，每个由一个 worker agent 独立执行。\n"
        "\n"
        "输出**严格 JSON**：\n"
        "[\n"
        '  {\"label\": \"短标签\", \"description\": \"子任务描述\", \"starting_url\": \"https://...\"},\n'
        "  ...\n"
        "]\n"
        "\n"
        "规则：\n"
        "1. 每个子任务**独立**，不依赖其它子任务的结果。\n"
        "2. starting_url 必须是目标网站的具体 URL（不一定是首页）。\n"
        "3. description 要包含'要找什么'的具体指令（如：'抽出所有 quote 文本和作者'）。\n"
        "4. 不要 markdown 代码块、不要额外文字。"
    )

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

    def plan(self, topic: str, base_url: str) -> list[dict]:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content": f"研究主题：{topic}\n目标网站根：{base_url}"},
            ],
            temperature=0.3,
        )
        text = (resp.choices[0].message.content or "").strip()
        if text.startswith("```"):
            text = text.strip("`").lstrip("json").strip()
        last_bracket = text.rfind("]")
        if last_bracket != -1:
            text = text[: last_bracket + 1]
        return json.loads(text)


# =========================================================
# Summarizer —— 汇总所有 worker 的发现，写终稿
# =========================================================
class Summarizer:
    SYSTEM = (
        "你是研究报告撰写人。给你一份研究主题和多份子任务发现，"
        "你要写一篇**结构清晰的中文研究报告**。\n"
        "\n"
        "格式：\n"
        "# 标题\n"
        "## 摘要（2-3 句）\n"
        "## 主要发现（每个子任务一段，引用具体内容）\n"
        "## 总结（1 段）\n"
        "\n"
        "规则：\n"
        "- 全文 400-700 字。\n"
        "- 引用必须出自下面的子任务发现，不要凭记忆补充。\n"
        "- 如果某子任务发现为空或失败，要在报告里如实说明。"
    )

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

    def write(self, topic: str, findings_by_label: dict[str, str]) -> str:
        findings_block = "\n\n".join(
            f"=== 子任务 [{label}] 的发现 ===\n{content}"
            for label, content in findings_by_label.items()
        )
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content": f"研究主题：{topic}\n\n{findings_block}"},
            ],
            temperature=0.4,
        )
        return (resp.choices[0].message.content or "").strip()
