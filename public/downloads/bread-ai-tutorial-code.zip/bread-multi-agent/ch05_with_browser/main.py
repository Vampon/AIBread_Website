"""
第 5 章 · Multi-Agent + Bread Browser（终章）
==============================================

四阶段：
  1. Planner 把研究主题拆成 2-3 个子任务（含 starting_url + description）
  2. 每个子任务派一个 BrowserWorker，调浏览器去抓内容
  3. 收集所有 worker 的 findings
  4. Summarizer 汇总成研究报告

这是 OpenAI Deep Research / Perplexity Pro 等"研究 agent"产品的**最小可用样态**。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

from agents import Planner, BrowserWorker, Summarizer


def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    topic = "quotes.toscrape.com 上'love'、'life'、'humor'三个标签下的代表性引言"
    base_url = "https://quotes.toscrape.com"

    out_dir = HERE / "output"
    out_dir.mkdir(exist_ok=True)

    # ---- 阶段 1: Planner ----
    print(f"=== 研究主题 ===\n{topic}\n")
    print("=== 阶段 1: Planner 在拆任务 ===")
    planner = Planner(client, model)
    subtasks = planner.plan(topic, base_url)
    for i, t in enumerate(subtasks, 1):
        print(f"  {i}. [{t['label']}] {t['description']}")
        print(f"     起始 URL: {t['starting_url']}")
    (out_dir / "01_plan.json").write_text(
        __import__("json").dumps(subtasks, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # ---- 阶段 2: 派 worker ----
    print(f"\n=== 阶段 2: 派 {len(subtasks)} 个 BrowserWorker 同时干活 ===\n")
    findings = {}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        for i, task in enumerate(subtasks, 1):
            print(f"  --- Worker {i}/{len(subtasks)}  [{task['label']}] ---")
            # 每个 worker 用独立的 page（同一个 browser 实例下，互不污染）
            page = browser.new_page()
            worker = BrowserWorker(client, model, page)
            findings[task["label"]] = worker.run(task["description"], task["starting_url"])
            print(f"     ✓ findings 长度：{len(findings[task['label']])} 字")
            page.close()
        browser.close()

    (out_dir / "02_findings.json").write_text(
        __import__("json").dumps(findings, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # ---- 阶段 3: Summarizer ----
    print(f"\n=== 阶段 3: Summarizer 写终稿 ===")
    summarizer = Summarizer(client, model)
    report = summarizer.write(topic, findings)

    (out_dir / "03_report.md").write_text(report, encoding="utf-8")
    print(f"\n=== 最终研究报告 ===\n{report}\n")
    print(f"\n所有产物已存到 {out_dir}/")
    print(f"  01_plan.json     - Planner 的子任务计划")
    print(f"  02_findings.json - 各 worker 的发现")
    print(f"  03_report.md     - Summarizer 写的终稿")


if __name__ == "__main__":
    main()
