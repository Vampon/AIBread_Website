"""
第 0 章 · Dialogue
==================

多 agent 系统的"Hello World"：两个 LLM 实例**交替对话**。

核心思想：
  一个 agent 的 'user message' 可以是**另一个 agent 的 assistant message**。

只要会做这一件事，所有更高级的 multi-agent 模式都建立在它之上。

demo 场景：
  Agent A = Python 拥护者
  Agent B = Go 拥护者
  让他们辩论 3 轮"哪个语言更适合写 AI agent"。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")


class Speaker:
    """一个最简 agent —— 持有自己的 messages 列表 + 一句 system prompt。"""

    def __init__(self, client: OpenAI, model: str, name: str, persona: str):
        self.client = client
        self.model = model
        self.name = name
        # 注意：persona 里要明确告诉它"对方说什么算 user，你说什么算 assistant"
        self.messages = [{"role": "system", "content": persona}]

    def hear(self, text: str) -> None:
        """听到对方说的话 → 作为 user message 存进自己的历史。"""
        self.messages.append({"role": "user", "content": text})

    def speak(self) -> str:
        """根据当前历史生成自己的回复，记进自己的历史并返回。"""
        resp = self.client.chat.completions.create(
            model=self.model, messages=self.messages, temperature=0.7,
        )
        text = resp.choices[0].message.content or ""
        self.messages.append({"role": "assistant", "content": text})
        return text


def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    alice = Speaker(
        client, model, name="Alice",
        persona=(
            "你是 Alice，一个资深 Python 开发者。你坚信 Python 是写 AI agent 最好的语言。"
            "对方是 Bob，他更喜欢 Go。\n"
            "规则：每次回复 2-3 句话，论据具体（不要喊口号），可以反驳对方上一句话。"
            "保持友好但坚定。"
        ),
    )
    bob = Speaker(
        client, model, name="Bob",
        persona=(
            "你是 Bob，一个资深 Go 开发者。你坚信 Go 在性能、部署、并发上完胜 Python，更适合生产级 AI agent。"
            "对方是 Alice，她偏 Python。\n"
            "规则：每次回复 2-3 句话，论据具体（不要喊口号），可以反驳对方上一句话。"
            "保持友好但坚定。"
        ),
    )

    # 开局由 Alice 主动起话题
    opening = "Bob，我们来辩论一下：写 AI agent，Python 显然比 Go 更合适，你怎么看？"
    alice.messages.append({"role": "assistant", "content": opening})
    print(f"\n🐍 Alice: {opening}\n")

    last_utterance = opening
    speakers = [bob, alice]  # 下一个轮到 Bob

    ROUNDS = 6  # 共 6 个发言（Alice 开场后，两人各再说 3 轮）
    for i in range(ROUNDS):
        speaker = speakers[i % 2]
        speaker.hear(last_utterance)
        reply = speaker.speak()
        emoji = "🦫" if speaker.name == "Bob" else "🐍"
        print(f"{emoji} {speaker.name}: {reply}\n")
        last_utterance = reply

    print("=" * 50)
    print("辩论结束。两 agent 各自的对话历史长度：")
    print(f"  Alice messages: {len(alice.messages)}")
    print(f"  Bob   messages: {len(bob.messages)}")


if __name__ == "__main__":
    main()
