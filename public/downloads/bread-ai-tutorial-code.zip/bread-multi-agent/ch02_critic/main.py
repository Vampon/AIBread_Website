"""
第 2 章 · Critic
================

在 Executor 之后加一个 Critic agent，形成**生产-审查回路**：

  Executor 出稿 → Critic 评分 → 不达标 → Executor 改 → Critic 再评 → ...

这是内容生产场景的标配——写作、代码、报告。

demo 任务：
  "写一条不超过 140 字的中文推特，主题是 Python 的 GIL。"
  要求：风格机智、技术准确、长度合规。
"""

import json
import os
import re
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")


# =========================================================
# Executor —— 出稿
# =========================================================
class Executor:
    SYSTEM = (
        "你是一位机智、懂技术的中文 Twitter 内容创作者。\n"
        "用户会给你一个题目和反馈。你的任务：写一条**不超过 140 字**的中文推特。\n"
        "\n"
        "规则：\n"
        "- 严格控制字数（含标点、emoji 算字符）。\n"
        "- 既要机智有梗，也要技术准确。\n"
        "- 只输出推特正文，不要解释、不要前后缀。\n"
        "- 如果用户给了 Critic 反馈，**针对性修改**而不是从头重写。"
    )

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model
        self.messages = [{"role": "system", "content": self.SYSTEM}]

    def write(self, instruction: str) -> str:
        self.messages.append({"role": "user", "content": instruction})
        resp = self.client.chat.completions.create(
            model=self.model, messages=self.messages, temperature=0.7,
        )
        text = (resp.choices[0].message.content or "").strip()
        self.messages.append({"role": "assistant", "content": text})
        return text


# =========================================================
# Critic —— 评分 + 反馈
# =========================================================
class Critic:
    SYSTEM = (
        "你是一位严格的中文内容编辑。用户会给你一条推特草稿和原始需求。\n"
        "你的工作：\n"
        "1. 检查长度（≤140 字符）\n"
        "2. 检查机智度（是否有梗 / 反差 / 笑点）\n"
        "3. 检查技术准确性\n"
        "4. 综合打分 1-10\n"
        "\n"
        "输出**严格 JSON**：{\"score\": int, \"pass\": bool, \"feedback\": str}\n"
        "- pass = true 当且仅当 score >= 8 且所有硬指标（长度）合格。\n"
        "- feedback 是给作者的具体修改建议（不超过 60 字）。\n"
        "- 不要任何额外文字、不要 markdown 代码块。"
    )

    def __init__(self, client: OpenAI, model: str):
        self.client = client
        self.model = model

    def review(self, original_task: str, draft: str) -> dict:
        # 无状态：每次重置 messages，避免被前一轮 bias
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content": f"原始需求：{original_task}\n\n草稿：\n{draft}"},
            ],
            temperature=0.2,
        )
        text = (resp.choices[0].message.content or "").strip()
        # 容错剥皮
        if text.startswith("```"):
            text = text.strip("`")
            if text.startswith("json"):
                text = text[4:]
        # 末尾可能有解释，截到最后一个 }
        last_brace = text.rfind("}")
        if last_brace != -1:
            text = text[: last_brace + 1]
        try:
            return json.loads(text.strip())
        except json.JSONDecodeError:
            # 最后兜底：正则抠 score / pass
            score_m = re.search(r'"score"\s*:\s*(\d+)', text)
            pass_m = re.search(r'"pass"\s*:\s*(true|false)', text)
            return {
                "score": int(score_m.group(1)) if score_m else 0,
                "pass": pass_m and pass_m.group(1) == "true",
                "feedback": "(Critic 返回非 JSON，已兜底)",
            }


# =========================================================
# 主流程：生产-审查回路
# =========================================================
def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    task = "写一条不超过 140 字的中文推特，主题是 Python 的 GIL。要求风格机智、技术准确。"
    MAX_ROUNDS = 4

    executor = Executor(client, model)
    critic = Critic(client, model)

    print(f"=== 任务 ===\n{task}\n")

    instruction = task  # 第一轮直接传任务
    final_draft = ""
    for round_idx in range(1, MAX_ROUNDS + 1):
        print(f"\n--- Round {round_idx} ---")
        draft = executor.write(instruction)
        print(f"📝 Executor 草稿（{len(draft)} 字符）：\n{draft}")

        review = critic.review(task, draft)
        score = review.get("score", 0)
        passed = review.get("pass", False)
        feedback = review.get("feedback", "")
        print(f"🔎 Critic 评分：{score}/10  通过：{passed}")
        print(f"   反馈：{feedback}")

        final_draft = draft
        if passed:
            print("\n✅ 审查通过！")
            break
        # 把 Critic 反馈作为下一轮 Executor 的 instruction
        instruction = f"Critic 给出反馈：{feedback}\n请针对性修改你的上一稿，重新输出推特正文。"
    else:
        print(f"\n⚠️  达到最大轮数 {MAX_ROUNDS}，仍未通过。返回最后一稿。")

    print(f"\n=== 最终稿 ===\n{final_draft}")


if __name__ == "__main__":
    main()
