# Bread Multi-Agent · 从零搭建多智能体协作系统

> 知识星球付费课程 · 第五部 · ~520 行 Python · Python 新手友好

---

## 这一课在解决什么问题

前四课你已经能用**一个 agent**做很多事：

- 多轮对话（Bread Agent）
- 调内部 API（Bread MCP）
- 查知识库（Bread RAG）
- 操作浏览器（Bread Browser）

但**单 agent 有天花板**。三个真实痛点：

### 痛点 1：上下文越来越长

一个 agent 同时干"研究 + 写作 + 校对"——messages 累积 50+ 轮 → token 飙升 → 模型注意力下降 → 结果质量变差。

### 痛点 2：角色冲突

让一个 agent 既是"创作者"又是"批评者"——它会**自相矛盾**或**自我夸赞**。LLM 不擅长在同一对话里切换价值观。

### 痛点 3：工具集爆炸

一个 agent 挂 30 个工具——LLM 不知道何时调谁。**工具数 > 10 准确率显著下降**（实测）。

**多 agent 协作模式解决这三个问题**：

```
              ┌──────────┐
              │  Planner │ 拆任务
              └────┬─────┘
                   ↓
      ┌─────┬─────┴─────┬─────┐
      ↓     ↓           ↓     ↓
   Coder  Writer    Researcher  ...   ← 每个 agent 只懂自己那摊
      └─────┴─────┬─────┴─────┘
                   ↓
              ┌──────────┐
              │ Verifier │ 审查
              └──────────┘
```

每个 agent **角色单一、上下文短、工具少** —— 反而更强。

这是 CrewAI / AutoGen / LangGraph multi-agent / OpenAI Swarm 等主流框架的共同思想。

---

## 章节地图

```
ch00 dialogue        ──── 两个 agent 互发消息（最小模型）
     │
ch01 planner_exec    ──── Planner 拆任务 / Executor 执行
     │
ch02 critic          ──── + Critic 形成"生产-审查"回路
     │
ch03 router          ──── Router 智能分发到专家 agent
     │
ch04 pipeline        ──── 多阶段流水线写博客（researcher → outliner → writer → editor）
     │
ch05 with_browser ★  ──── 多 agent 协作 + Bread Browser（四课合体）
```

每章 README 沿用 5 段式：故事 → 跑起来 → 逐行精讲 → FAQ → 思考题。

---

## 零基础准备

跟前 4 课**共用**环境：

```
pip install -r requirements.txt
```

复制 Bread Agent / Bread Browser 的 `.env` 文件过来即可。

ch05 额外需要 Playwright（学到那一章再装）：

```
pip install playwright
python -m playwright install chromium
```

---

## 五个核心模式（学完你能掌握的）

| 模式 | 教学位置 | 真实场景 |
|---|---|---|
| **对话（dialogue）** | ch00 | 辩论、谈判模拟、role-play 训练 |
| **Planner-Executor** | ch01 | 复杂任务拆解（"装修我家"） |
| **Critic / 评分循环** | ch02 | 内容生产质量保障 |
| **Router / 分发** | ch03 | 客服系统按问题类型路由 |
| **Pipeline / 流水线** | ch04 | 内容生产、数据加工 |
| **混合（含工具）** | ch05 | 真实业务自动化 |

---

## 工程约束（沿用 Bread 系列）

- Python 3.10+
- **纯同步**
- 只依赖 `openai` + `python-dotenv`（ch05 再加 playwright）
- 每章独立目录、互不依赖、`diff` 可读
- Windows / macOS / Linux 通用

---

## 目录

- ch00_dialogue —— 最简两 agent 对话
- ch01_planner_executor —— Planner + Executor
- ch02_critic —— 加 Critic 回路
- ch03_router —— Router 分发
- ch04_pipeline —— 流水线
- ch05_with_browser —— 多 agent + 浏览器

---

**祝玩得开心。一个 agent 不够用的时候，就让它们组队。**

> —— Bread Multi-Agent 课程 · 知识星球
