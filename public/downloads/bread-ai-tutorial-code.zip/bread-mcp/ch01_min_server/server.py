"""
第 1 章 · 最简 MCP server
=========================

这是一个真正可以被任何 MCP client（包括 Claude Code、Cursor）调用的服务器。
它只暴露一个工具：echo —— 把你传入的字符串原样返回。

MCP server 的本质很简单：
  1. 在 stdin 上死循环读一行 JSON
  2. 看 method 字段决定做什么
  3. 把响应 JSON 写到 stdout
  4. 把日志写到 stderr（绝对不能写到 stdout——会污染协议通信）

MCP 协议规定了 3 个最基础的方法：
  - initialize         : 握手，交换协议版本和能力
  - tools/list          : 列出本 server 提供的工具
  - tools/call          : 调用一个工具

我们这一章就实现这 3 个。
"""

import json
import sys

# ★ Windows 上 server 的 stdin/stdout 默认 cp936/GBK。
#    MCP 协议消息必须 UTF-8，否则 client 解码就崩。
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PROTOCOL_VERSION = "2024-11-05"  # MCP 协议版本字符串（参见 spec.modelcontextprotocol.io）
SERVER_NAME = "bread-mcp-echo"
SERVER_VERSION = "0.1.0"


# ============================================================
# 日志：必须写 stderr，stdout 留给协议
# ============================================================
def log(msg: str):
    sys.stderr.write(f"[server] {msg}\n")
    sys.stderr.flush()


# ============================================================
# 发送 / 接收 JSON-RPC
# ============================================================
def send(obj: dict):
    line = json.dumps(obj, ensure_ascii=False)
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def recv() -> dict | None:
    """读一行 stdin，解析为 dict。EOF 时返回 None。"""
    line = sys.stdin.readline()
    if not line:
        return None
    return json.loads(line.strip())


# ============================================================
# 工具：echo —— 我们的"业务逻辑"
# ============================================================
def tool_echo(text: str) -> str:
    return f"echo: {text}"


# 工具的 JSON Schema（MCP client 会读这个来知道工具长啥样）
TOOLS = [
    {
        "name": "echo",
        "description": "把传入的字符串原样回声出来，前面加上 'echo: ' 前缀。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "想被回声的字符串"},
            },
            "required": ["text"],
        },
    },
]


# ============================================================
# 协议方法的实现
# ============================================================
def handle_initialize(params: dict) -> dict:
    """握手响应。客户端会告诉我们它支持什么；我们告诉它我们支持什么。"""
    client_info = params.get("clientInfo", {})
    log(f"initialize from {client_info.get('name', '?')} {client_info.get('version', '')}")
    return {
        "protocolVersion": PROTOCOL_VERSION,
        "capabilities": {
            "tools": {},  # 表示我们提供 tools。空 dict 即可，里面可以加 listChanged 等子能力
        },
        "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
    }


def handle_tools_list() -> dict:
    return {"tools": TOOLS}


def handle_tools_call(params: dict) -> dict:
    name = params.get("name")
    arguments = params.get("arguments", {})
    if name == "echo":
        result_text = tool_echo(**arguments)
        return {
            # MCP 规定 content 是一个数组，每项可以是 text/image/...
            "content": [{"type": "text", "text": result_text}],
            "isError": False,
        }
    raise ValueError(f"unknown tool: {name}")


# ============================================================
# 主循环：按行读 stdin → dispatch → 写响应到 stdout
# ============================================================
def main():
    log(f"started, protocol={PROTOCOL_VERSION}")
    while True:
        try:
            req = recv()
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": f"Parse error: {e}"}})
            continue

        if req is None:
            log("EOF, exiting")
            break

        method = req.get("method")
        params = req.get("params") or {}
        req_id = req.get("id")  # 通知形态没有 id

        log(f"<-- method={method} id={req_id}")

        # 通知（无 id）：处理但不返回响应
        if method == "notifications/initialized":
            log("client initialized")
            continue

        try:
            if method == "initialize":
                result = handle_initialize(params)
            elif method == "tools/list":
                result = handle_tools_list()
            elif method == "tools/call":
                result = handle_tools_call(params)
            else:
                send({
                    "jsonrpc": "2.0", "id": req_id,
                    "error": {"code": -32601, "message": f"Method not found: {method}"},
                })
                continue

            send({"jsonrpc": "2.0", "id": req_id, "result": result})

        except Exception as e:
            log(f"!! error: {type(e).__name__}: {e}")
            send({
                "jsonrpc": "2.0", "id": req_id,
                "error": {"code": -32603, "message": str(e)},
            })


if __name__ == "__main__":
    main()
