"""
手工测试 server.py
==================

这个脚本不是 client。它只是个"手工喂请求"的便利工具——
spawn server 子进程，然后用 stdin/stdout 跟它对话，
打印每一次交互。让你**亲眼看见**协议消息长什么样。

下一章 ch02 我们会写真正的 client 类，把这套流程封装好。
"""

import json
import subprocess
import sys
from pathlib import Path

# Windows 控制台 UTF-8（防中文乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SERVER = str(Path(__file__).parent / "server.py")


def main():
    # 用虚拟环境的 Python 路径调起 server；学员自己跑用 sys.executable 就行
    proc = subprocess.Popen(
        [sys.executable, SERVER],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        bufsize=1,
    )

    def send(obj):
        line = json.dumps(obj, ensure_ascii=False)
        print(f"\n--> {line}")
        proc.stdin.write(line + "\n")
        proc.stdin.flush()

    def recv():
        line = proc.stdout.readline().strip()
        print(f"<-- {line}")
        return json.loads(line) if line else None

    # 1) 握手
    send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
          "params": {"protocolVersion": "2024-11-05",
                     "capabilities": {},
                     "clientInfo": {"name": "test-by-hand", "version": "0.1.0"}}})
    recv()

    # 2) 通知 server 我已就绪
    send({"jsonrpc": "2.0", "method": "notifications/initialized"})
    # 通知没有响应

    # 3) 列工具
    send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
    recv()

    # 4) 调用 echo
    send({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
          "params": {"name": "echo", "arguments": {"text": "你好 MCP"}}})
    recv()

    # 5) 调一个不存在的方法
    send({"jsonrpc": "2.0", "id": 4, "method": "no_such_method"})
    recv()

    # 关闭 stdin —— server 读到 EOF 会自己退出
    proc.stdin.close()
    proc.wait(timeout=5)
    print("\n=== server 退出，返回码 =", proc.returncode)
    # 把 server 的 stderr 日志也打出来，让你看见服务端那一侧的视角
    err = proc.stderr.read()
    if err:
        print("=== server stderr ===")
        print(err)


if __name__ == "__main__":
    main()
