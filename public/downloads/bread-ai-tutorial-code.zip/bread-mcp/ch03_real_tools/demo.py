"""演示：用 client 连 fs server，依次调 3 个工具。"""

import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from client import MCPClient

HERE = Path(__file__).parent


def main():
    server_cmd = [sys.executable, str(HERE / "server.py")]
    with MCPClient(server_cmd) as c:
        print(f"已连接: {c.server_info['name']} v{c.server_info['version']}")

        print("\n--- list_tools ---")
        for t in c.list_tools():
            print(f"  {t['name']:10s} {t['description']}")

        print("\n--- 调 get_time ---")
        text, err = c.call_tool("get_time")
        print(f"  结果: {text}  (error={err})")

        print("\n--- 调 list_dir(.) ---")
        text, err = c.call_tool("list_dir", path=str(HERE))
        print(f"  结果:\n{text}")

        print("\n--- 调 read_file(README.md) ---")
        text, err = c.call_tool("read_file", path=str(HERE / "README.md"))
        print(f"  前 200 字: {text[:200]}...")

        print("\n--- 调一个会出错的：read_file(不存在的文件) ---")
        text, err = c.call_tool("read_file", path="/no/such/file/here.xxx")
        print(f"  isError={err}, 错误信息: {text}")


if __name__ == "__main__":
    main()
