"""
第 3 章 · 真实工具集 MCP server
================================

ch01 的 server 只有一个 echo——纯纯演示。这一章我们升级到 3 个真有用的工具：

    read_file(path)     读取文本文件
    list_dir(path)      列出目录内容
    get_time()          返回当前时间

工程上的关键变化：
    1. 用 **dispatch 表** 注册工具（不再 if-elif 一坨）
    2. **每个工具的 schema 跟实现配对存放**（看 TOOL_REGISTRY）
    3. 添加**错误友好返回** —— 工具执行报错时返回 isError=true 而不是抛
    4. 添加**资源类工具结果**示例（read_file 的内容截断）

这就是工业级 MCP server 的基础模板。
"""

import json
import sys
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "bread-mcp-fs"
SERVER_VERSION = "0.1.0"


def log(msg: str):
    sys.stderr.write(f"[server] {msg}\n")
    sys.stderr.flush()


def send(obj: dict):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def recv() -> dict | None:
    line = sys.stdin.readline()
    return json.loads(line.strip()) if line else None


# ============================================================
# 工具实现
# ============================================================

def tool_read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def tool_list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def tool_get_time() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================
# 工具注册表：name → (schema, impl)
#
# 工具数量一多，if/elif dispatch 就丑了。改用 dict 注册表：
#   - 加新工具只要往 TOOL_REGISTRY 加一项，handle_tools_call 不用动
#   - schema 和实现写在一起，不容易漏改
# ============================================================

TOOL_REGISTRY: dict[str, dict] = {
    "read_file": {
        "schema": {
            "name": "read_file",
            "description": "读取一个文本文件的内容（超过 4000 字会截断）。",
            "inputSchema": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "文件路径"}},
                "required": ["path"],
            },
        },
        "impl": tool_read_file,
    },
    "list_dir": {
        "schema": {
            "name": "list_dir",
            "description": "列出一个目录下的文件和子目录。",
            "inputSchema": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "目录路径，默认当前目录"}},
                "required": [],
            },
        },
        "impl": tool_list_dir,
    },
    "get_time": {
        "schema": {
            "name": "get_time",
            "description": "返回服务器当前的本地时间（精确到秒）。",
            "inputSchema": {"type": "object", "properties": {}, "required": []},
        },
        "impl": tool_get_time,
    },
}


# ============================================================
# 协议方法
# ============================================================
def handle_initialize(params: dict) -> dict:
    client = params.get("clientInfo", {})
    log(f"initialize from {client.get('name', '?')}")
    return {
        "protocolVersion": PROTOCOL_VERSION,
        "capabilities": {"tools": {}},
        "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
    }


def handle_tools_list() -> dict:
    return {"tools": [t["schema"] for t in TOOL_REGISTRY.values()]}


def handle_tools_call(params: dict) -> dict:
    name = params.get("name")
    arguments = params.get("arguments", {}) or {}

    entry = TOOL_REGISTRY.get(name)
    if entry is None:
        # 协议层错误：方法（工具）不存在
        raise ValueError(f"unknown tool: {name}")

    # ★ 工具执行失败 → 不抛异常，而是用 isError=true 返回。
    #    这是 MCP 规范推荐做法 —— 让调用方（agent）能从错误信息恢复，
    #    跟 Bread Agent ch02 的"错误回喂"思想一致。
    try:
        result = entry["impl"](**arguments)
        return {
            "content": [{"type": "text", "text": str(result)}],
            "isError": False,
        }
    except Exception as e:
        return {
            "content": [{"type": "text", "text": f"{type(e).__name__}: {e}"}],
            "isError": True,
        }


# ============================================================
# 主循环（跟 ch01 同款）
# ============================================================
HANDLERS = {
    "initialize": lambda p: handle_initialize(p),
    "tools/list": lambda p: handle_tools_list(),
    "tools/call": lambda p: handle_tools_call(p),
}


def main():
    log(f"started, tools={list(TOOL_REGISTRY.keys())}")
    while True:
        try:
            req = recv()
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "id": None,
                  "error": {"code": -32700, "message": f"Parse error: {e}"}})
            continue
        if req is None:
            break

        method = req.get("method")
        params = req.get("params") or {}
        req_id = req.get("id")

        if method == "notifications/initialized":
            continue

        handler = HANDLERS.get(method)
        if not handler:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32601, "message": f"Method not found: {method}"}})
            continue

        try:
            result = handler(params)
            send({"jsonrpc": "2.0", "id": req_id, "result": result})
        except Exception as e:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32603, "message": str(e)}})

    log("EOF")


if __name__ == "__main__":
    main()
