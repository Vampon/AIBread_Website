"""
第 2 章 · 最简 MCP client（class MCPClient）
============================================

ch01 的 test_by_hand.py 是个一次性脚本，把所有逻辑堆在 main 里。
这一章我们把它**抽象成一个类**：MCPClient。

类的好处：
  - request id 自动维护（不用每次自己写 id=1, id=2...）
  - 完整握手封装在 .connect()
  - 调工具就一个方法：.call_tool("echo", text="...")
  - .close() 优雅关闭

这个 MCPClient 就是 ch04 接入 Bread Agent 时直接用的"基础设施"。
"""

import json
import subprocess
import sys
from pathlib import Path
from typing import List, Optional, Dict

PROTOCOL_VERSION = "2024-11-05"
CLIENT_NAME = "bread-mcp-client"
CLIENT_VERSION = "0.1.0"


class MCPClient:
    """通过 stdio 跟一个 MCP server 通信的客户端。

    用法：
        with MCPClient([sys.executable, "server.py"]) as client:
            tools = client.list_tools()
            result = client.call_tool("echo", text="hello")
    """

    def __init__(self, server_command: List[str]):
        self.server_command = server_command
        self.proc: Optional[subprocess.Popen] = None
        self._next_id = 1
        self.server_info: dict = {}
        self.server_capabilities: dict = {}

    # -------- 上下文管理：with ... as client --------
    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    # -------- 启动子进程 + 完整握手 --------
    def connect(self):
        self.proc = subprocess.Popen(
            self.server_command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            encoding="utf-8",
            bufsize=1,
        )

        # 1) initialize 握手
        init_result = self._request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
        })
        self.server_info = init_result.get("serverInfo", {})
        self.server_capabilities = init_result.get("capabilities", {})

        # 2) 通知 server "我准备好了"——这一步是 MCP 协议要求的
        self._notify("notifications/initialized")

    # -------- 关闭 --------
    def close(self):
        if not self.proc:
            return
        try:
            self.proc.stdin.close()
            self.proc.wait(timeout=5)
        except Exception:
            self.proc.kill()
        self.proc = None

    # -------- 通用：发请求 + 等响应 --------
    def _request(self, method: str, params: Optional[Dict] = None) -> dict:
        req_id = self._next_id
        self._next_id += 1
        req = {"jsonrpc": "2.0", "id": req_id, "method": method}
        if params is not None:
            req["params"] = params
        self._write(req)

        resp = self._read()
        if resp.get("id") != req_id:
            raise RuntimeError(f"id 不匹配: 发 {req_id}，收 {resp.get('id')}")

        if "error" in resp:
            err = resp["error"]
            raise RuntimeError(f"server error {err.get('code')}: {err.get('message')}")

        return resp.get("result", {})

    # -------- 通用：发通知（无响应）--------
    def _notify(self, method: str, params: Optional[Dict] = None):
        req = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            req["params"] = params
        self._write(req)

    def _write(self, obj: dict):
        line = json.dumps(obj, ensure_ascii=False)
        self.proc.stdin.write(line + "\n")
        self.proc.stdin.flush()

    def _read(self) -> dict:
        line = self.proc.stdout.readline()
        if not line:
            raise RuntimeError("server 提前关闭 stdout")
        return json.loads(line.strip())

    # -------- MCP 高层 API --------
    def list_tools(self) -> List[dict]:
        return self._request("tools/list").get("tools", [])

    def call_tool(self, name: str, **arguments) -> str:
        """调一个工具，把结果中所有 text content 拼起来返回。"""
        result = self._request("tools/call", {"name": name, "arguments": arguments})
        if result.get("isError"):
            return f"[tool error] " + "".join(
                c.get("text", "") for c in result.get("content", [])
            )
        return "".join(c.get("text", "") for c in result.get("content", []) if c.get("type") == "text")


# ============================================================
# Demo：连上 server.py，列工具，调 echo
# ============================================================
def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    server_cmd = [sys.executable, str(Path(__file__).parent / "server.py")]

    with MCPClient(server_cmd) as client:
        print(f"已连接 server: {client.server_info}")
        print(f"server 能力: {client.server_capabilities}")

        print("\n--- 工具列表 ---")
        for t in client.list_tools():
            print(f"  {t['name']}: {t['description']}")

        print("\n--- 调用 echo ---")
        result = client.call_tool("echo", text="你好 MCP")
        print(f"  结果: {result}")

        print("\n--- 再调一次 ---")
        result = client.call_tool("echo", text="Hello again")
        print(f"  结果: {result}")


if __name__ == "__main__":
    main()
