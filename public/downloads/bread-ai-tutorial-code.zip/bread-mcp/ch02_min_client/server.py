"""跟 ch01 完全一致的 echo server（搬过来一份，让本章独立可跑）。"""

import json
import sys
from typing import Optional

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "bread-mcp-echo"
SERVER_VERSION = "0.1.0"


def log(msg: str):
    sys.stderr.write(f"[server] {msg}\n")
    sys.stderr.flush()


def send(obj: dict):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def recv() -> Optional[dict]:
    line = sys.stdin.readline()
    if not line:
        return None
    return json.loads(line.strip())


def tool_echo(text: str) -> str:
    return f"echo: {text}"


TOOLS = [{
    "name": "echo",
    "description": "把传入的字符串原样回声出来，前面加上 'echo: ' 前缀。",
    "inputSchema": {
        "type": "object",
        "properties": {"text": {"type": "string"}},
        "required": ["text"],
    },
}]


def handle_initialize(params):
    return {
        "protocolVersion": PROTOCOL_VERSION,
        "capabilities": {"tools": {}},
        "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
    }


def handle_tools_list():
    return {"tools": TOOLS}


def handle_tools_call(params):
    name = params.get("name")
    args = params.get("arguments", {})
    if name == "echo":
        return {"content": [{"type": "text", "text": tool_echo(**args)}], "isError": False}
    raise ValueError(f"unknown tool: {name}")


def main():
    log("started")
    while True:
        try:
            req = recv()
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "id": None,
                  "error": {"code": -32700, "message": f"Parse error: {e}"}})
            continue
        if req is None:
            break

        method = req.get("method")
        params = req.get("params") or {}
        req_id = req.get("id")

        if method == "notifications/initialized":
            continue

        try:
            if method == "initialize":
                result = handle_initialize(params)
            elif method == "tools/list":
                result = handle_tools_list()
            elif method == "tools/call":
                result = handle_tools_call(params)
            else:
                send({"jsonrpc": "2.0", "id": req_id,
                      "error": {"code": -32601, "message": f"Method not found: {method}"}})
                continue
            send({"jsonrpc": "2.0", "id": req_id, "result": result})
        except Exception as e:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32603, "message": str(e)}})
    log("EOF")


if __name__ == "__main__":
    main()
