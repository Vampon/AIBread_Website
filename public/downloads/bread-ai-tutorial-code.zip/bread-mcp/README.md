# Bread MCP · 从零搭建模型上下文协议（MCP）

> 知识星球付费课程 · Bread 系列第二部
> 6 章 · 约 500 行 · 纯 Python · 完全不会编程也能跟着做 · 不依赖 MCP 官方 SDK

---

## 这门课在讲什么

**MCP（Model Context Protocol，模型上下文协议）** 是 2024 年底 Anthropic 推出、2025-2026 横扫整个 AI 工具生态的标准协议。

简单说：MCP 让"工具"和"AI agent"之间有了**统一的接口**。以前你写一个新工具要嵌进 agent 代码里；用了 MCP 之后，工具变成了一个独立的小程序（**MCP server**），agent（**MCP client**）通过协议远程调用它。

```
                       MCP 协议
   你的 AI Agent  ←─────────────→  任意工具
   (MCP Client)                     (MCP Server)
                                    可以是别人写的、用别的语言写的、跑在远程服务器的
```

读完本课程，你会：

- 手写一个 MCP server（暴露文件操作、SQLite 数据库等工具）
- 手写一个 MCP client（连接任意 MCP server）
- **把 MCP 接入你的 Bread Agent**——让它一夜之间获得"用任何 MCP 工具"的能力

不依赖任何 MCP 官方 SDK——**协议级理解**才是这门课的核心。

---

## 这门课和 Bread Agent 什么关系

| | Bread Agent | Bread MCP |
|---|---|---|
| 解决什么问题 | agent 内核（循环、工具、钩子） | agent 怎么用**外部工具** |
| 推荐学习顺序 | 先学 | 后学（ch04 会接回 Bread Agent） |
| 是否依赖前作 | ❌ 完全独立 | ⚠️ ch04 起需要 Bread Agent 知识，建议先学 |
| 行数 | ~540 | ~500 |

如果你还没学 Bread Agent，**建议先去学**——ch04-ch05 会无缝把这两门课串成一个完整产品。

---

# 第一部分：零基础准备（5 分钟）

> 已经做过 Bread Agent 的同学直接跳过这一节——你的环境完全可以复用。

## 1. 安装 Python（已有跳过）

参见 Bread Agent README 的"零基础准备"。要求 Python 3.10+。

## 2. 进入本仓库目录

```
cd D:\Project\bread-mcp        # Windows
cd ~/Downloads/bread-mcp       # macOS/Linux
```

## 3. 装依赖

```
pip install -r requirements.txt
```

只有 `openai` + `python-dotenv` 两个包。

## 4. 配置 .env（ch04 起需要）

ch00~ch03 是**纯协议练习**，不需要 LLM Key——只用 Python 自己跟自己说话。**ch04 起**才需要一个 OpenAI 兼容 Key。

复制 `.env.example` 为 `.env`，填入 key。**如果你做过 Bread Agent，直接把那边的 `.env` 复制过来用就行**。

## 5. 第一次运行

```
cd ch00_jsonrpc
python main.py
```

看到一段 JSON-RPC 演示输出就算通过。

---

# 第二部分：课程地图

| 章 | 文件夹 | 你会学到 | 行数 |
|---|---|---|---:|
| 0 | `ch00_jsonrpc/` | JSON-RPC 2.0 协议长什么样、stdio 通信原理 | ~40 |
| 1 | `ch01_min_server/` | **最简 MCP server** —— initialize / tools/list / tools/call | ~120 |
| 2 | `ch02_min_client/` | **最简 MCP client** —— 子进程 + 完整握手 | ~120 |
| 3 | `ch03_real_tools/` | 真实工具集 server：read_file / list_dir / get_time | ~180 |
| 4 | `ch04_with_agent/` | **★ 接入 Bread Agent** —— MCP 工具自动适配为 OpenAI tool | ~250 |
| 5 | `ch05_sqlite_server/` | **实战** —— SQLite MCP server，让 agent 能查数据库 | ~350 |

每章 README 五段式（故事 → 跑起来 → 逐行精讲 → FAQ → 思考题），跟 Bread Agent 同款。

---

## 怎么学每一章

**最高效的方法是看 diff**。把当前章和上一章并排打开对比，你会很直观地看到"协议是从一个简单的 JSON-RPC 循环慢慢长出来的"。

每章 30-45 分钟：读 README + 跑代码 + 做 3 道思考题。**不动手等于白学**。

---

# 附录

## 课程刻意没教的

- **HTTP / SSE transport**：MCP 也支持 HTTP+SSE，但 stdio 已经能完整讲清协议本质，HTTP 是工程细节
- **Sampling / 反向调用**：MCP 允许 server 反过来调 client 的 LLM，进阶特性
- **Progress / Cancellation 通知**：长任务进度报告
- **资源订阅**：resources 的变更监听
- **官方 SDK**（`mcp` 包）：用了 SDK 就看不见协议——我们故意手写

这些等你掌握核心后自学不到一天。

## 这门课对得起的画面

读完后，当你向人介绍 MCP，你能说出：

> "MCP 就是 JSON-RPC 2.0 之上规定了一组方法名（initialize / tools.list / tools.call / resources.read），通信走 stdio 或 HTTP-SSE。客户端 spawn 服务端做子进程，按协议握手完之后就能像调本地函数一样调任意工具。"

而不是张口"MCP 嘛...就是那个 Anthropic 出的标准"。

## 致谢

参考资料：
- [MCP 官方规范](https://spec.modelcontextprotocol.io)
- [JSON-RPC 2.0 规范](https://www.jsonrpc.org/specification)
- 上一部：[Bread Agent](../bread-agent/)

—— Bread MCP 课程 · 知识星球
