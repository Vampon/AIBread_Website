"""
第 5 章 · SQLite MCP server（终章实战）
=======================================

这一章我们写一个真实有用的 MCP server——把 SQLite 数据库暴露成工具。
agent 拿到它后，能"看数据库结构、跑查询、改数据"。

提供 4 个工具：
    db_list_tables()         列出所有表名
    db_describe_table(table) 看一张表的字段定义
    db_query(sql)            执行 SELECT 类查询
    db_execute(sql)          执行 INSERT/UPDATE/DELETE/CREATE/DROP

这是 MCP 最有商业价值的场景——把 agent 接到企业数据库。

注意：本 server 故意把 db_execute 限制在 ":memory:" 数据库或临时 db 文件，
避免学员误删生产数据库。**生产部署时务必加权限校验**。
"""

import json
import sqlite3
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "bread-mcp-sqlite"
SERVER_VERSION = "0.1.0"


def log(msg: str):
    sys.stderr.write(f"[sqlite] {msg}\n"); sys.stderr.flush()


def send(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n"); sys.stdout.flush()


def recv():
    line = sys.stdin.readline()
    return json.loads(line.strip()) if line else None


# ============================================================
# 数据库连接
#
# 启动参数：python server.py <db_path>
# 例如    : python server.py demo.db
# 不传    : 默认用一个 demo.db（如果不存在自动建一份带示例数据的）
# ============================================================

DB_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / "demo.db"


def init_demo_db_if_needed():
    """如果 db 是空的，自动建表 + 塞示例数据，让学员开箱有得查。"""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    if cur.fetchone() is None:
        log(f"db {DB_PATH} 是空的，初始化示例数据")
        cur.executescript("""
            CREATE TABLE employees (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                salary REAL,
                hire_date TEXT
            );
            INSERT INTO employees (name, department, salary, hire_date) VALUES
                ('张三', '工程部', 25000, '2023-03-15'),
                ('李四', '销售部', 18000, '2024-01-10'),
                ('王五', '工程部', 32000, '2022-07-01'),
                ('赵六', '产品部', 22000, '2024-09-22'),
                ('钱七', '销售部', 20000, '2023-11-05');

            CREATE TABLE projects (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                owner_id INTEGER,
                status TEXT,
                FOREIGN KEY(owner_id) REFERENCES employees(id)
            );
            INSERT INTO projects (name, owner_id, status) VALUES
                ('面包烤箱 v2', 1, 'in_progress'),
                ('销售大屏', 2, 'done'),
                ('数据中台', 3, 'in_progress');
        """)
        conn.commit()
    conn.close()


init_demo_db_if_needed()
log(f"数据库: {DB_PATH}")


def _conn() -> sqlite3.Connection:
    """每次工具调用都新开一个 connection，避免长连接锁问题。"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 让结果支持按列名访问
    return conn


# ============================================================
# 工具实现
# ============================================================

def tool_db_list_tables() -> str:
    conn = _conn()
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        if not rows:
            return "(数据库无表)"
        return "\n".join(r["name"] for r in rows)
    finally:
        conn.close()


def tool_db_describe_table(table: str) -> str:
    conn = _conn()
    try:
        rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
        if not rows:
            return f"表 {table} 不存在"
        lines = ["列名\t类型\t非空\t默认值\t主键"]
        for r in rows:
            lines.append(f"{r['name']}\t{r['type']}\t{r['notnull']}\t{r['dflt_value']}\t{r['pk']}")
        return "\n".join(lines)
    finally:
        conn.close()


MAX_ROWS = 100  # 防止 SELECT 把上下文撑爆


def tool_db_query(sql: str) -> str:
    """执行 SELECT。其他语句应该走 db_execute。"""
    s = sql.strip().lstrip("(").lower()
    if not (s.startswith("select") or s.startswith("with")):
        return "db_query 只接受 SELECT 或 WITH 开头的查询；改用 db_execute"

    conn = _conn()
    try:
        cur = conn.execute(sql)
        rows = cur.fetchmany(MAX_ROWS + 1)
        truncated = len(rows) > MAX_ROWS
        rows = rows[:MAX_ROWS]
        if not rows:
            return "(空结果集)"

        cols = rows[0].keys()
        out = ["\t".join(cols)]
        for r in rows:
            out.append("\t".join(str(r[c]) if r[c] is not None else "NULL" for c in cols))
        if truncated:
            out.append(f"... (truncated at {MAX_ROWS} rows)")
        return "\n".join(out)
    finally:
        conn.close()


def tool_db_execute(sql: str) -> str:
    """执行 INSERT/UPDATE/DELETE/CREATE/DROP 等非查询语句。"""
    conn = _conn()
    try:
        cur = conn.execute(sql)
        conn.commit()
        return f"OK, rowcount={cur.rowcount}"
    finally:
        conn.close()


# ============================================================
# 工具注册表
# ============================================================

TOOL_REGISTRY = {
    "db_list_tables": {
        "schema": {"name": "db_list_tables",
                   "description": "列出当前数据库里的所有表名。无参数。",
                   "inputSchema": {"type": "object", "properties": {}, "required": []}},
        "impl": tool_db_list_tables},

    "db_describe_table": {
        "schema": {"name": "db_describe_table",
                   "description": "查看一张表的列定义（列名、类型、是否非空、默认值、是否主键）。",
                   "inputSchema": {"type": "object",
                                   "properties": {"table": {"type": "string", "description": "表名"}},
                                   "required": ["table"]}},
        "impl": tool_db_describe_table},

    "db_query": {
        "schema": {"name": "db_query",
                   "description": ("执行 SELECT / WITH 类查询，返回结果（最多 100 行，超出截断）。"
                                   "结果是 TSV 格式：第一行是列名，后续每行一条记录。"),
                   "inputSchema": {"type": "object",
                                   "properties": {"sql": {"type": "string", "description": "SQL 查询语句"}},
                                   "required": ["sql"]}},
        "impl": tool_db_query},

    "db_execute": {
        "schema": {"name": "db_execute",
                   "description": ("执行非查询的 SQL 语句：INSERT / UPDATE / DELETE / CREATE / DROP。"
                                   "返回受影响的行数。仅在用户明确要求修改数据时使用。"),
                   "inputSchema": {"type": "object",
                                   "properties": {"sql": {"type": "string", "description": "SQL 语句"}},
                                   "required": ["sql"]}},
        "impl": tool_db_execute},
}


# ============================================================
# 协议方法
# ============================================================

def handle_initialize(params):
    return {"protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION}}


def handle_tools_call(params):
    name = params.get("name")
    args = params.get("arguments", {}) or {}
    entry = TOOL_REGISTRY.get(name)
    if entry is None:
        raise ValueError(f"unknown tool: {name}")
    try:
        result = entry["impl"](**args)
        return {"content": [{"type": "text", "text": str(result)}], "isError": False}
    except Exception as e:
        return {"content": [{"type": "text", "text": f"{type(e).__name__}: {e}"}], "isError": True}


HANDLERS = {
    "initialize": handle_initialize,
    "tools/list": lambda p: {"tools": [t["schema"] for t in TOOL_REGISTRY.values()]},
    "tools/call": handle_tools_call,
}


def main():
    log(f"started, tools={list(TOOL_REGISTRY.keys())}")
    while True:
        try:
            req = recv()
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "id": None,
                  "error": {"code": -32700, "message": f"Parse error: {e}"}})
            continue
        if req is None: break

        method = req.get("method")
        params = req.get("params") or {}
        req_id = req.get("id")

        if method == "notifications/initialized":
            continue

        handler = HANDLERS.get(method)
        if not handler:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32601, "message": f"Method not found: {method}"}})
            continue

        try:
            result = handler(params)
            send({"jsonrpc": "2.0", "id": req_id, "result": result})
        except Exception as e:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32603, "message": str(e)}})


if __name__ == "__main__":
    main()
