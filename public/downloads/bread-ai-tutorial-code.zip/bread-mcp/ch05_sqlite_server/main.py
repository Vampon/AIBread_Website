"""
第 5 章 · SQLite MCP server（终章实战）
=======================================

把数据库变成 agent 的工具。
跑起来后试：
    "数据库里有什么表"
    "工程部工资最高的是谁"
    "给我看一下所有进行中的项目和负责人"
    "把张三的工资涨到 28000"
"""

import sys
from pathlib import Path

from dotenv import load_dotenv

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")
load_dotenv(HERE.parent.parent / "bread-agent" / ".env")  # 兜底

from client import MCPClient
from agent import Agent


def main():
    db_path = HERE / "demo.db"
    server_cmd = [sys.executable, str(HERE / "server.py"), str(db_path)]

    with MCPClient(server_cmd) as mcp:
        print(f"已连接 MCP server: {mcp.server_info.get('name')} v{mcp.server_info.get('version')}")
        print(f"数据库文件: {db_path}\n")

        agent = Agent(mcp)
        print("\nBread MCP × Bread Agent · SQLite 数据分析师\n输入消息开始；Ctrl+C 退出。\n")

        while True:
            try:
                user_input = input("你 > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n再见！")
                break
            if not user_input:
                continue
            try:
                answer = agent.chat(user_input)
            except KeyboardInterrupt:
                print("\n[中断本轮]")
                continue
            print(f"\nAI > {answer}\n")


if __name__ == "__main__":
    main()
