"""跟 ch04 一样的 Agent，但 system prompt 改成数据分析师人设。"""

import json
import os

from openai import OpenAI

from client import MCPClient


def mcp_schema_to_openai_tool(t: dict) -> dict:
    return {
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t.get("description", ""),
            "parameters": t.get("inputSchema", {"type": "object", "properties": {}}),
        },
    }


SYSTEM_PROMPT = """你是一个数据分析助手，能通过 MCP 工具操作一个 SQLite 数据库。

工作流程建议：
- 不知道有什么表 → 先 db_list_tables
- 不知道表结构 → db_describe_table
- 看数据 → db_query (SELECT)
- 改数据 → 必须先和用户确认，再用 db_execute（一次只做一个改动）

风格：
- 列出查询结果时，用中文总结发现的洞察，不要只贴 TSV
- 写 SQL 时，多用 LIMIT 防止结果过大
- 用户用中文问"工程部工资最高的人"这种自然语言，你要翻译成 SQL
"""


class Agent:
    MAX_STEPS = 15

    def __init__(self, mcp: MCPClient):
        self.client = OpenAI(
            api_key=os.environ["OPENAI_API_KEY"],
            base_url=os.environ["OPENAI_BASE_URL"],
        )
        self.model = os.environ["MODEL"]
        self.mcp = mcp

        mcp_tools = self.mcp.list_tools()
        self.tools_openai = [mcp_schema_to_openai_tool(t) for t in mcp_tools]
        self.tool_names = {t["name"] for t in mcp_tools}

        print(f"[agent] 已发现 {len(mcp_tools)} 个 MCP 工具: {', '.join(sorted(self.tool_names))}")

        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    def chat(self, user_input: str) -> str:
        self.messages.append({"role": "user", "content": user_input})

        for step in range(self.MAX_STEPS):
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=self.tools_openai,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)

            if not msg.tool_calls:
                return msg.content or ""

            for call in msg.tool_calls:
                name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    result = f"参数 JSON 解析失败: {e}"
                else:
                    # 把 SQL 显式打到日志，让学员看清楚 agent 编了什么查询
                    arg_preview = args.get("sql") or args.get("table") or json.dumps(args, ensure_ascii=False)
                    print(f"  [step {step}] {name}({arg_preview[:120]})")
                    if name not in self.tool_names:
                        result = f"工具不存在: {name}"
                    else:
                        result = self.mcp.call_tool(name, args)
                    print(f"  [step {step}] -> {str(result)[:160]}")

                self.messages.append({"role": "tool", "tool_call_id": call.id, "content": str(result)})

        return "[已达到最大步数]"
