"""
第 4 章 · 把 MCP server 接到 Bread Agent
========================================

本章是 Bread MCP 的"高潮"——MCP 协议的真正价值在这里显形：

  Bread Agent ch02 的工具是写死在 Python 里的本地函数。
  本章的 Agent 启动时**通过 MCP 协议**从 server 拉取工具清单，
  LLM 想调哪个，我们就远程调哪个。

工具来自外部进程、可以用别的语言写、可以跑在别的机器上——agent 一无所知。

注意：本章起需要 LLM API Key。如果你没做过 Bread Agent，先去那边配 .env。
"""

import sys
from pathlib import Path

from dotenv import load_dotenv

# UTF-8（防中文乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# 加载 .env（先找本仓库根，再回退到 bread-agent/.env）
HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")           # bread-mcp/.env
load_dotenv(HERE.parent.parent / "bread-agent" / ".env")  # 兜底：复用 bread-agent 的

from client import MCPClient
from agent import Agent


def main():
    # 启动 MCP server 子进程
    server_cmd = [sys.executable, str(HERE / "server.py")]

    with MCPClient(server_cmd) as mcp:
        print(f"已连接 MCP server: {mcp.server_info.get('name')} v{mcp.server_info.get('version')}\n")

        agent = Agent(mcp)
        print("\nBread MCP × Bread Agent · v1\n输入消息开始对话；Ctrl+C 退出。\n")

        while True:
            try:
                user_input = input("你 > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n再见！")
                break
            if not user_input:
                continue
            try:
                answer = agent.chat(user_input)
            except KeyboardInterrupt:
                print("\n[中断本轮]")
                continue
            print(f"\nAI > {answer}\n")


if __name__ == "__main__":
    main()
