"""ch02 的 MCPClient（搬过来让本章独立）。"""

import json
import subprocess

PROTOCOL_VERSION = "2024-11-05"
CLIENT_NAME = "bread-mcp-client"
CLIENT_VERSION = "0.1.0"


class MCPClient:
    def __init__(self, server_command: list[str]):
        self.server_command = server_command
        self.proc: subprocess.Popen | None = None
        self._next_id = 1
        self.server_info: dict = {}

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    def connect(self):
        self.proc = subprocess.Popen(
            self.server_command,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            encoding="utf-8", bufsize=1,
        )
        init = self._request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
        })
        self.server_info = init.get("serverInfo", {})
        self._notify("notifications/initialized")

    def close(self):
        if not self.proc:
            return
        try:
            self.proc.stdin.close()
            self.proc.wait(timeout=5)
        except Exception:
            self.proc.kill()
        self.proc = None

    def _request(self, method, params=None) -> dict:
        req_id = self._next_id
        self._next_id += 1
        req = {"jsonrpc": "2.0", "id": req_id, "method": method}
        if params is not None:
            req["params"] = params
        self._write(req)
        resp = self._read()
        if "error" in resp:
            err = resp["error"]
            raise RuntimeError(f"server error {err.get('code')}: {err.get('message')}")
        return resp.get("result", {})

    def _notify(self, method, params=None):
        req = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            req["params"] = params
        self._write(req)

    def _write(self, obj):
        self.proc.stdin.write(json.dumps(obj, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()

    def _read(self) -> dict:
        line = self.proc.stdout.readline()
        if not line:
            raise RuntimeError("server 提前关闭 stdout")
        return json.loads(line.strip())

    def list_tools(self) -> list[dict]:
        return self._request("tools/list").get("tools", [])

    def call_tool(self, name: str, arguments: dict) -> str:
        """调一个工具。注意：本章我们用 arguments dict 而不是 **kwargs——
           因为下面 agent 会把 OpenAI 给的 arguments dict 直接转发过来。"""
        result = self._request("tools/call", {"name": name, "arguments": arguments})
        text = "".join(c.get("text", "") for c in result.get("content", []) if c.get("type") == "text")
        if result.get("isError"):
            return f"[工具报错] {text}"
        return text
