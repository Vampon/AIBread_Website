"""
Agent + MCPClient 集成
======================

这个 Agent 跟 Bread Agent ch02 的 run_agent 几乎一样——区别在于工具集
**全部来自 MCP server**：不再写本地 Python 函数，而是通过 MCPClient 远程调用。

适配关键就两件事：
  1. MCP 的 tool schema 字段名是 inputSchema，OpenAI 要的是 parameters → 翻译一下
  2. 调工具不是 TOOLS_IMPL[name](**args)，而是 mcp.call_tool(name, args)
"""

import json
import os
import sys
from pathlib import Path

from openai import OpenAI

from client import MCPClient


def mcp_schema_to_openai_tool(mcp_tool: dict) -> dict:
    """把 MCP 的工具 schema 翻译成 OpenAI 的 function tool 格式。

    MCP:                              OpenAI:
    {                                 {
      "name": "read_file",              "type": "function",
      "description": "...",             "function": {
      "inputSchema": {                    "name": "read_file",
        "type": "object",                 "description": "...",
        "properties": {...}               "parameters": {
      }                                     "type": "object",
    }                                       "properties": {...}
                                          }
                                        }
                                      }
    """
    return {
        "type": "function",
        "function": {
            "name": mcp_tool["name"],
            "description": mcp_tool.get("description", ""),
            "parameters": mcp_tool.get("inputSchema", {"type": "object", "properties": {}}),
        },
    }


class Agent:
    """OpenAI-style agent，工具集来自一个 MCP server。"""

    MAX_STEPS = 10

    def __init__(self, mcp: MCPClient):
        self.client = OpenAI(
            api_key=os.environ["OPENAI_API_KEY"],
            base_url=os.environ["OPENAI_BASE_URL"],
        )
        self.model = os.environ["MODEL"]
        self.mcp = mcp

        # ★ 关键一步：从 MCP server 拉取所有工具，翻译成 OpenAI 格式
        mcp_tools = self.mcp.list_tools()
        self.tools_openai = [mcp_schema_to_openai_tool(t) for t in mcp_tools]
        self.tool_names = {t["name"] for t in mcp_tools}

        print(f"[agent] 已发现 {len(mcp_tools)} 个 MCP 工具: {', '.join(sorted(self.tool_names))}")

        self.messages = [
            {"role": "system", "content":
             "你是一个能调用外部 MCP 工具的中文助理，根据需要使用工具。完成任务后用一句话总结。"},
        ]

    def chat(self, user_input: str) -> str:
        self.messages.append({"role": "user", "content": user_input})

        for step in range(self.MAX_STEPS):
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=self.messages,
                tools=self.tools_openai,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)

            if not msg.tool_calls:
                return msg.content or ""

            for call in msg.tool_calls:
                name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    result = f"参数 JSON 解析失败: {e}"
                else:
                    print(f"  [step {step}] mcp.call_tool {name}({args})")
                    if name not in self.tool_names:
                        result = f"工具不存在: {name}"
                    else:
                        # ★ 关键：调用变成 MCP 远程调用
                        result = self.mcp.call_tool(name, args)
                    print(f"  [step {step}] -> {str(result)[:100]}")

                self.messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": str(result),
                })

        return "[已达到最大步数，强行终止]"
