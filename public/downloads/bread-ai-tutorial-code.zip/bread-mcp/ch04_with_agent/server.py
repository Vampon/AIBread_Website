"""ch03 真实工具集 server（搬过来让本章独立可跑）。"""

import json
import sys
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "bread-mcp-fs"
SERVER_VERSION = "0.1.0"


def log(msg: str):
    sys.stderr.write(f"[server] {msg}\n"); sys.stderr.flush()


def send(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n"); sys.stdout.flush()


def recv():
    line = sys.stdin.readline()
    return json.loads(line.strip()) if line else None


def tool_read_file(path: str) -> str:
    text = Path(path).read_text(encoding="utf-8")
    if len(text) > 4000:
        text = text[:4000] + f"\n... (truncated, total {len(text)} chars)"
    return text


def tool_list_dir(path: str = ".") -> str:
    p = Path(path)
    if not p.is_dir():
        return f"{p} 不是目录"
    items = [f"{'DIR ' if c.is_dir() else 'FILE'} {c.name}" for c in sorted(p.iterdir())]
    return "\n".join(items) if items else "(空目录)"


def tool_get_time() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


TOOL_REGISTRY = {
    "read_file": {
        "schema": {"name": "read_file", "description": "读取一个文本文件的内容（超过 4000 字会截断）。",
                   "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}},
        "impl": tool_read_file},
    "list_dir": {
        "schema": {"name": "list_dir", "description": "列出一个目录下的文件和子目录。",
                   "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": []}},
        "impl": tool_list_dir},
    "get_time": {
        "schema": {"name": "get_time", "description": "返回服务器当前的本地时间（精确到秒）。",
                   "inputSchema": {"type": "object", "properties": {}, "required": []}},
        "impl": tool_get_time},
}


def handle_initialize(params):
    return {"protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION}}


def handle_tools_call(params):
    name = params.get("name")
    args = params.get("arguments", {}) or {}
    entry = TOOL_REGISTRY.get(name)
    if entry is None:
        raise ValueError(f"unknown tool: {name}")
    try:
        result = entry["impl"](**args)
        return {"content": [{"type": "text", "text": str(result)}], "isError": False}
    except Exception as e:
        return {"content": [{"type": "text", "text": f"{type(e).__name__}: {e}"}], "isError": True}


HANDLERS = {
    "initialize": handle_initialize,
    "tools/list": lambda p: {"tools": [t["schema"] for t in TOOL_REGISTRY.values()]},
    "tools/call": handle_tools_call,
}


def main():
    log(f"started, tools={list(TOOL_REGISTRY.keys())}")
    while True:
        try:
            req = recv()
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "id": None,
                  "error": {"code": -32700, "message": f"Parse error: {e}"}})
            continue
        if req is None: break

        method = req.get("method")
        params = req.get("params") or {}
        req_id = req.get("id")

        if method == "notifications/initialized":
            continue

        handler = HANDLERS.get(method)
        if not handler:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32601, "message": f"Method not found: {method}"}})
            continue

        try:
            result = handler(params)
            send({"jsonrpc": "2.0", "id": req_id, "result": result})
        except Exception as e:
            send({"jsonrpc": "2.0", "id": req_id,
                  "error": {"code": -32603, "message": str(e)}})


if __name__ == "__main__":
    main()
