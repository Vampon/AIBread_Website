"""
第 0 章 · JSON-RPC 2.0 入门 + stdio 通信
========================================

MCP 是建立在 JSON-RPC 2.0 之上的。所以学 MCP 之前，我们必须先理解
"两个程序之间用 JSON 字符串通信"这件事到底长什么样。

本章不写 server / client。只用 Python 自己跟自己讲一遍：
  1. 一条 JSON-RPC 请求长什么样
  2. 一条 JSON-RPC 响应长什么样
  3. 错误怎么表达
  4. 通过 stdin/stdout 怎么传

整个过程一行 import 都不需要——只用标准库 json。
"""

import json
import sys

# Windows 控制台 UTF-8（防中文乱码）
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass


# ============================================================
# 1. JSON-RPC 2.0 请求的标准结构
# ============================================================
# 4 个字段：
#   jsonrpc: 必须是字符串 "2.0"
#   id:      请求的标识，调用方自己给（数字或字符串都行）；响应会带上同一个 id
#   method:  你想调的方法名
#   params:  参数（可以是 dict 也可以是 list）

request = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "add",
    "params": {"a": 3, "b": 5},
}

print("=" * 60)
print("一条 JSON-RPC 请求长这样：")
print(json.dumps(request, indent=2, ensure_ascii=False))


# ============================================================
# 2. 响应的标准结构
# ============================================================
# 成功响应只有 jsonrpc / id / result
# 失败响应只有 jsonrpc / id / error
# id 必须和请求里的 id 对得上

success_response = {
    "jsonrpc": "2.0",
    "id": 1,
    "result": 8,
}

error_response = {
    "jsonrpc": "2.0",
    "id": 1,
    "error": {
        "code": -32601,
        "message": "Method not found",
        "data": "你调的 'subtract' 方法服务端没实现",
    },
}

print("\n" + "=" * 60)
print("成功响应：")
print(json.dumps(success_response, indent=2, ensure_ascii=False))
print("\n失败响应：")
print(json.dumps(error_response, indent=2, ensure_ascii=False))


# ============================================================
# 3. 通过 stdin/stdout 怎么传输
# ============================================================
# 约定：一行一个 JSON。发送方把 dict 序列化为 JSON 字符串、写一行；
#       接收方读一行、json.loads 还原成 dict。

# 模拟"发送"——把请求写到 stderr（避免污染 stdout 演示）
def send(obj: dict, stream=sys.stderr):
    line = json.dumps(obj, ensure_ascii=False)
    stream.write(line + "\n")
    stream.flush()


# 模拟"接收"——从字符串里读一行 JSON
def recv_from_string(s: str) -> dict:
    return json.loads(s.strip())


print("\n" + "=" * 60)
print("传输演示（请求和响应之间往返）：")
print()

# 发请求
send(request)
print("  ↑ 上面这一行（在 stderr）就是真实传输的内容。")
print("  服务端会按行读它，json.loads 还原，处理。")

# 模拟收到的响应文本
raw_response_text = '{"jsonrpc":"2.0","id":1,"result":8}\n'
parsed = recv_from_string(raw_response_text)
print(f"\n收到的原始文本: {raw_response_text!r}")
print(f"解析后的 dict:  {parsed}")


# ============================================================
# 4. 错误码的几个标准值（JSON-RPC 2.0 规范）
# ============================================================
ERROR_CODES = {
    -32700: "Parse error          (收到的不是合法 JSON)",
    -32600: "Invalid Request      (JSON 合法但不是合法 JSON-RPC 请求)",
    -32601: "Method not found     (方法名服务端没实现)",
    -32602: "Invalid params       (参数类型或缺失不对)",
    -32603: "Internal error       (服务端内部异常)",
}

print("\n" + "=" * 60)
print("JSON-RPC 2.0 标准错误码：")
for code, name in ERROR_CODES.items():
    print(f"  {code}: {name}")


print("\n" + "=" * 60)
print("这一章学完了。下一章 ch01 我们就用这套规则写一个真正的 MCP server。")
