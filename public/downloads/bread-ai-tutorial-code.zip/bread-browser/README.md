# Bread Browser · 从零搭建一个会用浏览器的 AI Agent

> 知识星球付费课程 · 第四部 · ~520 行 Python · Python 新手友好

---

## 这一课在解决什么问题

前三课（Bread Agent / MCP / RAG）你已经能让 AI **聊天 + 调内部工具 + 查私有文档**。
但有一类任务 AI 还是干不了：

> "帮我去 quotes.toscrape.com 把 humor 标签下所有引言抓下来。"
> "去 GitHub 搜 langchain，把第一页 star 数前 5 的项目名字告诉我。"
> "帮我登录公司 OA，把今天的待办列出来。"

这些任务的共同点 —— **需要操作浏览器**。点按钮、填表单、翻页、读 DOM。

2024 年起这是 AI agent 最炸的方向，代表项目：

- **browser-use** —— Python 开源，2024 年 GitHub 涨星最快的 AI 项目之一
- **Skyvern** —— YC W24，企业级浏览器自动化
- **Anthropic Computer Use** —— Claude 3.5 Sonnet 直接操作整个桌面
- **OpenAI Operator** —— GPT 浏览器代理产品

它们底层做的事**惊人地相似**：

1. 用 Playwright / Puppeteer 启浏览器
2. 抽页面里的可交互元素（按钮、输入框、链接）
3. 喂给 LLM + 任务描述
4. LLM 选一个 action（"点编号 [3] 的按钮"）
5. 本地执行 → 截新页面 → 回到 2

**这一课从零教你写这套循环**。

---

## 为什么从零写而不是直接用 browser-use

| 你想要的 | 直接用 browser-use | 学 Bread Browser |
|---|---|---|
| 跑通个 demo | ✅ 5 分钟 | ❌ 需要写代码 |
| 理解它在干什么 | ❌ 几千行黑盒 | ✅ ~500 行手撕 |
| 出问题能 debug | ❌ | ✅ |
| 自定义元素抽取 | ❌ 改框架内部 | ✅ 改你自己的几十行 |
| 接你自己的 LLM | ⚠️ 配置 | ✅ 直接 OpenAI SDK |
| 简历能拿出来讲 | ❌ "我会用 browser-use" | ✅ "我从零写过一个 browser-agent" |

---

## 章节地图

```
ch00 hello         ──── Playwright 启动 / 导航 / 截图（不涉及 AI）
     │
ch01 dom_snapshot  ──── 抽页面里所有可交互元素，编号给 LLM
     │
ch02 one_action    ──── LLM 单步：根据任务选一个 action
     │
ch03 agent_loop ★  ──── 完整循环 + done 判定（本课灵魂）
     │
ch04 full_task     ──── 端到端任务：quotes.toscrape.com 多页面抓取
     │
ch05 with_agent ★  ──── 接入 Bread Agent 工具调用循环（终章）
```

每章读 README + 跑代码 + 看 diff + 做思考题 = **30-60 分钟**。

---

## 零基础准备（10 分钟）

### 1. 装 Python 3.10+

如果你前三课已经装过 Anaconda，跳过。

### 2. 装依赖

```
pip install -r requirements.txt
python -m playwright install chromium
```

第二行是关键：装 Playwright 之后**必须再装一次浏览器二进制**（~200 MB）。这是 Playwright 的特点。

### 3. 配 `.env`（从 Bread Agent 复制即可）

```
OPENAI_API_KEY=...
OPENAI_BASE_URL=https://ark.cn-beijing.volces.com/api/coding/v3
MODEL=glm-5.1
```

vision 模型 **本课程不需要** —— 我们只用 DOM 文本。

### 4. 测一下浏览器装好没

```
cd ch00_hello
python main.py
```

应该看到一个浏览器自动弹出来 → 打开 example.com → 截图 → 关闭。如果你看不见浏览器但程序没报错，说明跑了 **headless 模式**，正常。

---

## 五段式 README（每章固定结构）

跟前三课一样：

1. **故事** —— 为什么本章存在、解决前一章的什么问题
2. **跑起来** —— 一行命令 + 预期输出
3. **逐行精讲** —— 关键代码段 + 设计原因
4. **FAQ** —— 我踩过的 5-10 个坑
5. **思考题** —— 3 个动手改造的方向

---

## 工程约束

跟 Bread 系列前三课一致：

- Python 3.10+
- **纯同步**（Playwright 也有 async API，但本课程用 sync_playwright）
- 只依赖 `openai` + `python-dotenv` + `playwright`
- Windows / macOS / Linux 都跑得通
- 每章一个独立目录，**互不依赖**
- 后一章是前一章的 diff —— `git diff chN chN+1` 看变化

---

## Demo 目标站

整门课主要用 [quotes.toscrape.com](https://quotes.toscrape.com)：

- 专为爬虫教学设计，**永远不会改版**
- 有列表 / 搜索 / 翻页 / 登录，复杂度刚好
- 静态版（`/`）和 JS 渲染版（`/js/`）都有，可以演示两种场景

ch04 会涉及它的多个页面，是本课的"高潮章"。

---

## 学完你能做的事

技术上：

- 看懂 **browser-use / Skyvern / Anthropic Computer Use** 等项目的核心思路
- 自己写一个 **公司内部 OA 自动化 agent**（填周报、提工单、查考勤）
- 把任何**没有 API 的网站**变成可用的"数据源"
- 对接前三课 —— Bread Browser 作为一个工具，给你的 Bread Agent 用

产品上：

- AI 客服 / 智能业务代理 / 智能助手新增**"会用浏览器"**这个能力维度
- 真正"做事"的 agent —— 大多数产品停留在"聊天 + 查文档"，能操作浏览器是下一代差异化

---

## 下一步建议（学完之后）

1. **接 Vision** —— 当 DOM 抽不到时切截图 + GPT-4V / Claude vision
2. **多 Agent 协作** —— planner / executor / verifier 三个 agent 配合
3. **接 Computer Use** —— Anthropic 的 computer-use beta，直接操作整个桌面
4. **生产级反爬** —— stealth 模式 / 代理池 / 验证码处理

---

## 目录

- ch00_hello —— 启动浏览器
- ch01_dom_snapshot —— 抽 DOM 元素
- ch02_one_action —— LLM 单步动作
- ch03_agent_loop —— 完整 agent 循环
- ch04_full_task —— 端到端任务
- ch05_with_agent —— 接入 Bread Agent

---

**祝玩得开心。让你的 AI 真正动起来。**

> —— Bread Browser 课程 · 知识星球
