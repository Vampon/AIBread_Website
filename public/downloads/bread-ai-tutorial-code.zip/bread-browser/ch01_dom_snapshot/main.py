"""
第 1 章 · DOM Snapshot
======================

本章把网页的 HTML 压成 LLM 友好的纯文本快照。

【为什么不直接喂 HTML？】
quotes.toscrape.com 首页 HTML 约 10 KB / 200 行。
我们抽完之后只剩 ~15 行。差不多 10× token 节省。
而且 LLM 处理这种"列表式"格式比 HTML 准确率高得多。

【输出示例】
  [0] <a> Quotes to Scrape  → https://quotes.toscrape.com/
  [1] <a> Login            → https://quotes.toscrape.com/login
  [2] <a> Albert Einstein  → /author/Albert-Einstein
  ...

每个元素有唯一编号。下一章 LLM 会输出"点 [5]"——
我们就能精准定位到这个元素。
"""

import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


# 在浏览器里执行的 JS。注意：这段代码在网页的 JS runtime 里跑，不是 Python！
# Playwright 的 page.evaluate() 会把字符串当 JS 执行，把 return 值序列化回 Python。
EXTRACT_JS = r"""
() => {
  // 1. 清掉旧的标记（多次调用本函数时会复用页面）
  document.querySelectorAll('[data-bread-id]').forEach(el => el.removeAttribute('data-bread-id'));

  // 2. 选出所有"可交互"元素
  const SELECTOR = [
    'button', 'input', 'a', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="textbox"]',
    '[onclick]', '[contenteditable="true"]'
  ].join(',');
  const candidates = Array.from(document.querySelectorAll(SELECTOR));

  // 3. 过滤"看不见"的元素 + 给每个剩下的元素打标记
  const result = [];
  let idx = 0;
  for (const el of candidates) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;       // 0 尺寸跳过
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    if (parseFloat(style.opacity) === 0) continue;

    el.setAttribute('data-bread-id', String(idx));

    // 收集对 LLM 有用的字段
    result.push({
      idx: idx,
      tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || el.placeholder ||
             el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 100),
      type: el.type || '',
      href: el.href || '',
      name: el.name || '',
    });
    idx += 1;
  }
  return result;
}
"""


def snapshot_page(page) -> list[dict]:
    """让浏览器执行 EXTRACT_JS，返回元素列表。"""
    return page.evaluate(EXTRACT_JS)


def format_elements(elements: list[dict]) -> str:
    """把元素列表渲染成 LLM 友好的纯文本。"""
    lines = []
    for el in elements:
        parts = [f"[{el['idx']}] <{el['tag']}"]
        if el["type"]:
            parts.append(f' type="{el["type"]}"')
        if el["name"]:
            parts.append(f' name="{el["name"]}"')
        parts.append(">")
        if el["text"]:
            parts.append(f" {el['text']}")
        if el["href"] and el["tag"] == "a":
            href = el["href"]
            if len(href) > 60:
                href = href[:57] + "..."
            parts.append(f"  → {href}")
        lines.append("".join(parts))
    return "\n".join(lines)


def demo_one(page, url: str, label: str):
    print(f"\n=== {label} ===")
    print(f"加载 {url} ...")
    page.goto(url)
    elements = snapshot_page(page)
    print(f"抽到 {len(elements)} 个可交互元素：\n")
    print(format_elements(elements))


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        demo_one(page, "https://quotes.toscrape.com", "quotes.toscrape.com 首页")
        demo_one(page, "https://quotes.toscrape.com/login", "/login 页面")
        demo_one(page, "https://quotes.toscrape.com/search.aspx", "/search.aspx 搜索页（有 select）")

        print("\n等 3 秒后关闭，方便你打开 DevTools 看 data-bread-id 属性...")
        page.wait_for_timeout(3000)
        browser.close()


if __name__ == "__main__":
    main()
