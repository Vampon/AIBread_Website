"""
第 2 章 · One Action
====================

第一次让 LLM 真正"用浏览器"——但**只让它走一步**。

流程：
  1. 启浏览器、打开 quotes.toscrape.com
  2. 抽页面元素（ch01 的活）
  3. 把 元素列表 + 任务 喂给 LLM
  4. LLM 通过 tool_calls 返回一个 action：click / type / press / done
  5. 本地执行这个 action
  6. 重新抽页面，对比变化

【为什么不直接加循环】
Bread Agent ch01 也是"只一步"——把 round-trip 拆出来看清楚，
是新手理解 agent 流的关键。下一章再加 while。
"""

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")


# ============================================================
# DOM 抽取（沿用 ch01 的 EXTRACT_JS 和 format_elements）
# ============================================================
EXTRACT_JS = r"""
() => {
  document.querySelectorAll('[data-bread-id]').forEach(el => el.removeAttribute('data-bread-id'));
  const SELECTOR = [
    'button', 'input', 'a', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="textbox"]',
    '[onclick]', '[contenteditable="true"]'
  ].join(',');
  const candidates = Array.from(document.querySelectorAll(SELECTOR));
  const result = [];
  let idx = 0;
  for (const el of candidates) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    if (parseFloat(style.opacity) === 0) continue;
    el.setAttribute('data-bread-id', String(idx));
    result.push({
      idx: idx,
      tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || el.placeholder ||
             el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 100),
      type: el.type || '',
      href: el.href || '',
      name: el.name || '',
    });
    idx += 1;
  }
  return result;
}
"""


def snapshot_page(page) -> list[dict]:
    return page.evaluate(EXTRACT_JS)


def format_elements(elements: list[dict]) -> str:
    lines = []
    for el in elements:
        parts = [f"[{el['idx']}] <{el['tag']}"]
        if el["type"]:
            parts.append(f' type="{el["type"]}"')
        if el["name"]:
            parts.append(f' name="{el["name"]}"')
        parts.append(">")
        if el["text"]:
            parts.append(f" {el['text']}")
        if el["href"] and el["tag"] == "a":
            href = el["href"]
            if len(href) > 60:
                href = href[:57] + "..."
            parts.append(f"  → {href}")
        lines.append("".join(parts))
    return "\n".join(lines)


# ============================================================
# 浏览器动作集（agent 能调的 4 个工具）
# ============================================================
TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "click",
            "description": "Click an element by its [index] from the page snapshot.",
            "parameters": {
                "type": "object",
                "properties": {"index": {"type": "integer", "description": "Element index from snapshot"}},
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "type_text",
            "description": "Type text into an input/textarea by its [index]. Existing content will be replaced.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer"},
                    "text": {"type": "string"},
                },
                "required": ["index", "text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "press_key",
            "description": "Press a keyboard key. Common: 'Enter', 'Tab', 'Escape'.",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "done",
            "description": "The task is finished. Return the final answer to the user.",
            "parameters": {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
            },
        },
    },
]


def execute_action(page, name: str, args: dict) -> str:
    """执行一个 action，返回简短的结果描述（给人 / 给后续 LLM 看）。"""
    if name == "click":
        locator = page.locator(f'[data-bread-id="{args["index"]}"]')
        locator.click()
        return f"clicked element [{args['index']}]"
    if name == "type_text":
        locator = page.locator(f'[data-bread-id="{args["index"]}"]')
        locator.fill(args["text"])
        return f"typed {args['text']!r} into [{args['index']}]"
    if name == "press_key":
        page.keyboard.press(args["key"])
        return f"pressed {args['key']}"
    if name == "done":
        return f"DONE: {args['answer']}"
    return f"unknown action: {name}"


# ============================================================
# 主流程
# ============================================================
SYSTEM_PROMPT = (
    "You are a browser-use agent. The user gives you a task and a numbered snapshot "
    "of the current web page. You MUST call exactly one tool: click / type_text / "
    "press_key / done. Pick the most reasonable next step.\n"
    "- Indices in [N] refer to elements in the snapshot.\n"
    "- If the task is already complete, call `done` with the answer."
)


def main():
    task = "Click the 'Login' link to go to the login page."

    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        page.goto("https://quotes.toscrape.com")

        # 1. 抽页面
        elements = snapshot_page(page)
        snapshot_text = format_elements(elements)
        print("=== 当前页面快照 ===")
        print(snapshot_text)

        # 2. 问 LLM "下一步该做什么"
        user_msg = f"Task: {task}\n\nCurrent page (URL: {page.url}):\n{snapshot_text}"
        print(f"\n=== 任务 ===\n{task}\n")

        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            tools=TOOLS_SCHEMA,
            tool_choice="required",  # 强制调工具，不允许只回文本
        )
        msg = resp.choices[0].message

        if not msg.tool_calls:
            print(f"[警告] LLM 没调工具，只回了文本：{msg.content}")
            browser.close()
            return

        call = msg.tool_calls[0]
        name = call.function.name
        args = json.loads(call.function.arguments or "{}")
        print(f"=== LLM 选择 action ===")
        print(f"{name}({args})")

        # 3. 本地执行
        result = execute_action(page, name, args)
        print(f"\n=== 执行结果 ===\n{result}")

        # 4. 等页面变化，再抽一次，对比
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(500)
        new_elements = snapshot_page(page)
        print(f"\n=== 执行后页面 (URL: {page.url}) ===")
        print(f"现在抽到 {len(new_elements)} 个元素：\n")
        print(format_elements(new_elements))

        print("\n等 3 秒后关闭浏览器...")
        page.wait_for_timeout(3000)
        browser.close()


if __name__ == "__main__":
    main()
