"""
第 0 章 · Hello Playwright
==========================

不涉及 AI。本章目标：让 Playwright 在你机器上跑起来。

3 件事：
  1. 启浏览器
  2. 打开一个网页，读标题
  3. 截图存盘

如果这一章跑得通，整门课的"基建"就 OK。
"""

import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def main():
    here = Path(__file__).resolve().parent
    screenshot_path = here / "hello.png"

    # sync_playwright() 返回的对象是个"管家"，必须用 with 包起来
    # 出 with 之后浏览器进程会被自动清理 —— 这就是为什么 Playwright 强制 with
    with sync_playwright() as p:
        # headless=False 让你看见浏览器；True 则后台跑
        # 本章用 False 是为了让你看到 "AI 真的在动"
        print("[1/4] 启动 Chromium...")
        browser = p.chromium.launch(headless=False)

        print("[2/4] 新建一个标签页...")
        page = browser.new_page()

        print("[3/4] 打开 https://quotes.toscrape.com ...")
        page.goto("https://quotes.toscrape.com")

        # 读标题 + 读 H1 + 读第一段引用
        title = page.title()
        h1 = page.locator("h1").first.inner_text()
        first_quote = page.locator(".quote .text").first.inner_text()

        print(f"  网页标题: {title}")
        print(f"  H1 文本: {h1}")
        print(f"  第一条引言: {first_quote[:60]}...")

        print(f"[4/4] 截图存到 {screenshot_path.name}")
        page.screenshot(path=str(screenshot_path), full_page=True)

        # 留两秒让你看见浏览器再关闭
        page.wait_for_timeout(2000)
        browser.close()

    print(f"\n完成 ✓  打开 {screenshot_path} 看截图")


if __name__ == "__main__":
    main()
