"""
工具集：浏览器工具 + 一个非浏览器工具
==========================================

本章核心思想：**Bread Agent 的内核不变，工具集换**。

跟 Bread Agent ch05 的 tools.py 同构 —— 你能看到：
  - TOOLS_SCHEMA：给 LLM 看的工具列表
  - TOOLS_IMPL  ：本地实现

不同的是工具实现依赖一个 `page` 对象（浏览器会话），所以包成 BrowserToolBox 类。

为了强调"工具集任意混搭"，本章还加了一个非浏览器工具 `get_current_time`，
跟 Bread Agent ch01 同款。LLM 自己决定何时调浏览器、何时调时间工具。
"""

from datetime import datetime


EXTRACT_JS = r"""
() => {
  document.querySelectorAll('[data-bread-id]').forEach(el => el.removeAttribute('data-bread-id'));
  const SELECTOR = [
    'button', 'input', 'a', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="textbox"]',
    '[onclick]', '[contenteditable="true"]'
  ].join(',');
  const candidates = Array.from(document.querySelectorAll(SELECTOR));
  const result = [];
  let idx = 0;
  for (const el of candidates) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    if (parseFloat(style.opacity) === 0) continue;
    el.setAttribute('data-bread-id', String(idx));
    result.push({
      idx: idx,
      tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || el.placeholder ||
             el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 100),
      type: el.type || '',
      href: el.href || '',
      name: el.name || '',
    });
    idx += 1;
  }
  return result;
}
"""


def format_elements(elements: list[dict]) -> str:
    lines = []
    for el in elements:
        parts = [f"[{el['idx']}] <{el['tag']}"]
        if el["type"]:
            parts.append(f' type="{el["type"]}"')
        if el["name"]:
            parts.append(f' name="{el["name"]}"')
        parts.append(">")
        if el["text"]:
            parts.append(f" {el['text']}")
        if el["href"] and el["tag"] == "a":
            href = el["href"]
            if len(href) > 60:
                href = href[:57] + "..."
            parts.append(f"  → {href}")
        lines.append("".join(parts))
    return "\n".join(lines)


# =========================================================
# OpenAI tool schemas（LLM 视角）
# =========================================================
TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "open_url",
            "description": "Open / navigate to a URL in the browser. Use this to start a task or jump pages.",
            "parameters": {
                "type": "object",
                "properties": {"url": {"type": "string"}},
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "page_snapshot",
            "description": "Get a numbered list of interactive elements on the current page. Call this when you need to see what's clickable.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "click",
            "description": "Click an element by its [index] from the latest page_snapshot.",
            "parameters": {
                "type": "object",
                "properties": {"index": {"type": "integer"}},
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "type_text",
            "description": "Type text into an input/textarea by its [index]. Replaces existing content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer"},
                    "text": {"type": "string"},
                },
                "required": ["index", "text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "press_key",
            "description": "Press a keyboard key (e.g. 'Enter').",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "extract_text",
            "description": (
                "Read visible text by CSS selector. Use for non-interactive content "
                "(article body, quotes, prices). Returns all matched texts."
            ),
            "parameters": {
                "type": "object",
                "properties": {"selector": {"type": "string"}},
                "required": ["selector"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "scroll",
            "description": "Scroll the page one viewport ('down' or 'up').",
            "parameters": {
                "type": "object",
                "properties": {"direction": {"type": "string", "enum": ["down", "up"]}},
                "required": ["direction"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "Return the current local date/time. NOT a browser tool — just a regular helper.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
]


class BrowserToolBox:
    """持有 page 对象、暴露 execute(name, args)。"""

    def __init__(self, page):
        self.page = page

    def snapshot_text(self) -> str:
        elements = self.page.evaluate(EXTRACT_JS)
        return format_elements(elements)

    def execute(self, name: str, args: dict) -> str:
        # ---- 浏览器工具 ----
        if name == "open_url":
            self.page.goto(args["url"])
            return self._with_snapshot(f"opened {args['url']}")
        if name == "page_snapshot":
            return self._with_snapshot("snapshot requested")
        if name == "click":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').click()
            return self._with_snapshot(f"clicked [{args['index']}]")
        if name == "type_text":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').fill(args["text"])
            return self._with_snapshot(f"typed {args['text']!r} into [{args['index']}]")
        if name == "press_key":
            self.page.keyboard.press(args["key"])
            return self._with_snapshot(f"pressed {args['key']}")
        if name == "extract_text":
            try:
                texts = self.page.locator(args["selector"]).all_inner_texts()
            except Exception as e:
                return f"extract_text failed: {e}"
            if not texts:
                return f"(selector {args['selector']!r} matched nothing)"
            joined = "\n---\n".join(t.strip() for t in texts if t.strip())
            if len(joined) > 4000:
                joined = joined[:4000] + "\n...[truncated]"
            return f"Extracted from {args['selector']!r}:\n{joined}"
        if name == "scroll":
            delta = 800 if args["direction"] == "down" else -800
            self.page.mouse.wheel(0, delta)
            return self._with_snapshot(f"scrolled {args['direction']}")
        # ---- 非浏览器工具 ----
        if name == "get_current_time":
            return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return f"unknown tool: {name}"

    def _with_snapshot(self, action_result: str) -> str:
        try:
            self.page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        self.page.wait_for_timeout(400)
        snap = self.snapshot_text()
        return f"{action_result}\n\nCurrent page (URL: {self.page.url}):\n{snap}"
