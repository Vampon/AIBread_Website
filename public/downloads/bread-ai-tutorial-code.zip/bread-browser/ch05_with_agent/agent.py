"""
Agent · Bread Agent 风格的通用循环
====================================

跟 Bread Agent ch05/ch06 的 Agent 类**几乎一比一**。
唯一区别：工具集来自 BrowserToolBox。

核心点：agent 不知道工具是浏览器还是普通函数——它只看 schema。
"""

import json

from openai import OpenAI

from tools import TOOLS_SCHEMA, BrowserToolBox


SYSTEM_PROMPT = (
    "You are a helpful assistant that can BOTH chat with the user AND control a web browser.\n"
    "\n"
    "Browser tools:\n"
    "  open_url(url)       — navigate\n"
    "  page_snapshot()     — see numbered interactive elements on current page\n"
    "  click(index) / type_text(index, text) / press_key(key)\n"
    "  extract_text(css)   — read non-interactive content\n"
    "  scroll(direction)\n"
    "\n"
    "Non-browser tools:\n"
    "  get_current_time()  — return current date/time\n"
    "\n"
    "Rules:\n"
    "- For chit-chat or knowledge questions, DON'T open the browser — just answer.\n"
    "- For tasks involving websites/data on the web, use the browser tools.\n"
    "- Always call page_snapshot before clicking unless you JUST saw a fresh snapshot.\n"
    "- Indices [N] refer to the LATEST snapshot — they change after every navigation.\n"
    "- When the task is done, simply respond with a normal text message (no tool call)."
)


class Agent:
    MAX_STEPS = 25
    SNAPSHOT_KEEP_LAST_N = 3

    def __init__(self, client: OpenAI, model: str, toolbox: BrowserToolBox):
        self.client = client
        self.model = model
        self.toolbox = toolbox
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    def _truncate_old_snapshots(self):
        tool_indices = [i for i, m in enumerate(self.messages)
                        if isinstance(m, dict) and m.get("role") == "tool"]
        if len(tool_indices) <= self.SNAPSHOT_KEEP_LAST_N:
            return
        to_truncate = tool_indices[: -self.SNAPSHOT_KEEP_LAST_N]
        for i in to_truncate:
            msg = self.messages[i]
            content = msg.get("content", "")
            if "Current page" in content:
                head = content.split("Current page", 1)[0]
                msg["content"] = head + "[snapshot omitted to save tokens]"

    def chat(self, user_input: str) -> str:
        self.messages.append({"role": "user", "content": user_input})

        for step in range(self.MAX_STEPS):
            self._truncate_old_snapshots()
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=TOOLS_SCHEMA,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)

            if not msg.tool_calls:
                return msg.content or ""

            for call in msg.tool_calls:
                name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    self.messages.append({
                        "role": "tool", "tool_call_id": call.id,
                        "content": f"参数 JSON 解析失败: {e}",
                    })
                    continue

                arg_repr = ", ".join(f"{k}={v!r}" for k, v in args.items())
                if len(arg_repr) > 80:
                    arg_repr = arg_repr[:77] + "..."
                print(f"  [step {step}] {name}({arg_repr})")

                try:
                    result = self.toolbox.execute(name, args)
                except Exception as e:
                    result = f"tool failed: {type(e).__name__}: {e}"

                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": str(result),
                })

        return "[已达到最大步数 MAX_STEPS]"
