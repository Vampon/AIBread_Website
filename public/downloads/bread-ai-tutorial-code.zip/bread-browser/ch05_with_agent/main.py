"""
第 5 章 · 接入 Bread Agent（终章）
====================================

REPL 模式：你像跟普通 chatbot 一样输入消息，但它能在需要时**调浏览器**。

对照实验（3 类输入）：
  闲聊：     "你好"                          → 不该开浏览器
  时间问题：  "现在几点"                       → 调 get_current_time
  网页任务：  "去 quotes.toscrape.com 抓 humor 标签的引言" → 用浏览器工具

这 3 类输入由 **同一个 Agent 实例** 处理——这就是 Bread 系列的统一心智模型。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

from tools import BrowserToolBox
from agent import Agent


def main():
    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        page.goto("about:blank")

        toolbox = BrowserToolBox(page)
        agent = Agent(client, model, toolbox)

        print("Bread Browser-Agent · 会用浏览器的 chatbot")
        print("输入消息开始；Ctrl+C 退出。")
        print("试试：")
        print("  你好")
        print("  现在几点")
        print("  打开 quotes.toscrape.com，告诉我首页第一条引言")
        print()

        while True:
            try:
                user_input = input("你 > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n再见！")
                break
            if not user_input:
                continue
            try:
                answer = agent.chat(user_input)
            except KeyboardInterrupt:
                print("\n[中断本轮]")
                continue
            print(f"\nAI > {answer}\n")

        browser.close()


if __name__ == "__main__":
    main()
