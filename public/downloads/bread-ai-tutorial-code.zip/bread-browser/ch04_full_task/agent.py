"""
BrowserAgent · ch04 加强版
============================

新增工具：
  - extract_text(selector)   读非交互区域的文字（用 CSS selector）
  - scroll(direction)        翻屏（页面有滚动条时）
  - goto(url)                直接跳 URL（跳过点链接）

新增机制：
  - 历史快照截断：messages 里只保留**最近 3 步**的完整快照，
    更早的快照折叠成 "[snapshot at step N omitted]"。
    这样 10 步任务不会爆 token。
"""

import json

from openai import OpenAI


EXTRACT_JS = r"""
() => {
  document.querySelectorAll('[data-bread-id]').forEach(el => el.removeAttribute('data-bread-id'));
  const SELECTOR = [
    'button', 'input', 'a', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="textbox"]',
    '[onclick]', '[contenteditable="true"]'
  ].join(',');
  const candidates = Array.from(document.querySelectorAll(SELECTOR));
  const result = [];
  let idx = 0;
  for (const el of candidates) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    if (parseFloat(style.opacity) === 0) continue;
    el.setAttribute('data-bread-id', String(idx));
    result.push({
      idx: idx,
      tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || el.placeholder ||
             el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 100),
      type: el.type || '',
      href: el.href || '',
      name: el.name || '',
    });
    idx += 1;
  }
  return result;
}
"""


def format_elements(elements: list[dict]) -> str:
    lines = []
    for el in elements:
        parts = [f"[{el['idx']}] <{el['tag']}"]
        if el["type"]:
            parts.append(f' type="{el["type"]}"')
        if el["name"]:
            parts.append(f' name="{el["name"]}"')
        parts.append(">")
        if el["text"]:
            parts.append(f" {el['text']}")
        if el["href"] and el["tag"] == "a":
            href = el["href"]
            if len(href) > 60:
                href = href[:57] + "..."
            parts.append(f"  → {href}")
        lines.append("".join(parts))
    return "\n".join(lines)


TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "click",
            "description": "Click an element by its [index].",
            "parameters": {
                "type": "object",
                "properties": {"index": {"type": "integer"}},
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "type_text",
            "description": "Type text into an input/textarea by its [index]. Replaces existing content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer"},
                    "text": {"type": "string"},
                },
                "required": ["index", "text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "press_key",
            "description": "Press a keyboard key (e.g. 'Enter').",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "goto",
            "description": "Navigate the browser to a URL directly.",
            "parameters": {
                "type": "object",
                "properties": {"url": {"type": "string"}},
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "extract_text",
            "description": (
                "Read visible text from non-interactive elements. "
                "Pass a CSS selector like '.quote .text' or '.quote .author'. "
                "Returns all matched elements' text, one per line."
            ),
            "parameters": {
                "type": "object",
                "properties": {"selector": {"type": "string"}},
                "required": ["selector"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "scroll",
            "description": "Scroll the page. direction: 'down' / 'up' (one viewport at a time).",
            "parameters": {
                "type": "object",
                "properties": {"direction": {"type": "string", "enum": ["down", "up"]}},
                "required": ["direction"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "done",
            "description": "Task complete. Return final answer.",
            "parameters": {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
            },
        },
    },
]


SYSTEM_PROMPT = (
    "You are a browser-use agent. The user gives you a task. You see the page as a numbered "
    "list of INTERACTIVE elements only (buttons/links/inputs). To read the page's actual "
    "CONTENT (article text, quotes, etc.), call extract_text with a CSS selector.\n"
    "\n"
    "Tools:\n"
    "  click(index) / type_text(index, text) / press_key(key)  — interact\n"
    "  goto(url)                                                — direct navigation\n"
    "  extract_text(selector)                                   — read content\n"
    "  scroll(direction)                                         — page scrolling\n"
    "  done(answer)                                              — finish\n"
    "\n"
    "Rules:\n"
    "- Indices in [N] refer to the CURRENT snapshot. After each action the snapshot is refreshed.\n"
    "- Read content with extract_text, NOT by clicking text — clicks are for buttons/links only.\n"
    "- When asked for structured data (a list/JSON), build a clear JSON string in the `done` answer.\n"
    "- Don't repeat yourself. If an action didn't change anything, try a different approach."
)


class BrowserAgent:
    MAX_STEPS = 20
    SNAPSHOT_KEEP_LAST_N = 3  # 历史里只保留最近 N 步的完整快照

    def __init__(self, client: OpenAI, model: str, page):
        self.client = client
        self.model = model
        self.page = page
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self._step_idx = 0

    # ---- 浏览器侧 ----
    def _snapshot(self) -> str:
        elements = self.page.evaluate(EXTRACT_JS)
        return format_elements(elements)

    def _execute(self, name: str, args: dict) -> str:
        if name == "click":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').click()
            return f"clicked [{args['index']}]"
        if name == "type_text":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').fill(args["text"])
            return f"typed {args['text']!r} into [{args['index']}]"
        if name == "press_key":
            self.page.keyboard.press(args["key"])
            return f"pressed {args['key']}"
        if name == "goto":
            self.page.goto(args["url"])
            return f"navigated to {args['url']}"
        if name == "extract_text":
            try:
                texts = self.page.locator(args["selector"]).all_inner_texts()
            except Exception as e:
                return f"extract_text failed: {e}"
            if not texts:
                return f"(selector {args['selector']!r} matched nothing)"
            joined = "\n---\n".join(t.strip() for t in texts if t.strip())
            if len(joined) > 4000:
                joined = joined[:4000] + "\n...[truncated]"
            return f"Extracted from {args['selector']!r}:\n{joined}"
        if name == "scroll":
            delta = 800 if args["direction"] == "down" else -800
            self.page.mouse.wheel(0, delta)
            return f"scrolled {args['direction']}"
        return f"unknown action: {name}"

    def _build_tool_result(self, action_result: str, include_snapshot: bool = True) -> str:
        if not include_snapshot:
            return action_result
        try:
            self.page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        self.page.wait_for_timeout(400)
        new_snapshot = self._snapshot()
        return f"{action_result}\n\nCurrent page (URL: {self.page.url}):\n{new_snapshot}"

    def _truncate_old_snapshots(self):
        """折叠较早的 tool 消息里的快照，只保留最近 N 个完整快照。"""
        tool_indices = [i for i, m in enumerate(self.messages)
                        if isinstance(m, dict) and m.get("role") == "tool"]
        if len(tool_indices) <= self.SNAPSHOT_KEEP_LAST_N:
            return
        to_truncate = tool_indices[: -self.SNAPSHOT_KEEP_LAST_N]
        for i in to_truncate:
            msg = self.messages[i]
            content = msg.get("content", "")
            if "Current page" in content:
                head = content.split("Current page", 1)[0]
                msg["content"] = head + "[snapshot omitted to save tokens]"

    # ---- 主循环 ----
    def run(self, task: str) -> str:
        snapshot = self._snapshot()
        self.messages.append({
            "role": "user",
            "content": f"Task: {task}\n\nCurrent page (URL: {self.page.url}):\n{snapshot}",
        })

        for step in range(self.MAX_STEPS):
            self._step_idx = step
            self._truncate_old_snapshots()
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=TOOLS_SCHEMA,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)

            if not msg.tool_calls:
                return msg.content or "(no answer)"

            for call in msg.tool_calls:
                name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    self.messages.append({
                        "role": "tool", "tool_call_id": call.id,
                        "content": f"参数 JSON 解析失败: {e}",
                    })
                    continue

                arg_repr = ", ".join(f"{k}={v!r}" for k, v in args.items())
                if len(arg_repr) > 80:
                    arg_repr = arg_repr[:77] + "..."
                print(f"  [step {step}] {name}({arg_repr})")

                if name == "done":
                    self.messages.append({
                        "role": "tool", "tool_call_id": call.id, "content": "done",
                    })
                    return args.get("answer", "(no answer)")

                try:
                    action_result = self._execute(name, args)
                except Exception as e:
                    action_result = f"action failed: {type(e).__name__}: {e}"

                # extract_text 不需要新快照（页面没变）
                include_snap = name not in ("extract_text",)
                tool_content = self._build_tool_result(action_result, include_snapshot=include_snap)
                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": tool_content,
                })

        return "[已达到最大步数 MAX_STEPS]"
