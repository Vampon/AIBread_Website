"""
第 4 章 · Full Task
===================

真实端到端任务：去 quotes.toscrape.com 的 humor 标签页，
把所有引言抓下来，让 LLM 整理成 JSON。

依赖 ch04 新工具：
  - extract_text：读非交互的引言文本
  - goto：直接跳标签页（省点点击）
"""

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

from agent import BrowserAgent


def main():
    task = (
        "Go to quotes.toscrape.com and find the tag 'humor'. "
        "Extract every quote on that page along with its author. "
        "Return the result as a JSON array in `done`, where each item is "
        '{"text": ..., "author": ...}.'
    )

    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        page.goto("https://quotes.toscrape.com")

        print(f"=== 任务 ===\n{task}\n")
        print("=== Agent 开始 ===")

        agent = BrowserAgent(client, model, page)
        answer = agent.run(task)

        print(f"\n=== Agent 最终回答 ===\n{answer}\n")

        # 尝试把回答解析为 JSON 保存
        save_path = HERE / "result.json"
        try:
            # 从 markdown 代码块里抠 JSON
            content = answer
            if "```" in content:
                parts = content.split("```")
                # 取第一个 ``` 块
                block = parts[1] if len(parts) > 1 else content
                if block.startswith("json"):
                    block = block[4:]
                content = block.strip()
            data = json.loads(content)
            save_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"已存到 {save_path.name} ({len(data)} 条记录)")
        except Exception as e:
            print(f"(无法解析为 JSON: {e}；原始回答已经在上面)")

        print("\n等 3 秒后关闭浏览器...")
        page.wait_for_timeout(3000)
        browser.close()


if __name__ == "__main__":
    main()
