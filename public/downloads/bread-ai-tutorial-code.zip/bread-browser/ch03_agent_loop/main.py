"""
第 3 章 · Agent Loop（本课灵魂章）
=====================================

把 ch02 的单步扩成循环。

demo 任务：登录 quotes.toscrape.com（用户名 admin / 密码 1234）。
这是个**4 步任务**：
  1. 点 Login
  2. 在 username 输入框填 admin
  3. 在 password 输入框填 1234
  4. 点 Submit（或回车）
登录成功后页面右上会变成 Logout —— 这是 LLM 判断 done 的信号。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
load_dotenv(HERE.parent / ".env")

from agent import BrowserAgent


def main():
    task = (
        "Log into the website with username 'admin' and password '1234'. "
        "Confirm you're logged in by checking whether 'Logout' appears in the page snapshot, "
        "then call done with a short summary."
    )

    client = OpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
    )
    model = os.environ["MODEL"]

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        page.goto("https://quotes.toscrape.com")

        print(f"=== 任务 ===\n{task}\n")
        print(f"=== 起始页面 ===\n{page.url}\n")
        print("=== Agent 开始 ===")

        agent = BrowserAgent(client, model, page)
        answer = agent.run(task)

        print(f"\n=== Agent 最终回答 ===\n{answer}\n")
        print(f"最终页面 URL: {page.url}")

        print("\n等 5 秒后关闭浏览器（这时可以肉眼检查是否登录成功）...")
        page.wait_for_timeout(5000)
        browser.close()


if __name__ == "__main__":
    main()
