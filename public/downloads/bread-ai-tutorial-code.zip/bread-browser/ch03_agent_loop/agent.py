"""
BrowserAgent · 浏览器版的 agent loop
======================================

跟 Bread Agent 的循环结构**完全同构**：

  while True:
    resp = llm(messages, tools)
    if not resp.tool_calls: break       # LLM 觉得做完了
    for call in resp.tool_calls:
      result = execute(call)
      messages.append(tool_result_with_new_snapshot)

关键差异：每次工具调用之后，**新的页面快照塞进 tool result**——
LLM 才能"看见"自己刚才那一步的后果。
"""

import json

from openai import OpenAI


# DOM 抽取（沿用 ch01/ch02）
EXTRACT_JS = r"""
() => {
  document.querySelectorAll('[data-bread-id]').forEach(el => el.removeAttribute('data-bread-id'));
  const SELECTOR = [
    'button', 'input', 'a', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="textbox"]',
    '[onclick]', '[contenteditable="true"]'
  ].join(',');
  const candidates = Array.from(document.querySelectorAll(SELECTOR));
  const result = [];
  let idx = 0;
  for (const el of candidates) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    if (parseFloat(style.opacity) === 0) continue;
    el.setAttribute('data-bread-id', String(idx));
    result.push({
      idx: idx,
      tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || el.placeholder ||
             el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 100),
      type: el.type || '',
      href: el.href || '',
      name: el.name || '',
    });
    idx += 1;
  }
  return result;
}
"""


def format_elements(elements: list[dict]) -> str:
    lines = []
    for el in elements:
        parts = [f"[{el['idx']}] <{el['tag']}"]
        if el["type"]:
            parts.append(f' type="{el["type"]}"')
        if el["name"]:
            parts.append(f' name="{el["name"]}"')
        parts.append(">")
        if el["text"]:
            parts.append(f" {el['text']}")
        if el["href"] and el["tag"] == "a":
            href = el["href"]
            if len(href) > 60:
                href = href[:57] + "..."
            parts.append(f"  → {href}")
        lines.append("".join(parts))
    return "\n".join(lines)


TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "click",
            "description": "Click an element by its [index] from the page snapshot.",
            "parameters": {
                "type": "object",
                "properties": {"index": {"type": "integer"}},
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "type_text",
            "description": "Type text into an input/textarea by its [index]. Replaces existing content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer"},
                    "text": {"type": "string"},
                },
                "required": ["index", "text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "press_key",
            "description": "Press a keyboard key. Common: 'Enter', 'Tab', 'Escape'.",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "done",
            "description": "The task is finished. Return the final answer to the user.",
            "parameters": {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
            },
        },
    },
]


SYSTEM_PROMPT = (
    "You are a browser-use agent. The user gives you a task. You can see the page as a "
    "numbered list of interactive elements. Each step you pick ONE action: click, type_text, "
    "press_key, or done.\n"
    "\n"
    "Rules:\n"
    "- Indices in [N] refer to elements in the CURRENT snapshot. After every action, you "
    "  receive a NEW snapshot; the indices may have changed.\n"
    "- Be patient — multi-step tasks are normal. Login = click login + type user + type pass + submit.\n"
    "- When the task is complete, call `done` with a concise final answer.\n"
    "- Don't repeat yourself. If an action didn't change the page, try a different one."
)


class BrowserAgent:
    MAX_STEPS = 15

    def __init__(self, client: OpenAI, model: str, page):
        self.client = client
        self.model = model
        self.page = page
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    # ---- 浏览器侧 ----
    def _snapshot(self) -> str:
        elements = self.page.evaluate(EXTRACT_JS)
        return format_elements(elements)

    def _execute(self, name: str, args: dict) -> str:
        if name == "click":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').click()
            return f"clicked element [{args['index']}]"
        if name == "type_text":
            self.page.locator(f'[data-bread-id="{args["index"]}"]').fill(args["text"])
            return f"typed {args['text']!r} into [{args['index']}]"
        if name == "press_key":
            self.page.keyboard.press(args["key"])
            return f"pressed {args['key']}"
        return f"unknown action: {name}"

    def _build_tool_result(self, action_result: str) -> str:
        """工具执行后等页面稳定，再抽一次新快照，塞进 tool result。"""
        # 等待短暂时间让 DOM 更新（导航 / AJAX / 动画）
        try:
            self.page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        self.page.wait_for_timeout(400)
        new_snapshot = self._snapshot()
        return f"{action_result}\n\nCurrent page (URL: {self.page.url}):\n{new_snapshot}"

    # ---- 主循环 ----
    def run(self, task: str) -> str:
        snapshot = self._snapshot()
        self.messages.append({
            "role": "user",
            "content": f"Task: {task}\n\nCurrent page (URL: {self.page.url}):\n{snapshot}",
        })

        for step in range(self.MAX_STEPS):
            resp = self.client.chat.completions.create(
                model=self.model, messages=self.messages, tools=TOOLS_SCHEMA,
            )
            msg = resp.choices[0].message
            self.messages.append(msg)

            # 没调工具 = LLM 觉得任务完成了，直接说话
            if not msg.tool_calls:
                return msg.content or "(LLM finished without saying anything)"

            for call in msg.tool_calls:
                name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError as e:
                    self.messages.append({
                        "role": "tool", "tool_call_id": call.id,
                        "content": f"参数 JSON 解析失败: {e}",
                    })
                    continue

                print(f"  [step {step}] {name}({args})")

                if name == "done":
                    answer = args.get("answer", "(no answer)")
                    self.messages.append({
                        "role": "tool", "tool_call_id": call.id, "content": "task marked done",
                    })
                    return answer

                try:
                    action_result = self._execute(name, args)
                except Exception as e:
                    action_result = f"action failed: {type(e).__name__}: {e}"

                tool_content = self._build_tool_result(action_result)
                self.messages.append({
                    "role": "tool", "tool_call_id": call.id, "content": tool_content,
                })

        return "[已达到最大步数 MAX_STEPS]"
